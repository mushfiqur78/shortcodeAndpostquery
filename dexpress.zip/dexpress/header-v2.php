<body <?php body_class(); ?>>
    <div id="page" class="body_wrapper home2">
		<!-- ==================================================  
						Start Header Area
		=================================================== -->
		<header class="header_area">
			<div class="logo-overlay"></div>
			<div class="logo_area">
				<?php global $dexpress_opt;
                    $logo_url = !empty($dexpress_opt['logo-2_main']['url']) ? $dexpress_opt['logo-2_main']['url'] : null;
                    dexpress_logo( esc_url($logo_url) );  
                ?>
			</div>
			<div class="menu_area">
				<div class="container">
					<div class="row">
						<div class="col-md-9 col-md-offset-3 col-sm-12 col-sm-offset-0">
							<div class="top_toolbar">
								<div class="top_toolbar_left">
									<span><?php echo dexpress_welcome_text(); ?></span>
								</div>
								<?php dexpress_socialicons(); ?>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-9 col-md-offset-3 col-sm-12 col-sm-offset-0">
							<?php dexpress_hearder_top(); ?>
						</div>
					</div>
				</div>
			</div>
			<div class="mainmenu_area_fixed">
				<div class="mainmenu_area_fixed_inner">
					<nav class="mainmenu">
						<?php dexpress_main_menu(); ?>
					</nav>
				</div>
			</div>
			<div class="mobile_menu">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="mobile_mean_logo">
								<?php global $dexpress_opt;
                                    $logo_url = !empty($dexpress_opt['logo_main']['url']) ? $dexpress_opt['logo_main']['url'] : null;
                                    dexpress_logo( esc_url($logo_url) );
                                ?>
							</div>
							<nav class="mobile_mean_menu">
								<?php dexpress_mobile_menu(); ?>
							</nav>
						</div>
					</div>
				</div>
			</div>
		</header>
		<!-- ==================================================  
						End Header Area
		=================================================== -->