<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package dexpress
 */

get_header(); 
dexpress_blog_single_breadcrumb();
$single_blog_layout = dexpress_sidebar_layoutpossition('single_blog_layout', 'sidebar_single_blog_pos');
?>
    
        <!-- ==================================================  
						Start single_blog_content Area
		=================================================== -->
        <div class="blog blog-detail">
            <section class="single_blog_details_area">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12 <?php echo 'col-sm-'.$single_blog_layout['blogcolwidth']; if($single_blog_layout['blogsidebar']=='left'){ echo ' pull-right'; } ?>">
                            <div id="primary" class="content-area">
                                <main id="main" class="site-main" role="main">
									<div class="single_p_blog_detail">
                                    <?php
                                        while ( have_posts() ) : the_post();
                                            get_template_part( 'template-parts/content-single', get_post_format() );
                                            // If comments are open or we have at least one comment, load up the comment template.
                                            if ( comments_open() || get_comments_number() ) :
                                                comments_template();
                                            endif;
                                        endwhile; // End of the loop.
                                    ?>
									</div>
                                </main><!-- #main -->
                            </div><!-- #primary -->
                        </div>
                        <!-- Sidebar -->
                        <?php if( $single_blog_layout['blogsidebar']=='left' ||     
                                $single_blog_layout['blogsidebar']=='right' ) : ?>
                            <?php get_sidebar('singleblog'); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </section>
		</div>
		<!-- ==================================================  
						End single_blog_content Area
		=================================================== -->
<?php get_footer();
