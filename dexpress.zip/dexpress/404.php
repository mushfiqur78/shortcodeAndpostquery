<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package dexpress
 */

get_header(); 
global $dexpress_opt;
dexpress_breadcrumb(); ?>
<!-- ==================================================  
						Start Error Content Area
=================================================== -->
<section class="error_content_area">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="error_content">
                    <h2><?php dexpress_not_found_img(); ?></h2>
                    <p><?php dexpress_not_found_content(); ?></p>
                    <a href="<?php echo esc_url( home_url('/') ); ?>" class="business_btn btn_colored">
                        <i class="icofont icofont-long-arrow-left"></i>
                        <?php esc_html_e('Go Home', 'dexpress'); ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ==================================================  
                End Error Content Area
=================================================== -->
<?php get_footer();