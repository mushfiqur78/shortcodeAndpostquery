<?php
/**
 * dexpress functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package dexpress
 */

if ( ! function_exists( 'dexpress_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function dexpress_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on dexpress, use a find and replace
	 * to change 'dexpress' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'dexpress', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );
    
    /*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );
    add_image_size( 'dexpress-service-img', 350, 170, true );
    add_image_size( 'dexpress-blog-img', 458, 252, true );
    add_image_size( 'dexpress-protfolio-img', 400, 450, true );    
    add_image_size( 'dexpress-blog-sidebarthumb', 410, 275, true );
    add_image_size( 'dexpress-single-sidebarthumb', 734, 434, true );
    add_image_size( 'dexpress-team-img', 340, 355, true );
    add_image_size( 'dexpress-allteam-img', 155, 155, true );

    // This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'mainmenu' => esc_html__( 'Main Menu', 'dexpress' ),
		'footerbootom' => esc_html__( 'Footer Bottom Menu', 'dexpress' ),
	) );
    
	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'dexpress_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );
}
endif;

add_action( 'after_setup_theme', 'dexpress_setup' );

function dexpress_theme_add_editor_styles() {
    add_editor_style( 'assets/css/dexpress-editor-style.css' );
}
add_action( 'admin_init', 'dexpress_theme_add_editor_styles' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function dexpress_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'dexpress_content_width', 640 );
}
add_action( 'after_setup_theme', 'dexpress_content_width', 0 );
/**
 * dexpress Partner Slider
 */
function dexpress_partner_script(){
	global $dexpress_opt;
	ob_start(); ?>
		var dexpress_partnernumber = <?php if(!empty($dexpress_opt['partnernumber'])) { 
		echo esc_js($dexpress_opt['partnernumber']); 
		} else { echo '6'; } ?>,
		dexpress_partnerscroll = <?php echo esc_js(!empty($dexpress_opt['partnerscroll'])) ? 'true': 'false'; ?>;
	<?php
	return ob_get_clean();
}

// If we get this far, we have custom styles. Let's do this.
function dexpress_header_style_script(){
	
	ob_start();
	//add custom css
	global $dexpress_opt;
	if ( isset($dexpress_opt['custom_css']) && !empty($dexpress_opt['custom_css'])) { ?>
		<?php echo esc_html($dexpress_opt['custom_css']); ?>
	<?php }
		// Has the text been hidden?
		if ( ! display_header_text() ) :
	?>
	.site-title,
	.site-description {
		position: absolute;
		clip: rect(1px, 1px, 1px, 1px);
	}
	<?php
		// If the user has set a custom color for the text use that.
		else :
	?>
	.site-title a,
	.site-description {
		color: #<?php
		$header_text_color = get_header_textcolor();
		echo esc_attr( $header_text_color ); ?>;
	}
	<?php endif; ?>
	<?php return ob_get_clean();
}

/**
 * Enqueue google fonts.
 */
function dexpress_fonts_url(){
	$fonts_url = '';
	 
	/* Translators: If there are characters in your language that are not
	* supported by Roboto, translate this to 'off'. Do not translate
	* into your own language.
	*/
	$roboto = _x( 'on', 'Roboto font: on or off', 'dexpress' );
	$robotoslab = _x( 'on', 'Ubuntu font: on or off', 'dexpress' );
	 
	/* Translators: If there are characters in your language that are not
	* supported by Open Sans, translate this to 'off'. Do not translate
	* into your own language.
	*/
	 
	if ( 'off' !== $roboto || 'off' !== $robotoslab ) {
		$font_families = array();

		if ( 'off' !== $roboto ) {
			$font_families[] = 'Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i';
		}

		if ( 'off' !== $robotoslab ) {
			$font_families[] = 'Roboto Slab:300,400,700,800';
		}

		$query_args = array(
			'family' => urlencode( implode( '|', $font_families ) ),
			'subset' => urlencode( 'latin,latin-ext' ),	
		);

		$fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
	}
	 
	return esc_url_raw( $fonts_url );
}
function dexpress_inline_stylesheet(){
    global $dexpress_opt;
    ob_start(); ?>
p.form-submit input{
	background: <?php echo !empty($dexpress_opt['background_primary_color']['background-color'])?> !important;
}    
<?php
    return ob_get_clean();
}


/**
 * Enqueue scripts and styles.
 */
function dexpress_scripts() {
	// Add custom fonts, used in the main stylesheet.
	wp_enqueue_style( 'dexpress-fonts', dexpress_fonts_url(), array(), null );
    
    // Bootstrap Min CSS
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css' );
    
    // Carousel Min CSS
    wp_enqueue_style( 'owl-carousel', get_template_directory_uri() . '/assets/css/owl.carousel.min.css' );
    
    // Animate Min CSS
    wp_enqueue_style( 'animate', get_template_directory_uri() . '/assets/css/animate.min.css' );
    
    wp_enqueue_style( 'aos', get_template_directory_uri() . '/assets/css/aos.css' );
    
    // Font Awesome Min CSS
    wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/css/all.min.css' );	 
    
    // Venobox CSS
    wp_enqueue_style( 'venobox', get_template_directory_uri() . '/assets/css/venobox.css' );
    
    // Meanmenu CSS
    wp_enqueue_style( 'meanmenu', get_template_directory_uri() . '/assets/css/meanmenu.css' );
   
    // Magnific-popup CSS
    wp_enqueue_style( 'magnific', get_template_directory_uri() . '/assets/css/magnific-popup.css' );
    
    // Main Style
    wp_enqueue_style( 'dexpress-main-style', get_template_directory_uri() . '/assets/css/style.css' );
    
    // Style Sheet
	wp_enqueue_style( 'dexpress-style', get_stylesheet_uri() );
    
    // Style inline
    wp_add_inline_style( 'dexpress-style', dexpress_inline_stylesheet() );
    
    // Bootstrap Script
	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), '3.3.7', true );
	wp_enqueue_script( 'fontawesome', get_template_directory_uri() . '/js/all.min.js', array('jquery'), '3.3.7', true );
    
    // Carousel Script
	wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array('jquery'), '1.0', true );
    
    // Easing Script
    wp_enqueue_script( 'jquery-easing-', get_template_directory_uri() . '/assets/js/jquery.easing.min.js', array('jquery'), '1.3.2', true );
    
    // Isotope Script
	wp_enqueue_script( 'isotope-pkgd', get_template_directory_uri() . '/assets/js/isotope.pkgd.min.js', array('jquery'), '3.0.3', true );
    
    // Packery Script
	wp_enqueue_script( 'packery-pkgd', get_template_directory_uri() . '/assets/js/packery.pkgd.min.js', array('jquery'), '2.0.0', true );
	
    // Jquery Counterup
    wp_enqueue_script( 'jquery-counterup', get_template_directory_uri() . '/assets/js/jquery.counterup.js', array('jquery'), '1.0', true );
    
    wp_enqueue_script( 'venobox', get_template_directory_uri() . '/assets/js/venobox.min.js', array('jquery'), '1.0', true );
    
    // waypoints
	wp_enqueue_script( 'waypoints', get_template_directory_uri() . '/assets/js/jquery.waypoints.min.js', array('jquery'), '4.0.1', true );
	
    // Lettering
	wp_enqueue_script( 'jquery-lettering', get_template_directory_uri() . '/assets/js/jquery.lettering.js', array('jquery'), '2.0.3', true );
	wp_enqueue_script( 'jquery-meanmenu', get_template_directory_uri() . '/assets/js/jquery.meanmenu.min.js', array('jquery'), '2.0.3', true );
	
    wp_enqueue_script( 'jquery-magnific-popup', get_template_directory_uri() . '/assets/js/jquery.magnific-popup.min.js', array('jquery'), '1.0', true );
	
    // Inline Script
	wp_enqueue_script( 'aos-js', get_template_directory_uri() . '/assets/js/aos.js', array('jquery'), '1.0', true );
	
    wp_enqueue_script( 'dexpress-main-js', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), '1.0', true );
    
    // Inline Script
    wp_add_inline_style( 'dexpress-style', dexpress_header_style_script(),'wp_head' );
    
    wp_enqueue_script( 'dexpress-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'dexpress-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );
    
    wp_add_inline_script('dexpress-main-js', dexpress_partner_script(), 'before');
    
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'dexpress_scripts' );
add_action( 'wp_enqueue_scripts', function(){
	wp_enqueue_style( 'font-awesome', '//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css' );
});
add_filter('wpacu_preload_locad_font_files_out',function(){
	return '';
});
/**
*Custom Admin Style 
*/
function dexpress_admin_acripts(){
	wp_enqueue_style('thickbox');
	wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
    wp_enqueue_script('upload_media_widget', get_template_directory_uri() . '/js/upload-media.js', array('jquery'));
}
add_action('admin_enqueue_scripts','dexpress_admin_acripts');

/**
 * Load TGM plugin file.
 */
require get_template_directory() . '/inc/tgm-plugin/class-tgm-plugin-activation.php';
require get_template_directory() . '/inc/tgm-plugin/required-plugins.php';
/**
 * Widget
 */
require_once get_template_directory() . '/inc/widgets/register-widget.php';
/**
 * Load Redux Framework file.
 */
if ( file_exists( get_template_directory().'/inc/dexpress-config.php' ) ) {
  require_once( get_template_directory().'/inc/dexpress-config.php' );
}
/**
 * Load global function file.
 */
require_once get_template_directory() . '/inc/global-function.php';
require_once get_template_directory() . '/inc/dexpress_metabox.php';
/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';
/**
 * Custom Excerpt Lenth.
 */
//Google Map Api Key
global $dexpress_opt;
if(isset($dexpress_opt['map_apy_key']) && !empty($dexpress_opt['map_apy_key'])){
	add_action('wp_enqueue_scripts', 'dexpress_googlemap_api_enqueue');
}
function dexpress_comment_reply($content) {
    $content = str_replace('Reply', '<i class="fa fa-reply-all"></i>
', $content);
    return $content;
}
add_filter('comment_reply_link', 'dexpress_comment_reply');

/* Sort team members like page order i.e. the number assigned */
add_action( 'pre_get_posts', 'my_change_sort_order'); 
    function my_change_sort_order($query){
        if(is_archive()):
         //If you wanted it for the archive of a custom post type use: is_post_type_archive( $post_type )
           //Set the order ASC or DESC
           $query->set( 'order', 'DESC' );
           //Set the orderby
        endif;    
    };
function change_category_order( $query ) {
    if ( $query->is_tax('work_category') ) {
        $query->set( 'order', 'ASC' );
    }
}
add_action( 'pre_get_posts', 'change_category_order' );