<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package dexpress
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<?php wp_head(); ?>
</head>
<?php
        $dexpress_pg_header =  get_post_meta(get_the_ID(),'_dexpress_page_header',true); 
           if( is_page() ):
                if( ($dexpress_pg_header==2) ){
                    get_header('v2'); 
                }
                else{
                    get_header('v1');
                }
           else:
                dexpress_header_layout();
           endif; 
        ?>