<?php
// Header layout
function dexpress_header_layout(){
    global $dexpress_opt;
    if ( !isset($dexpress_opt['header_layout']) ) {
        get_header('v1');
    } else {
        get_header($dexpress_opt['header_layout']);
    };
 }
// Display header top bar
function dexpress_header_top_show(){
	global $dexpress_opt;
    if( isset( $dexpress_opt['show_header_top_bar'] ) ){
        return $dexpress_opt['show_header_top_bar'];
    }else{
        return 1;
    }
}
// Phone number
function dexpress_top_bar_phone(){
	global $dexpress_opt;
    $return = (isset($dexpress_opt['top_bar_phone']) && !empty($dexpress_opt['top_bar_phone'])) ? $dexpress_opt['top_bar_phone'] : false;
	return $return;
}
// Phone number Text line
function dexpress_phone_text(){
	global $dexpress_opt;
	$return = (isset($dexpress_opt['phone_text']) && !empty($dexpress_opt['phone_text'])) ? $dexpress_opt['phone_text'] : false;
	return $return;
}
// Email Address
function dexpress_top_bar_email(){
	global $dexpress_opt;
	 $return = (isset($dexpress_opt['top_bar_email']) && !empty($dexpress_opt['top_bar_email'])) ? $dexpress_opt['top_bar_email'] : false;
	return $return;
}
// Email Address Text
function dexpress_email_text(){
	global $dexpress_opt;
    $return = (isset($dexpress_opt['email_text']) && !empty($dexpress_opt['email_text'])) ? $dexpress_opt['email_text'] : false;
    return $return;
}
// Email Address
function dexpress_adress_line1(){
	global $dexpress_opt;
	$return = (isset($dexpress_opt['adress_line1']) && !empty($dexpress_opt['adress_line1'])) ? $dexpress_opt['adress_line1'] : false;
    return $return;
}
// Email Address
function dexpress_adress_line2(){
	global $dexpress_opt;
	$return = (isset($dexpress_opt['adress_line1']) && !empty($dexpress_opt['adress_line2'])) ? $dexpress_opt['adress_line2'] : false;
    return $return;
}
// Display logo
function dexpress_logo($theme_logo_url = ''){
    $theme_logo = $theme_logo_url;
	if(is_ssl()){
		$theme_logo = str_replace('http:', 'https:', $theme_logo_url);
	}
	
	if( !empty($theme_logo) ){ ?>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
				<img src="<?php echo esc_url($theme_logo); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" />
			</a>
		<?php
		} else { ?>
			<h3 class="navbar-blog-info">
			    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
			        <?php bloginfo( 'name' ); ?>
			    </a>
            </h3>
			<?php
		} ?>
	<?php
}
// Display header top bar
function dexpress_welcome_text(){
    global $dexpress_opt;
    if(isset($dexpress_opt['welcome_text']) && !empty ($dexpress_opt['welcome_text'])); {
	return $dexpress_opt['welcome_text'];
    };
}
// Topbar Social link
function dexpress_socialicons(){
	global $dexpress_opt;
	if(isset($dexpress_opt['topbar_social_icons'])) {
        echo '<div class="top_toolbar_right">';
        foreach($dexpress_opt['topbar_social_icons'] as $key=>$value ) {
             if(!empty($value) && $value!=$key){
                echo '<a class="'.esc_attr($key).' social-icon" href="'.esc_url($value).'" title="'.ucwords(esc_attr($key)).'" target="_blank">
                <i class="fa-brands fa-'.esc_attr($key).' "></i>
                </a>';
            }
        }
        echo '</div>';
    };
}
// dexpress hearder top
function dexpress_hearder_top(){
	if( dexpress_header_top_show() == 1) : ?>
        <!-- ======================================
                ==Start toolbar==
        ====================================== -->
        <div class="toolbar_bottom">
            <ul>
               <?php if( dexpress_top_bar_phone () ){ ?>
                <li>
                    <div class="toolbar_bottom_img">
                        <i class="fa fa-phone" aria-hidden="true"></i>
                    </div>
                    <div class="toolbar_bottom_content">
                        <span><?php echo esc_html(dexpress_phone_text());?></span>
                        <a href="tel:<?php echo esc_attr(dexpress_top_bar_phone()); ?>">
                            <?php echo esc_html(dexpress_top_bar_phone()); ?>
                        </a>
                    </div>
                </li>
                <?php } ?>
                <?php if( dexpress_adress_line1() ){ ?>
                    <li>
                        <div class="toolbar_bottom_img">
                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                        </div>
                        <div class="toolbar_bottom_content">
                            <span><?php echo esc_attr(dexpress_adress_line1()); ?></span>
                            <?php echo esc_html(dexpress_adress_line2()); ?>
                        </div>
                    </li>
                <?php } ?>
                <?php if( dexpress_top_bar_email() ){ ?>
                <li>
                    <div class="toolbar_bottom_img">
                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                    </div>
                    <div class="toolbar_bottom_content">
                        <span><?php echo esc_html(dexpress_email_text()); ?></span>
                        <a  href="mailto:<?php echo esc_attr(dexpress_top_bar_email()); ?>">
                            <?php echo esc_html(dexpress_top_bar_email()); ?>
                        </a>
                    </div>
                </li>
                <?php } ?>        
            </ul>
        </div>
        <!-- ====================================
                ==Start toolbar==
        ====================================== -->
	<?php endif;
}
// Main Menu
function dexpress_main_menu(){
	wp_nav_menu( array(
        'theme_location'    => 'mainmenu', 
        'container_class'   => '',
        'menu_class'        => '',
        'fallback_cb'       => 'dexpress_menu_cb',
        'container'       => ''
    ));
}
function dexpress_menu_cb (){
        echo '<ul class=" ">';
        echo '<li><a href="' . admin_url( 'nav-menus.php' ) . '">'.esc_html('Add a menu', 'dexpress').'</a></li>';
        echo '</ul>';
}
function dexpress_mobile_menu(){
    wp_nav_menu( array(
        'theme_location'    => 'mainmenu', 
        'container_class'   => '',
        'menu_class'        => 'menu_for_mobile',
        'fallback_cb'       => 'dexpress_menu_cb'
    ));
}
function dexpress_footer_menu(){
    wp_nav_menu( array(
        'theme_location'    => 'footerbootom', 
        'container_class'   => '',
        'menu_class'        => 'menu_for_mobile',
        'fallback_cb'       => 'dexpress_menu_cb'
    ));
}

// Page sidebar without Metabox;
function dexpress_metabox_exclude_blog_page() {
    $post_id = true;
    // If we're showing it based on ID, get the current ID
    if ( isset( $_GET['post'] ) ) {
        $post_id = $_GET['post'];
    } elseif ( isset( $_POST['post_ID'] ) ) {
        $post_id = $_POST['post_ID'];
    }
    if ( ! $post_id ) {
        return false;
    }
    // Get ID of page set as front page, 0 if there isn't one
    $blog_page = get_option( 'page_for_posts' );
    // there is a front page set and we're on it!
    return $post_id !== $blog_page;
}
// 404 error page error massage
function dexpress_not_found_content() {
	global $dexpress_opt;
	if ($dexpress_opt['notfound_content']){
		echo esc_html($dexpress_opt['notfound_content']);
	}
	else {
		echo esc_html('The page you are looking for, is not available','dexpress');
	}
}
// 404 error page error massage
function dexpress_not_found_img() {
	global $dexpress_opt;
	if ( !empty ($dexpress_opt['not_foundimg']['url'])){ ?>
		<img src="<?php echo esc_url($dexpress_opt['not_foundimg']['url']); ?>"/>
	<?php }
	else {
		esc_html_e('404','dexpress');
	}
}
// Sidebar Layout Possion function;
function dexpress_sidebar_layoutpossition($layout, $sidebar_possition, $page_layout=false){
    global $dexpress_opt;
    $bloglayout = 'sidebar';

    if($page_layout){
        $bloglayout = $page_layout;
    }else{
        if(isset($dexpress_opt[$layout]) && !empty($dexpress_opt[$layout])){
            $bloglayout = $dexpress_opt[$layout];
        }
    }
    
    if(isset($_GET['layout']) && $_GET['layout']!=''){
        $bloglayout = $_GET['layout'];
    }

    $blogsidebar = 'right';
    if(isset($dexpress_opt[$sidebar_possition]) && !empty($dexpress_opt[$sidebar_possition])){
        $blogsidebar = $dexpress_opt[$sidebar_possition];
    }

    if(isset($_GET['sidebar']) && $_GET['sidebar']!=''){
        $blogsidebar = $_GET['sidebar'];
    }

    $returnArray = array(
        'blogcolwidth' => 0,
        'blogsidebar' => $blogsidebar
    );
    
    if($bloglayout == 'sidebar'){
        $blogcolwidth = 9;
        
        $returnArray['blogcolwidth'] = $blogcolwidth;
    }else{
        $blogcolwidth = 12;
        $blogsidebar = 'no-sidebar';
        
        $returnArray['blogcolwidth'] = $blogcolwidth;
        $returnArray['blogsidebar'] = $blogsidebar;
    }
    return $returnArray;
}
//// BREADCRUMB START ////       
function dexpress_the_breadcrumb() {
  $showOnHome = 1; // 1 - show breadcrumbs on the homepage, 0 - don't show
  function dexpress_breadcrumb_delimiter(){
      return '<i class="fa fa-angle-double-right"></i>';
  } // delimiter between crumbs
    
  $home = __('Home', 'dexpress'); // text for the 'Home' link
  $showCurrent = 1; // 1 - show current post/page title in breadcrumbs, 0 - don't show
    
  function dexpress_breadcrumb_before(){
      return '<span class="current">';
  } // tag before the current crumb

  function dexpress_breadcrumb_after(){
      return '</span>';
  } // tag after the current crumb

  global $post;
  $homeLink = home_url();
 
  if (is_home() || is_front_page()) {
 
    if ($showOnHome == 1 && is_home()) echo '<div id="crumbs"><a href="' . esc_url($homeLink) . '">' . esc_html($home) . '</a></div>';
 
  } else {
 
    echo '<div id="crumbs"><a href="' . esc_url($homeLink) . '">' . esc_html($home) . '</a> ' . dexpress_breadcrumb_delimiter() . ' ';
 
    if ( is_category() ) {
      $thisCat = get_category(get_query_var('cat'), false);
      if ($thisCat->parent != 0) echo get_category_parents($thisCat->parent, TRUE, ' ' . dexpress_breadcrumb_delimiter() . ' ');
      echo dexpress_breadcrumb_before() . esc_html__('Archive by category "', 'dexpress') . single_cat_title('', false) . esc_html__('"', 'dexpress') . dexpress_breadcrumb_after();
 
    } elseif ( is_search() ) {
      echo dexpress_breadcrumb_before() . esc_html__('Search results for "', 'dexpress') . get_search_query() . esc_html__('"', 'dexpress') . dexpress_breadcrumb_after();
 
    } elseif ( is_day() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . dexpress_breadcrumb_delimiter() . ' ';
      echo '<a href="' . get_month_link(get_the_time('Y'),get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . dexpress_breadcrumb_delimiter() . ' ';
      echo dexpress_breadcrumb_before() . get_the_time('d') . dexpress_breadcrumb_after();
 
    } elseif ( is_month() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . dexpress_breadcrumb_delimiter() . ' ';
      echo dexpress_breadcrumb_before() . get_the_time('F') . dexpress_breadcrumb_after();
 
    } elseif ( is_year() ) {
      echo dexpress_breadcrumb_before() . get_the_time('Y') . dexpress_breadcrumb_after();
 
    } elseif ( is_single() && !is_attachment() ) {
      if ( get_post_type() != 'post' ) {
        $post_type = get_post_type_object(get_post_type());
        $slug = $post_type->rewrite;
        echo '<a href="' . esc_url($homeLink) . '/' . esc_attr($slug['slug']) . '/">' . esc_html($post_type->labels->singular_name) . '</a>';
        if ($showCurrent == 1) echo ' ' . dexpress_breadcrumb_delimiter() . ' ' . dexpress_breadcrumb_before() . get_the_title() . dexpress_breadcrumb_after();
      } else {
        $cat = get_the_category(); $cat = $cat[0];
        $cats = get_category_parents($cat, TRUE, ' ' . dexpress_breadcrumb_delimiter() . ' ');
        if ($showCurrent == 0) $cats = preg_replace("#^(.+)\s". dexpress_breadcrumb_delimiter() ."\s$#", "$1", $cats);
        echo wp_kses($cats, array(
            'a' => array(
                'href' => array(),
                'title' => array()
            ),
            'i' => array(
                'class' => array()
            )
        ));
        if ($showCurrent == 1) echo dexpress_breadcrumb_before() . get_the_title() . dexpress_breadcrumb_after();
      }
 
    } elseif ( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ) {
      $post_type = get_post_type_object(get_post_type());
      echo dexpress_breadcrumb_before() . esc_html($post_type->labels->singular_name) . dexpress_breadcrumb_after();
 
    } elseif ( is_attachment() ) {
      $parent = get_post($post->post_parent);
      $cat = get_the_category($parent->ID); $cat = $cat[0];
    echo is_wp_error( $cat_parents = get_category_parents($cat, TRUE, '' . dexpress_breadcrumb_delimiter() . '') ) ? '' : $cat_parents;
      
      echo '<a href="' . get_permalink($parent) . '">' . esc_html($parent->post_title) . '</a>';
      if ($showCurrent == 1) echo ' ' . dexpress_breadcrumb_delimiter() . ' ' . dexpress_breadcrumb_before() . get_the_title() . dexpress_breadcrumb_after();
 
    } elseif ( is_page() && !$post->post_parent ) {
      if ($showCurrent == 1) echo dexpress_breadcrumb_before() . get_the_title() . dexpress_breadcrumb_after();
 
    } elseif ( is_page() && $post->post_parent ) {
      $parent_id  = $post->post_parent;
      $breadcrumbs = array();
      while ($parent_id) {
        $page = get_page($parent_id);
        $breadcrumbs[] = '<a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';
        $parent_id  = $page->post_parent;
      }
      $breadcrumbs = array_reverse($breadcrumbs);
      for ($i = 0; $i < count($breadcrumbs); $i++) {
        echo wp_kses($breadcrumbs[$i], array(
            'a' => array(
                'href' => array()
            )
        ));
        if ($i != count($breadcrumbs)-1) echo ' ' . dexpress_breadcrumb_delimiter() . ' ';
      }
      if ($showCurrent == 1) echo ' ' . dexpress_breadcrumb_delimiter() . ' ' . dexpress_breadcrumb_before() . get_the_title() . dexpress_breadcrumb_after();
 
    } elseif ( is_tag() ) {
      echo dexpress_breadcrumb_before() . esc_html__('Posts tagged "', 'dexpress') . single_tag_title('', false) . esc_html__('"', 'dexpress') . dexpress_breadcrumb_after();
 
    } elseif ( is_author() ) {
       global $author;
      $userdata = get_userdata($author);
      echo dexpress_breadcrumb_before() . esc_html__('Articles posted by "', 'dexpress') . esc_html($userdata->display_name) . esc_html__('"', 'dexpress') . dexpress_breadcrumb_after();
 
    } elseif ( is_404() ) {
      echo dexpress_breadcrumb_before() . esc_html__('Error 404', 'dexpress') . dexpress_breadcrumb_after();
    }
      
    if ( get_query_var('paged') ) {
          if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() || is_page() ) echo '<span>'.esc_html__(' (', 'dexpress');
          echo __('Page', 'dexpress') . ' ' . get_query_var('paged');
          if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() || is_page() ) echo esc_html__(')', 'dexpress').'</span>';
    }
    echo '</div>';
 
  }
}
//// BREADCRUMB END ////

// Display Blog breadcrumb
function dexpress_breadcrumb(){
	global $dexpress_opt; ?>
	    <!-- START BREADCRUMB AREA -->
        <section class="breadcrumb_area blog-bdcmb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="breadcrumb_content">
							<h2>
                                <?php
                                    if(is_home() && is_front_page()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : esc_html__( 'Posts', 'dexpress' );
                                    }else if(is_home()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : wp_title('', false);
                                    }else{
                                        $title = wp_title('', false);
                                    }
                                    echo esc_html($title);
                                ?>
                            </h2>
							<div class="breadcrumb_location">
							    <?php dexpress_the_breadcrumb(); ?>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</section>
        <!--END BREADCRUMB AREA-->
<?php }
// Display Blog breadcrumb
function dexpress_blog_single_breadcrumb(){
	global $dexpress_opt; ?>
	    <!-- START BREADCRUMB AREA -->
        <section class="breadcrumb_area blog_single">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="breadcrumb_content">
							<h2>
                                <?php
                                    if(is_home() && is_front_page()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : esc_html__( 'Posts', 'dexpress' );
                                    }else if(is_home()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : wp_title('', false);
                                    }else{
                                        $title = wp_title('', false);
                                    }
                                    echo esc_html($title);
                                ?>
                            </h2>
							<div class="breadcrumb_location">
							    <?php dexpress_the_breadcrumb(); ?>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</section>
        <!--END BREADCRUMB AREA-->
<?php }
// Display About breadcrumb
function dexpress_about_us_breadcrumb(){
	global $dexpress_opt; ?>
	    <!-- START BREADCRUMB AREA -->
        <section class="breadcrumb_area about_us">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="breadcrumb_content">
							<h2>
                                <?php
                                    if(is_home() && is_front_page()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : esc_html__( 'Posts', 'dexpress' );
                                    }else if(is_home()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : wp_title('', false);
                                    }else{
                                        $title = wp_title('', false);
                                    }
                                    echo esc_html($title);
                                ?>
                            </h2>
							<div class="breadcrumb_location">
							    <?php dexpress_the_breadcrumb(); ?>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</section>
        <!--END BREADCRUMB AREA-->
<?php }
// Display Blog breadcrumb
function dexpress_work_breadcrumb(){
	global $dexpress_opt; ?>
	    <!-- START BREADCRUMB AREA -->
        <section class="breadcrumb_area workpage">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="breadcrumb_content">
							<h2>
                                <?php
                                    if(is_home() && is_front_page()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : esc_html__( 'Posts', 'dexpress' );
                                    }else if(is_home()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : wp_title('', false);
                                    }else{
                                        $title = wp_title('', false);
                                    }
                                    echo esc_html($title);
                                ?>
                            </h2>
							<div class="breadcrumb_location">
							    <?php dexpress_the_breadcrumb(); ?>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</section>
        <!--END BREADCRUMB AREA-->
<?php }
// Display Blog breadcrumb
function dexpress_work_with_us_breadcrumb(){
	global $dexpress_opt; ?>
	    <!-- START BREADCRUMB AREA -->
        <section class="breadcrumb_area workwithus">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="breadcrumb_content">
							<h2>
                                <?php
                                    if(is_home() && is_front_page()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : esc_html__( 'Posts', 'dexpress' );
                                    }else if(is_home()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : wp_title('', false);
                                    }else{
                                        $title = wp_title('', false);
                                    }
                                    echo esc_html($title);
                                ?>
                            </h2>
							<div class="breadcrumb_location">
							    <?php dexpress_the_breadcrumb(); ?>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</section>
        <!--END BREADCRUMB AREA-->
<?php }
// Display Blog breadcrumb
function dexpress_service_breadcrumb(){
	global $dexpress_opt; ?>
	    <!-- START BREADCRUMB AREA -->
        <section class="breadcrumb_area servicepage">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="breadcrumb_content">
							<h2>
                                <?php
                                    if(is_home() && is_front_page()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : esc_html__( 'Posts', 'dexpress' );
                                    }else if(is_home()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : wp_title('', false);
                                    }else{
                                        $title = wp_title('', false);
                                    }
                                    echo esc_html($title);
                                ?>
                            </h2>
							<div class="breadcrumb_location">
							    <?php dexpress_the_breadcrumb(); ?>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</section>
        <!--END BREADCRUMB AREA-->
<?php }
// Display Blog breadcrumb
function dexpress_singleservicepage_breadcrumb(){
	global $dexpress_opt;
    $backgroundImg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );
    ?>
	    <!-- START BREADCRUMB AREA -->
        <section class="singleservicepage" style="background-image: url('<?php echo $backgroundImg[0]; ?>')">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="breadcrumb_content">
							<h2>
                               
                                <?php
                                    if(is_home() && is_front_page()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : esc_html__( 'Posts', 'dexpress' );
                                    }else if(is_home()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : wp_title('', false);
                                    }else{
                                        $title = wp_title('', false);
                                    }
                                    echo esc_html($title);
                                ?>
                            </h2>
							<div class="breadcrumb_location">
							    <?php dexpress_the_breadcrumb(); ?>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</section>
        <!--END BREADCRUMB AREA-->
<?php }
// Display Blog breadcrumb
function dexpress_protfolio_breadcrumb(){
	global $dexpress_opt; ?>
	    <!-- START BREADCRUMB AREA -->
        <section class="breadcrumb_area protfoliopage">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="breadcrumb_content">
							<h2>
                                <?php
                                    if(is_home() && is_front_page()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : esc_html__( 'Posts', 'dexpress' );
                                    }else if(is_home()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : wp_title('', false);
                                    }else{
                                        $title = wp_title('', false);
                                    }
                                    echo esc_html($title);
                                ?>
                            </h2>
							<div class="breadcrumb_location">
							    <?php dexpress_the_breadcrumb(); ?>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</section>
        <!--END BREADCRUMB AREA-->
<?php }
// Display Blog breadcrumb
function dexpress_singlework_breadcrumb(){
	global $dexpress_opt; ?>
	    <!-- START BREADCRUMB AREA -->
        <section class="breadcrumb_area singlework">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="breadcrumb_content">
							<h2>
                                <?php
                                    if(is_home() && is_front_page()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : esc_html__( 'Posts', 'dexpress' );
                                    }else if(is_home()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : wp_title('', false);
                                    }else{
                                        $title = wp_title('', false);
                                    }
                                    echo esc_html($title);
                                ?>
                            </h2>
							<div class="breadcrumb_location">
							    <?php dexpress_the_breadcrumb(); ?>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</section>
        <!--END BREADCRUMB AREA-->
<?php }
// Display peoplepage breadcrumb
function dexpress_peoplepage_breadcrumb(){
	global $dexpress_opt; ?>
	    <!-- START BREADCRUMB AREA -->
        <section class="breadcrumb_area peoplepage">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="breadcrumb_content">
							<h2>
                                <?php
                                    if(is_home() && is_front_page()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : esc_html__( 'Posts', 'dexpress' );
                                    }else if(is_home()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : wp_title('', false);
                                    }else{
                                        $title = wp_title('', false);
                                    }
                                    echo esc_html($title);
                                ?>
                            </h2>
							<div class="breadcrumb_location">
							    <?php dexpress_the_breadcrumb(); ?>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</section>
        <!--END BREADCRUMB AREA-->
<?php }
// Display peoplepage breadcrumb
function dexpress_playtime_breadcrumb(){
	global $dexpress_opt; ?>
	    <!-- START BREADCRUMB AREA -->
        <section class="breadcrumb_area playtime">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="breadcrumb_content">
							<h2>
                                <?php
                                    if(is_home() && is_front_page()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : esc_html__( 'Posts', 'dexpress' );
                                    }else if(is_home()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : wp_title('', false);
                                    }else{
                                        $title = wp_title('', false);
                                    }
                                    echo esc_html($title);
                                ?>
                            </h2>
							<div class="breadcrumb_location">
							    <?php dexpress_the_breadcrumb(); ?>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</section>
        <!--END BREADCRUMB AREA-->
<?php }
// Display peoplepage breadcrumb
function dexpress_talkwith_us_breadcrumb(){
	global $dexpress_opt; ?>
	    <!-- START BREADCRUMB AREA -->
        <section class="breadcrumb_area talkwith">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="breadcrumb_content">
							<h2>
                                <?php
                                    if(is_home() && is_front_page()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : esc_html__( 'Posts', 'dexpress' );
                                    }else if(is_home()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : wp_title('', false);
                                    }else{
                                        $title = wp_title('', false);
                                    }
                                    echo esc_html($title);
                                ?>
                            </h2>
							<div class="breadcrumb_location">
							    <?php dexpress_the_breadcrumb(); ?>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</section>
        <!--END BREADCRUMB AREA-->
<?php }
// Display peoplepage breadcrumb
function dexpress_gallery_breadcrumb(){
	global $dexpress_opt; ?>
	    <!-- START BREADCRUMB AREA -->
        <section class="breadcrumb_area gallery">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="breadcrumb_content">
							<h2>
                                <?php
                                    if(is_home() && is_front_page()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : esc_html__( 'Posts', 'dexpress' );
                                    }else if(is_home()){
                                        $title = !empty($dexpress_opt['blog_breadcrumb_title']) ? $dexpress_opt['blog_breadcrumb_title'] : wp_title('', false);
                                    }else{
                                        $title = wp_title('', false);
                                    }
                                    echo esc_html($title);
                                ?>
                            </h2>
							<div class="breadcrumb_location">
							    <?php dexpress_the_breadcrumb(); ?>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</section>
        <!--END BREADCRUMB AREA-->
<?php }
// Blog Continue Reading  Button Text
function dexpress_blog_read_more(){
	global $dexpress_opt;
	if(isset($dexpress_opt['readmore_text'])){ 
        echo esc_html($dexpress_opt['readmore_text']); 
    } else { 
        esc_html_e('Continue Reading ', 'dexpress');
    }
}
//Change excerpt length
function dexpress_change_excerpt_length( $length ) {
	global $dexpress_opt;
	
	if(isset($dexpress_opt['excerpt_length'])){
		return $dexpress_opt['excerpt_length'];
	}
	return 16;
}
add_filter( 'excerpt_length', 'dexpress_change_excerpt_length', 999 );

// dexpress Newsletter title  Dispaly
function dexpress_newsletter_title(){
	global $dexpress_opt;
	if(!empty($dexpress_opt['newsletter_title'])) { 
        echo '<div class="footer_subscribe_heading">'.esc_html($dexpress_opt['newsletter_title']).'</div>'; 
    }
}
// dexpress Newsletter Description  dispaly
function dexpress_newsletter_des(){
	global $dexpress_opt;
	if(!empty($dexpress_opt['newsletter_description'])) {
        echo esc_html($dexpress_opt['newsletter_description']);
    }
}
// dexpress Newsletter Description  dispaly
function dexpress_newsletter_form(){
	global $dexpress_opt;
	if(!empty( $dexpress_opt['newsletter_form'] )){
       echo do_shortcode($dexpress_opt['newsletter_form']);
    }
}
// Contact copyright text
function dexpress_copyright(){
	global $dexpress_opt;
	if( isset($dexpress_opt['copyright']) && $dexpress_opt['copyright']!='' ) {
		echo wp_kses($dexpress_opt['copyright'], array(
			'a' => array(
				'href' => array(),
				'title' => array()
			),
			'br' => array(),
			'em' => array(),
			'strong' => array(),
		));
	} else {
		echo esc_html__('Copyright 2021 ' , 'dexpress'). " <a href='".esc_url('digitalexpressionsltd.com')."' target='_blank'>".esc_html__('' , 'dexpress')."</a> ".esc_html__('All Rights Reserved by Digital Expressions.' , 'dexpress');

	};
}
/**
 *  comment list modify 
 */
function dexpress_comments($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment; ?>
        <li <?php comment_class('comment'); ?> id="comment-<?php comment_ID() ?>">
            <div class="media">
                <div class="pull-left">
                    <?php echo get_avatar( $comment, 82 ); ?>
                </div>
                <div class="media_body">
                    <section class="comment-content comment">
                        <p><?php comment_text() ?></p>
                    </section>
                    <header class="media_top">
                        <div class="heading_left">
                            <a href="<?php comment_author_url(); ?>">
                                <?php comment_author(); ?>
                            </a>
                        </div>
                        <?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))); ?> 
                    </header>
                </div>
            </div>
                
<?php }


// comment box title change
add_filter( 'comment_form_defaults', 'dexpress_remove_comment_form_allowed_tags' );
function dexpress_remove_comment_form_allowed_tags( $defaults ) {
	$defaults['comment_notes_after'] = '';
	$defaults['comment_notes_before'] = '';
	return $defaults;
}

// comment form modify
function dexpress_modify_comment_form_fields($fields){
	$commenter = wp_get_current_commenter();
	$req	   = get_option( 'require_name_email' );

	$fields['author'] = '<div class="row"><div class="col-md-6"><div class="single_reply_box">
            <input type="text"  id="author" class="input-name" placeholder="'. esc_attr__("Your Name *", "dexpress").'" name="author" value="'. esc_attr( $commenter['comment_author'] ) .'" '. ( $req ? 'aria-required="true"' : '' ).'></div></div>';


	$fields['email'] = '<div class="col-md-6"><div class="single_reply_box">
            <input type="email" id="email" class="input-email" placeholder="'. esc_attr__("Your Email *", "dexpress").'" name="email" value="'. esc_attr( $commenter['comment_author_email'] ) .'" '. ( $req ? 'aria-required="true"' : '' ).'></div></div>';
	
	$fields['url'] = '<div class="col-md-6"><div class="single_reply_box">
            <input type="text" class="website" placeholder="'. esc_attr__("Your Website", "dexpress").'" name="website" value="'. esc_attr( $commenter['comment_author_url'] ) .'" '. ( $req ? 'aria-required="false"' : '' ).'></div></div></div>';

	return $fields;
}
add_filter('comment_form_default_fields','dexpress_modify_comment_form_fields'); 

function dexpress_comment_reform ($arg) {

$arg['title_reply'] = esc_html__('Leave a Reply','dexpress');
$arg['comment_field'] = '<div class="row"><div class="col-md-12"><div class="single_reply_box">
    <textarea id="comment" class="comment_field" name="comment" cols="77" rows="8" placeholder="'. esc_html__("Write your Comment", "dexpress").'" aria-required="true">
    </textarea></div></div></div>';

return $arg;

}
add_filter('comment_form_defaults','dexpress_comment_reform');

function istyler_change_comment_textarea_position( $fields ) {
	$comment = array('comment' => $fields['comment'] );
	unset( $fields['comment'] );
	return array_merge( $fields, $comment );
}
add_filter( 'comment_form_fields', 'istyler_change_comment_textarea_position' );


//Add google map API
function dexpress_googlemap_api(){
	global $dexpress_opt;
	//Add google map API
	$google_map_js_url = 'https://maps.googleapis.com/maps/api/js?key=' . $dexpress_opt['map_apy_key'];
	return esc_url_raw($google_map_js_url);
}
//For enqueue google map script
function dexpress_googlemap_api_enqueue(){
	wp_enqueue_script( 'google-map', dexpress_googlemap_api(), array(), null );
    
    // Inline Map
    wp_add_inline_script('dexpress-main-js', dexpress_googlemap(),'after');
}

// Google map 
function dexpress_googlemap(){
	global $dexpress_opt; 
	$map_desc = str_replace(array("\r\n", "\r", "\n"), "<br />", $dexpress_opt['map_desc']);
	$map_desc = addslashes($map_desc);
	ob_start(); 
?>
        var myCenter=new google.maps.LatLng(<?php if(isset($dexpress_opt['map_lat'])) { echo esc_js($dexpress_opt['map_lat']); } else { echo '23.797868'; } ?>, <?php if(isset($dexpress_opt['map_long'])) { echo esc_js($dexpress_opt['map_long']); } else { echo '90.403470'; } ?>);
            function initialize()
            {
            var mapProp = {
              center:myCenter,
              zoom:<?php if(isset($dexpress_opt['map_zoom'])) { echo esc_js($dexpress_opt['map_zoom']); } else { echo 14; } ?>,
              scrollwheel:<?php if($dexpress_opt['map_scrollwheel'] == 0 ) { echo 'false'; } else { echo 'true'; } ?>,
              mapTypeId:google.maps.MapTypeId.ROADMAP,
                styles: [{"featureType":"water","elementType":"geometry","stylers":[{"color":"<?php echo esc_js($dexpress_opt['map_color']);?>"},{"lightness":17}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":20}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffffff"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#ffffff"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":16}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":21}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#dedede"},{"lightness":21}]},{"elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"lightness":16}]},{"elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#333333"},{"lightness":40}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#f2f2f2"},{"lightness":19}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#fefefe"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#fefefe"},{"lightness":17},{"weight":1.2}]}]
              };

            var map=new google.maps.Map(document.getElementById("contactgoogleMap"),mapProp);

            var marker=new google.maps.Marker({
              position:myCenter,
              animation:google.maps.Animation.BOUNCE,
              icon: '<?php echo get_template_directory_uri(); ?>'
            });
			var infowindow = new google.maps.InfoWindow({
				content: "<?php echo wp_kses($map_desc, array(
							'a' => array(
								'href' => array(),
								'title' => array()
							),
							'i' => array(
								'class' => array()
							),
							'img' => array(
								'src' => array(),
								'alt' => array()
							),
							'br' => array(),
							'em' => array(),
							'strong' => array(),
							'p' => array(),
						)); ?>"
			});
			infowindow.open(map,marker);

            marker.setMap(map);
            
            setTimeout(function(){
                jQuery('.gm-style-iw').parent().addClass('hello');
            },1000);
            }
			var mapContainer = jQuery('#contactgoogleMap');
			if(mapContainer.length){
				google.maps.event.addDomListener(window, 'load', initialize);
			}
	<?php return ob_get_clean();
}
