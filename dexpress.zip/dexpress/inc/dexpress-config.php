<?php

/**
  ReduxFramework Sample Config File
  For full documentation, please visit: https://docs.reduxframework.com
 * */

if (!class_exists('dexpress_Theme_Config')) {

    class dexpress_Theme_Config {
        public $args        = array();
        public $sections    = array();
        public $theme;
        public $ReduxFramework;

        public function __construct() {

            if (!class_exists('ReduxFramework')) {
                return;
            }

            // This is needed. Bah WordPress bugs.  ;)
            if (  true == Redux_Helpers::isTheme(__FILE__) ) {
                $this->initSettings();
            } else {
                add_action('plugins_loaded', array($this, 'initSettings'), 10);
            }
        }
        public function initSettings() {
            // Just for demo purposes. Not needed per say.
            $this->theme = wp_get_theme();

            // Set the default arguments
            $this->setArguments();

            // Set a few help tabs so you can see how it's done
            $this->setHelpTabs();

            // Create the sections and fields
            $this->setSections();

            if (!isset($this->args['opt_name'])) { // No errors please
                return;
            }
            $this->ReduxFramework = new ReduxFramework($this->sections, $this->args);
        }

        /**

          This is a test function that will let you see when the compiler hook occurs.
          It only runs if a field	set with compiler=>true is changed.

         * */
        function compiler_action($options, $css, $changed_values) {
            echo '<h1>The compiler hook has run!</h1>';
            echo "<pre>";
            print_r($changed_values); // Values that have changed since the last save
            echo "</pre>";
        }

        /**

          Custom function for filtering the sections array. Good for child themes to override or add to the sections.
          Simply include this function in the child themes functions.php file.

          NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
          so you must use get_template_directory_uri() if you want to use any of the built in icons

         * */
        function dynamic_section($sections) {
            //$sections = array();
            $sections[] = array(
                'title' => esc_html__('Section via hook', 'dexpress'),
                'desc' => '<p class="description">'.esc_html__('This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.', 'dexpress').'</p>',
                'icon' => 'el-icon-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }

        /**

          Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.

         * */
        function change_arguments($args) {
            return $args;
        }

        /**

          Filter hook for filtering the default value of any given field. Very useful in development mode.

         * */
        function change_defaults($defaults) {
            $defaults['str_replace'] = 'Testing filter hook!';

            return $defaults;
        }

        // Remove the demo link and the notice of integrated demo from the redux-framework plugin
        function remove_demo() {

            // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
            if (class_exists('ReduxFrameworkPlugin')) {
                remove_filter('plugin_row_meta', array(ReduxFrameworkPlugin::instance(), 'plugin_metalinks'), null, 2);

                // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                remove_action('admin_notices', array(ReduxFrameworkPlugin::instance(), 'admin_notices'));
				// If Redux is running as a plugin, this will remove the demo notice and links
				add_action( 'redux/plugin/hooks', array( $this, 'remove_demo' ) );				
            }
        }

        public function setSections() {

            ob_start();

            $ct             = wp_get_theme();
            $this->theme    = $ct;
            $item_name      = $this->theme->get('Name');
            $tags           = $this->theme->Tags;
            $screenshot     = $this->theme->get_screenshot();
            $class          = $screenshot ? 'has-screenshot' : '';

            $customize_title = sprintf(esc_html__('Customize &#8220;%s&#8221;', 'dexpress'), $this->theme->display('Name'));
            
            ?>
            <div id="current-theme" class="<?php echo esc_attr($class); ?>">
            <?php if ($screenshot) : ?>
                <?php if (current_user_can('edit_theme_options')) : ?>
                        <a href="<?php echo wp_customize_url(); ?>" class="load-customize hide-if-no-customize" title="<?php echo esc_attr($customize_title); ?>">
                            <img src="<?php echo esc_url($screenshot); ?>" alt="<?php esc_attr_e('Current theme preview', 'dexpress'); ?>" />
                        </a>
                <?php endif; ?>
                    <img class="hide-if-customize" src="<?php echo esc_url($screenshot); ?>" alt="<?php esc_attr_e('Current theme preview', 'dexpress'); ?>" />
                <?php endif; ?>

                <h4><?php echo esc_attr($this->theme->display('Name')); ?></h4>

                <div>
                    <ul class="theme-info">
                        <li><?php printf(esc_html__('By %s', 'dexpress'), $this->theme->display('Author')); ?></li>
                        <li><?php printf(esc_html__('Version %s', 'dexpress'), $this->theme->display('Version')); ?></li>
                        <li><?php echo '<strong>' . esc_html__('Tags', 'dexpress') . ':</strong> '; ?><?php printf($this->theme->display('Tags')); ?></li>
                    </ul>
                    <p class="theme-description"><?php echo esc_attr($this->theme->display('Description')); ?></p>
                </div>
            </div>

            <?php
            $item_info = ob_get_contents();

            ob_end_clean();
	
		// General
		$this->sections[] = array(
			'title'     => esc_html__('General', 'dexpress'),
			'desc'      => esc_html__('Use this section to select for general theme options', 'dexpress'),
			'icon'      => 'el-icon-cog',
			'fields'    => array(
				array(
					'id'        => 'logo_main',
					'type'      => 'media',
					'title'     => esc_html__('Logo', 'dexpress'),
					'subtitle'  => esc_html__('Logo Upload For Headerv1 & Headerv3.', 'dexpress'),
					'compiler'  => 'true',
					'mode'      => false,
					'desc'      => esc_html__('Upload logo here.', 'dexpress'),
                    
				),
				array(
					'id'        => 'logo-2_main',
					'type'      => 'media',
					'title'     => esc_html__('Logo', 'dexpress'),
					'subtitle'  => esc_html__('Logo Upload For Headerv2', 'dexpress'),
					'compiler'  => 'true',
					'mode'      => false,
					'desc'      => esc_html__('Upload logo here.', 'dexpress'),
                    
				),
				array(
					'id'        => 'welcome_text',
					'type'      => 'text',
					'title'     => esc_html__('Welcome Text', 'dexpress'),
					'subtitle'  => esc_html__('welcome text', 'dexpress'),
					'compiler'  => 'true',
					'mode'      => false,
					'desc'      => esc_html__('Header Top welcome Text', 'dexpress'),
                    'default'   => esc_html__('Welcome Text', 'dexpress'),
                    
				),
                array(
					'id'        => 'breadcrumb_bg_blog',
					'type'      => 'background',
					'output'    => array('.breadcrumb_area.blog-bdcmb'),
					'title'     => esc_html__('Breadcrumb Background Image', 'dexpress'),
					'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'dexpress'),
					'background-color'	=> false
				),
                array(
					'id'        => 'breadcrumb_bg_aboutus',
					'type'      => 'background',
					'output'    => array('.breadcrumb_area.about_us'),
					'title'     => esc_html__('Breadcrumb About Us', 'dexpress'),
					'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'dexpress'),
					'background-color'	=> false
				),
                array(
					'id'        => 'breadcrumb_bg_workpage',
					'type'      => 'background',
					'output'    => array('.breadcrumb_area.workpage'),
					'title'     => esc_html__('Breadcrumb Work', 'dexpress'),
					'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'dexpress'),
					'background-color'	=> false
				),
                array(
					'id'        => 'breadcrumb_bg_servicepage',
					'type'      => 'background',
					'output'    => array('.breadcrumb_area.servicepage'),
					'title'     => esc_html__('Breadcrumb Service Page', 'dexpress'),
					'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'dexpress'),
					'background-color'	=> false
				),
                array(
					'id'        => 'breadcrumb_bg_singleservicepage',
					'type'      => 'background',
					'output'    => array('.breadcrumb_area.singleservicepage'),
					'title'     => esc_html__('Breadcrumb Single Service Page', 'dexpress'),
					'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'dexpress'),
					'background-color'	=> false
				),
                array(
					'id'        => 'breadcrumb_bg_peoplepage',
					'type'      => 'background',
					'output'    => array('.breadcrumb_area.peoplepage'),
					'title'     => esc_html__('Breadcrumb People Page', 'dexpress'),
					'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'dexpress'),
					'background-color'	=> false
				),
                array(
					'id'        => 'breadcrumb_bg_workwithus',
					'type'      => 'background',
					'output'    => array('.breadcrumb_area.workwithus'),
					'title'     => esc_html__('Breadcrumb Work with Page', 'dexpress'),
					'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'dexpress'),
					'background-color'	=> false
				),
                array(
					'id'        => 'breadcrumb_bg_protfoliopage',
					'type'      => 'background',
					'output'    => array('.breadcrumb_area.protfoliopage'),
					'title'     => esc_html__('Breadcrumb Protfoliopage Page', 'dexpress'),
					'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'dexpress'),
					'background-color'	=> false
				),
                array(
					'id'        => 'breadcrumb_bg_singlework',
					'type'      => 'background',
					'output'    => array('.breadcrumb_area.singlework'),
					'title'     => esc_html__('Breadcrumb Work Single Page', 'dexpress'),
					'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'dexpress'),
					'background-color'	=> false
				),
                array(
					'id'        => 'breadcrumb_bg_playtime',
					'type'      => 'background',
					'output'    => array('.breadcrumb_area.playtime'),
					'title'     => esc_html__('Breadcrumb Play time Page', 'dexpress'),
					'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'dexpress'),
					'background-color'	=> false
				),
                array(
					'id'        => 'breadcrumb_bg_talkwith',
					'type'      => 'background',
					'output'    => array('.breadcrumb_area.talkwith'),
					'title'     => esc_html__('Breadcrumb Talk With Us Page', 'dexpress'),
					'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'dexpress'),
					'background-color'	=> false
				),
                array(
					'id'        => 'breadcrumb_bg_gallery',
					'type'      => 'background',
					'output'    => array('.breadcrumb_area.gallery'),
					'title'     => esc_html__('Breadcrumb Gallery Page', 'dexpress'),
					'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'dexpress'),
					'background-color'	=> false
				),
			),
		);
        //Bacground Color Image
		$this->sections[] = array(
			'title'     => esc_html__('Color Chage Option', 'dexpress'),
			'desc'      => esc_html__('Use this section to select options for footer options', 'dexpress'),
			'icon'      => 'el-icon-cog',
			'fields'    => array(
                array(
                    'id'        => 'background_primary_color',
                    'type'      => 'background',
                    'output'    => array('.mainmenu .sub-menu, .success_story_list li:hover .s_story_img::before, .single_tesm_slider:hover .tesm_desig, .btn_one, .section_title h3::after, .widget_title > h3::after,  .breadcrumb_content > h3::before, .widget.widget_search, .mainmenu > ul > li::before, .mainmenu > ul > li::after, .filter_list > li::before, .comment_title > h4::after, .comment-reply-title::after, .toolbar_bottom::after, .home2 .header_area::after, .mainmenu_area_fixed, .tabmenu li.active a, .tabmenu li:hover a, p.form-submit input'),
                    'title'     => esc_html__('Background Primary Color', 'dexpress'),
                    'subtitle'  => esc_html__('background color.', 'dexpress'),
                    'background-image' => false,
                    'background-repeat' => false,
                    'background-attachment' => false,
                    'background-position' => false,
                    'background-size' => false,
                    'default'  => array(
                        'background-color' => '#ed1c24',
                    )
                ),
                array(
                    'id'        => 'rgba_background_color',
                    'type'      => 'background',
                    'output'    => array('.counterup_area::before'),
                    'title'     => esc_html__('Background RGBA Color', 'dexpress'),
                    'subtitle'  => esc_html__('Like Color', 'dexpress'),
                    'background-image' => false,
                    'background-repeat' => false,
                    'background-attachment' => false,
                    'background-position' => false,
                    'background-size' => false,
                    'default'  => array(
                        'background-color' => 'rgba(0, 175, 233, 0.85) none repeat scroll 0 0',

                    )
                ),
				array(
					'id'        => 'element_color',
					'type'      => 'color',
					'output'    => array('.mainmenu li.current-menu-item a, .widget_desc a i, .widget_contact .widget_desc a i, .widget_desc a:hover, .mainmenu li a:hover, .service_content h4:hover a, .filter_list > li.active, .post_title h4:hover a, .post_btn > a:hover, .blog-detail .post_title > h4, .comment_title > h4, .comment-reply-title, .post_share li a, .logged-in-as a'),
					'title'     => esc_html__('Change All Color', 'dexpress'),
					'subtitle'  => esc_html__('Like i, h5, span, Color', 'dexpress'),
					'default'   => '#ed1c24'
				),
				array(
					'id'        => 'border_left',
					'type'      => 'border',
					'output'    => array('.about_text > p, .aboutpg_text'),
					'title'     => esc_html__('Border Left', 'dexpress'),
					'subtitle'  => esc_html__('Change Color about text Paragraph', 'dexpress'),
					'default'  => array(
                        'border-color'  => '#ed1c24', 
                        'border-style'  => 'solid',
                        'border-left'   => '3px'
                    )
				),
                array(
					'id'        => 'border_lrb',
					'type'      => 'border',
					'output'    => array(''),
					'title'     => esc_html__('Border Left Right Bottom', 'dexpress'),
					'subtitle'  => esc_html__('This border only for left, right and bottom position.', 'dexpress'),
					'default'  => array(
                        'border-color'  => '#ed1c24', 
                        'border-style'  => 'solid',
                        'border-right'  => '3px', 
                        'border-bottom' => '3px', 
                        'border-left'   => '3px'
                    )
				),
				array(
					'id'        => 'border_lt',
					'type'      => 'border',
					'output'    => array('.about_next_plan_img::before'),
					'title'     => esc_html__('Border Left Top 10px', 'dexpress'),
					'subtitle'  => esc_html__('About Us Next Plan Image Border', 'dexpress'),
					'default'  => array(
                        'border-color'  => '#ed1c24', 
                        'border-style'  => 'solid',
                        'border-top'  => '10px',  
                        'border-left'   => '10px'
                    )
				),
				array(
					'id'        => 'border_rb',
					'type'      => 'border',
					'output'    => array('.about_next_plan_img::after'),
					'title'     => esc_html__('Border Right Bottom 10px', 'dexpress'),
					'subtitle'  => esc_html__('About Us Next Plan Image Border', 'dexpress'),
					'default'  => array(
                        'border-color'  => '#ed1c24', 
                        'border-style'  => 'solid',
                        'border-bottom'  => '10px',  
                        'border-right'   => '10px'
                    )
				),
				array(
					'id'        => 'border_top',
					'type'      => 'border',
					'output'    => array('figure.team_member::after'),
					'title'     => esc_html__('Change Team Member Border Color', 'dexpress'),
					'subtitle'  => esc_html__('Change Team Member Border Top', 'dexpress'),
					'default'  => array(
                        'border-color'  => '#ed1c24', 
                        'border-style'  => 'solid', 
                        'border-top'    => '3px'
                    )
				),
                array(
					'id'        => 'border_around',
					'type'      => 'border',
					'output'    => array('.single_tesm_slider:hover .tesm_img, .single_tesm_slider:hover, .single_tesm_slider:hover .tesm_img'),
					'title'     => esc_html__('Border Around', 'dexpress'),
					'subtitle'  => esc_html__('Change Member Border', 'dexpress'),
					'default'  => array(
                        'border-color'  => '#ed1c24', 
                        'border-style'  => 'solid',
                        'border-top'    => '1px', 
                        'border-right'  => '1px', 
                        'border-bottom' => '1px', 
                        'border-left'   => '1px'
                    )
				),
                
			),
		);    
        //Header
		$this->sections[] = array(
			'title'     => esc_html__('Header', 'dexpress'),
			'desc'      => esc_html__('Use this section to select for header options', 'dexpress'),
			'icon'      => 'el-icon-tasks',
            'fields'    => array(
                array(
					'id'        => 'header_layout',
					'type'      => 'select',
					'title'     => esc_html__('Header Layout', 'dexpress'),
					'customizer_only'   => false,

					//Must provide key => value pairs for select options
					'options'   => array(
						'v1' => esc_html__('Default' , 'dexpress'),
						'v2' => esc_html__('Second' , 'dexpress'),
					),
					'default'   => 'v1',
				),
            )
		);
		//Header Top
		$this->sections[] = array(
			'title'     => esc_html__('Header Top', 'dexpress'),
			'desc'      => esc_html__('Use this section to select options for header top bar.', 'dexpress'),
			'icon'      => 'el-icon-tasks',
			'subsection'=> true,
			'fields'    => array(			
				array(
					'id'        => 'show_header_top_bar',
					'type'     => 'switch',
					'title'    => esc_html__('Header Top Bar', 'dexpress'),
					'subtitle'	=> esc_html__('Show & Hide header top bar.', 'dexpress'),
					'default'  => true,
				),
				array(
					'id'        => 'background_top_header',
					'type'      => 'background',
					'output'    => array('.tiny_header'),
					'title'     => esc_html__('Header Topbar Background', 'dexpress'),
					'subtitle'  => esc_html__('Header Topbar background with image, color.', 'dexpress'),
					'default'  => array(
						'background-color' => '#FFF',
					)
				),
				array(
					'id'        => 'top_bar_phone',
					'type'      => 'text',
					'title'     => esc_html__('Phone Number', 'dexpress'),
					'subtitle'	=> esc_html__('Enter phone number at top bar.', 'dexpress'),
					'default'   => esc_html__('0123(1234)7894', 'dexpress'),
				),
				array(
					'id'        => 'phone_text',
					'type'      => 'text',
					'title'     => esc_html__('Day Time', 'dexpress'),
					'subtitle'	=> esc_html__('Enter Your Day and Time.', 'dexpress'),
					'default'   => esc_html__('Monday-Friday, 8am - 8pm', 'dexpress'),
				),
				array(
					'id'        => 'top_bar_email',
					'type'      => 'text',
					'title'     => esc_html__('Email Address', 'dexpress'),
					'subtitle'	=> esc_html__('Enter email address at top bar.', 'dexpress'),
					'default'   => esc_html__('youremail@example.com', 'dexpress'),
				),
				array(
					'id'        => 'email_text',
					'type'      => 'text',
					'title'     => esc_html__('About Email Address', 'dexpress'),
					'subtitle'	=> esc_html__('Enter email address at top bar.', 'dexpress'),
					'default'   => esc_html__('Drop us a line anytime!', 'dexpress'),
				),
				array(
					'id'        => 'adress_line1',
					'type'      => 'text',
					'title'     => esc_html__('Adress Line 1', 'dexpress'),
					'subtitle'	=> esc_html__('Enter Address Line1.', 'dexpress'),
					'default'   => esc_html__('724 Woodland Road ', 'dexpress'),
				),
				array(
					'id'        => 'adress_line2',
					'type'      => 'text',
					'title'     => esc_html__('Adress Line 2', 'dexpress'),
					'subtitle'	=> esc_html__('724 Woodland Road ', 'dexpress'),
					'default'   => esc_html__('Marlton, NJ 08053', 'dexpress'),
				),
				array(
					'id'       => 'topbar_social_icons',
					'type'     => 'sortable',
					'title'    => esc_html__('Social Icons', 'careunit'),
					'subtitle' => esc_html__('Enter social links at top bar.', 'careunit'),
					'desc'     => esc_html__('Drag/drop to re-arrange', 'careunit'),
					'mode'     => 'text',
					'options'  => array(
						'facebook'     => 'facebook',
						'twitter'     => 'twitter',
						'instagram'	=> 'instagram',
						'tumblr'     => 'tumblr',
						'pinterest'     => 'pinterest',
						'google-plus'     => 'google-plus',
						'linkedin'     => 'linkedin',
						'behance'     => 'behance',
						'dribbble'     => 'dribbble',
						'youtube'     => 'youtube',
						'vimeo'     => 'vimeo',
						'rss'     => 'rss'
					),
					
				)
			),
		);
        //Footer
		$this->sections[] = array(
			'title'     => esc_html__('Footer', 'dexpress'),
			'desc'      => esc_html__('Use this section to select options for footer options', 'dexpress'),
			'icon'      => 'el-icon-cog',
			'fields'    => array(
				array(
					'id'        => 'background_footer_color',
					'type'      => 'background',
					'output'    => array('.footer_top::before'),
					'title'     => esc_html__('Footer Background', 'dexpress'),
					'subtitle'  => esc_html__('Footer background color.', 'dexpress'),
					'background-image' => false,
					'background-repeat' => false,
					'background-attachment' => false,
					'background-position' => false,
					'background-size' => false,
					'default'  => array(
						'background-color' => 'rgba(8, 8, 8, 0.97)',
						
					)
				),
				array(
					'id'        => 'background_footer',
					'type'      => 'background',
					'output'    => array('.footer_top_area'),
					'title'     => esc_html__('Footer Background', 'dexpress'),
					'subtitle'  => esc_html__('Header background with image.', 'dexpress'),
					'background-color' => false,
				)
			),
		);
        $this->sections[] = array(
        'icon'       => 'el-icon-website',
        'title'      => esc_html__( 'Newsletter', 'dexpress' ),
        'subsection' => true,
        'fields'     => array(
            array(
                 'id'        => 'newsletter_title',
                 'type'      => 'text',
                 'title'     => esc_html__('Newsletter title', 'dexpress'),
                 'default'   => 'Newsletter'
            ),
            array(
                 'id'        => 'newsletter_description',
                 'type'      => 'textarea',
                 'title'     => esc_html__('Newsletter Description', 'dexpress'),
                 'default'   => 'Set Description'
            ),
            array(
                 'id'       => 'newsletter_form',
                 'type'     => 'text',
                 'title'    => esc_html__('Newsletter form ID', 'dexpress'),
                 'subtitle' => esc_html__('The form ID of MailPoet plugin.', 'dexpress')
                ),
           )
        );
        
		//Footer Copyright
		$this->sections[] = array(
			'title'     => esc_html__('Copyright', 'dexpress'),
			'desc'      => esc_html__('Use this section to select options for copyright.', 'dexpress'),
			'icon'      => 'el-icon-cog',
			'subsection'=> true,
			'fields'    => array(
				array(
					'id'        => 'background_footer_copyright',
					'type'      => 'background',
					'output'    => array('.tiny_footer'),
					'title'     => esc_html__('Footer Copyright Background', 'dexpress'),
					'subtitle'  => esc_html__('Footer Copyright background color with image.', 'dexpress'),
					'default'  => array(
						'background-color' => '#0e181e',
						
					)
				),	
				array(
					'id'      	=> 'copyright',
					'type'    	=> 'editor',
					'title'   	=> esc_html__('Copyright information', 'dexpress'),
					'subtitle'	=> esc_html__('HTML tags allowed: a, br, em, strong', 'dexpress'),
					'default'	=> esc_html__('Copyright 2017 dexpress Business. All Rights Reserved' , 'dexpress'),
					'args' 		=> array(
						'teeny'            => true,
						'textarea_rows'    => 5,
						'media_buttons'	=> false,
					)
				),				
				array(
					'id'      	=> 'footerright',
					'type'    	=> 'editor',
					'title'   	=> esc_html__('Athour Name', 'dexpress'),
					'subtitle'	=> esc_html__('HTML tags allowed: a, br, em, strong', 'dexpress'),
					'default'	=> esc_html__('Developed by ' , 'dexpress')." <a href='".esc_url('themeebit.com', 'dexpress')."' target='_blank'>".esc_html__('ThemeeBiT.' , 'dexpress')."</a> ",
					'args' 		=> array(
						'teeny'            => true,
						'textarea_rows'    => 5,
						'media_buttons'	=> false,
					)
				),
				array(
					'id'       => 'footer_social_icons',
					'type'     => 'sortable',
					'title'    => esc_html__('Social Icons', 'dexpress'),
					'subtitle' => esc_html__('Enter social links at footer.', 'dexpress'),
					'desc'     => esc_html__('Drag/drop to re-arrange', 'dexpress'),
					'mode'     => 'text',
					'options'  => array(
						'facebook'     => 'facebook',
						'twitter'     => 'twitter',
						'instagram'	=> 'instagram',
						'tumblr'     => 'tumblr',
						'pinterest'     => 'pinterest',
						'googleplus'     => 'googleplus',
						'linkedin'     => 'linkedin',
						'behance'     => 'behance',
						'dribbble'     => 'dribbble',
						'youtube'     => 'youtube',
						'vimeo'     => 'vimeo',
						'rss'     => 'rss',
					),
					'default' => array(
						'facebook'		=> 'http://facebook.com/',
						'twitter'		=> 'https://twitter.com/',
						'instagram'		=> '',
						'tumblr'     	=> '',
						'pinterest'     => 'https://uk.pinterest.com/',
						'googleplus'   => 'https://plus.google.com/',
						'linkedin'   	=> 'https://www.linkedin.com/',
						'behance'     	=> '',
						'dribbble'    	=> '',
						'youtube'   	=> '',
						'vimeo'    		=> '',
						'rss'    		=> '',
					),
				),

			),
		);
	
		// Sidebar
		$this->sections[] = array(
			'title'     => esc_html__('Sidebar', 'dexpress'),
			'desc'      => esc_html__('Use this section to select for Sidebar options', 'dexpress'),
			'icon'      => 'el-icon-cog',
			'fields'    => array(
				array(
					'id'        => 'blog_layout',
					'type'      => 'select',
					'title'     => esc_html__('Blog Layout', 'dexpress'),
					'customizer_only'   => false,
					'options'   => array(
						'nosidebar' => esc_html__('No Sidebar', 'dexpress'),
						'sidebar' => esc_html__('Sidebar', 'dexpress'),
					),
					'default'   => esc_html__('sidebar', 'dexpress')
				),
				array(
					'id'       => 'sidebarblog_pos',
					'type'     => 'radio',
					'title'    => esc_html__('Blog Sidebar Position', 'dexpress'),
					'subtitle' => esc_html__('Sidebar on Blog pages', 'dexpress'),
					'options'  => array(
						'left' => esc_html__('Left', 'dexpress'),
						'right' => esc_html__('Right', 'dexpress')
					),
					'default'  => esc_html__('right', 'dexpress')
				),
				array(
					'id'        => 'single_blog_layout',
					'type'      => 'select',
					'title'     => esc_html__('Single Blog Layout', 'dexpress'),
					'customizer_only'   => false,
					'options'   => array(
						'nosidebar' => esc_html__('No Sidebar', 'dexpress'),
						'sidebar' => esc_html__('Sidebar', 'dexpress'),
					),
					'default'   => esc_html__('sidebar', 'dexpress')
				),
				array(
					'id'       => 'sidebar_single_blog_pos',
					'type'     => 'radio',
					'title'    => esc_html__('Single Blog Sidebar Position', 'dexpress'),
					'subtitle' => esc_html__('Sidebar on Single Blog pages', 'dexpress'),
					'options'  => array(
						'left' => esc_html__('Left', 'dexpress'),
						'right' => esc_html__('Right', 'dexpress')
					),
					'default'  => esc_html__('right', 'dexpress')
				),
			),
		);
	
		// Blog options
		$this->sections[] = array(
			'title'     => esc_html__('Blog', 'dexpress'),
			'desc'      => esc_html__('Use this section to select options for blog', 'dexpress'),
			'icon'      => 'el-icon-file',
			'fields'    => array(
                array(
					'id'        => 'blog_breadcrumb_titlee',
					'type'      => 'text',
					'title'     => esc_html__('Blog Title', 'dexpress'),
					'default'   => esc_html__('Blog Title', 'dexpress')
				),
                array(
					'id'        => 'readmore_text',
					'type'      => 'text',
					'title'     => esc_html__('Read more text', 'dexpress'),
					'default'   => esc_html__('Read More', 'dexpress')
				),
				array(
					'id'        => 'excerpt_length',
					'type'      => 'slider',
					'title'     => esc_html__('Excerpt length on blog page', 'dexpress'),
					"default"   => 16,
					"min"       => 10,
					"step"      => 2,
					"max"       => 120,
					'display_value' => 'text'
				),
                array(
					'id'        => 'breadcrumb_bg_blog_single',
					'type'      => 'background',
					'output'    => array('.breadcrumb_area.blog_single'),
					'title'     => esc_html__('Breadcrumb Blog Single', 'dexpress'),
					'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'dexpress'),
					'background-color'	=> false
				),
			),
		);
		//Partner logos
		$this->sections[] = array(
			'title'     => esc_html__('Partner Logos', 'dexpress'),
			'desc'      => esc_html__('Upload partner logos and links.', 'dexpress'),
			'icon'      => 'el-icon-briefcase',
			'fields'    => array(
				array(
					'id'        => 'partnernumber',
					'type'      => 'slider',
					'title'     => esc_html__('Number of partner logo per page', 'dexpress'),
					'desc'      => esc_html__('Number of partner logos per page, default value: 6', 'dexpress'),
					"default"   => 6,
					"min"       => 1,
					"step"      => 1,
					"max"       => 12,
					'display_value' => 'text'
				),
				array(
					'id'       => 'partnerscroll',
					'type'     => 'switch',
					'title'    => esc_html__('Auto scroll', 'dexpress'),
					'default'  => true,
				),
				array(
					'id'          => 'partner_logos',
					'type'        => 'slides',
					'title'       => esc_html__('Logos', 'dexpress'),
					'desc'        => esc_html__('Upload logo image and enter logo link.', 'dexpress'),
					'placeholder' => array(
						'title'           => esc_html__('Title', 'dexpress'),
						'description'     => esc_html__('Description', 'dexpress'),
						'url'             => esc_html__('Link', 'dexpress'),
					),
				),
			),
        );
		
		//Testimonial Page
		$this->sections[] = array(
			'title'     => esc_html__('Testimonial Page', 'dexpress'),
			'desc'      => esc_html__('Testimonial Page Setting', 'dexpress'),
			'icon'      => 'el-icon-briefcase',
			'fields'    => array(
				array(
					'id'        => 'testimonialnumber',
					'type'      => 'slider',
					'title'     => esc_html__('Number of post per page', 'dexpress'),
					'desc'      => esc_html__('Number of post per page, default value: 8', 'dexpress'),
					"default"   => 8,
					"min"       => 1,
					"step"      => 1,
					"max"       => 12,
					'display_value' => 'text'
				),
				array(
					'id'       => 'enable_partner_slider',
					'type'     => 'switch',
					'title'    => esc_html__('Show/Hide Partner Slider', 'dexpress'),
					'default'  => true,
				),
			),
        );
	
		//404 Not Found Page
		$this->sections[] = array(
			'title'     => esc_html__('404 Error Page', 'dexpress'),
			'desc'      => esc_html__('Not Found Page Setting', 'dexpress'),
			'icon'      => 'el-icon-briefcase',
			'fields'    => array(
				array(
					'id'       => 'breadcrumb_on_off_error',
					'type'     => 'switch',
					'title'    => esc_html__('Breadcrumb Switch', 'dexpress'),
					'subtitle'  => esc_html__('Breadcrumb show & hide switch', 'dexpress'),
					'default'  => true,
				),
				array(
					'id'        => 'breadcrumb_bg_error',
					'type'      => 'background',
					'output'    => array('.breadcrumb.error-page'),
					'title'     => esc_html__('Breadcrumb Background Image', 'dexpress'),
					'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'dexpress'),
					'background-color'	=> false
				),
				array(
					'id'        => 'notfound_title',
					'type'      => 'text',
					'title'     => esc_html__('404 Not Found Title', 'dexpress'),
					'default'  	=> esc_html__('Oops! That page can\'t be found.', 'dexpress'),
				),
				array(
					'id'       => 'notfound_content',
					'type'     => 'text',
					'title'    => esc_html__('404 Not Found Content', 'dexpress'),
					'default'  => esc_html__('It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'dexpress'),
				),
                
				array(
					'id'        => 'not_foundimg',
					'type'      => 'media',
					'title'     => esc_html__('Not Found Image', 'dexpress'),
					'subtitle'  => esc_html__('Error Image', 'dexpress'),
					'compiler'  => 'true',
					'mode'      => false,
					'desc'      => esc_html__('Upload Error Image here', 'dexpress'),
                    
				),
			),
        );
			
		// Contact Map
        $this->sections[] = array(
			'title'     => esc_html__('Google Map', 'dexpress'),
			'desc'      => esc_html__('Use this section to select options for Google Map on contact page', 'dexpress'),
			'icon'      => 'el-icon-map-marker',
			'fields'    => array(
				array(
					'id'        => 'map_apy_key',
					'type'      => 'text',
					'title'     => esc_html__('Google API Key', 'dexpress'),
					'subtitle'	=>  '<a target="_blank" href="'.esc_url('https://developers.google.com/maps/documentation/javascript/get-api-key', 'dexpress').'">'.esc_html__('Click Here', 'dexpress').'</a> '.esc_html__('to Get a Google Maps API KEY', 'dexpress').'', 
				),
				array(
					'id'        => 'contact_form',
					'type'      => 'text',
					'title'     => esc_html__('Contact Form', 'dexpress'),
				),
				array(
					'id'               => 'map_desc',
					'type'             => 'editor',
					'title'    => esc_html__('Map description', 'dexpress'),
					'subtitle' => esc_html__('The text on map popup', 'dexpress'),
					'default'  => esc_html__('We are here', 'dexpress'),
					'args'   => array(
						'teeny'            => true,
						'textarea_rows'    => 5,
						'media_buttons'	=> false,
					)
				),
				array(
					'id'        => 'map_lat',
					'type'      => 'text',
					'title'     => esc_html__('Latitude', 'dexpress'),
					'default'   => '23.763762'
				),
				array(
					'id'        => 'map_long',
					'type'      => 'text',
					'title'     => esc_html__('Longtitude', 'dexpress'),
					'default'   => esc_html__('90.4311185', 'dexpress'),
				),
				array(
					'id'        => 'map_zoom',
					'type'      => 'slider',
					'title'     => esc_html__('Zoom level', 'dexpress'),
					"default"   => 17,
					"min"       => 0,
					"step"      => 1,
					"max"       => 21,
					'display_value' => 'text'
				),
				array(
					'id'        => 'map_color',
					'type'      => 'color',
					'title'     => esc_html__('Map Color', 'dexpress'),
					'default'   => '#26bdef',
				),
				array(
					'id'        => 'map_scrollwheel',
					'type'      => 'switch',
					'title'     => esc_html__('Scroll Wheel', 'dexpress'),
					'desc'      => esc_html__('Switch scrollwheel On/Off', 'dexpress'),
					'default'=> 0,
				),
			),
        );
		// Less Compiler
		$this->sections[] = array(
			'title'     => esc_html__('Less Compiler', 'dexpress'),
			'desc'      => esc_html__('Turn on this option to apply all theme options. Turn of when you have finished changing theme options and your site is ready.', 'dexpress'),
			'icon'      => 'el-icon-wrench',
			'fields'    => array(
				array(
					'id'        => 'enable_less',
					'type'      => 'switch',
					'title'     => esc_html__('Enable Less Compiler', 'dexpress'),
					'default'   => true,
				),
			),
		);

            $this->sections[] = array(
                'title'     => esc_html__('Import / Export', 'dexpress'),
                'desc'      => esc_html__('Import and Export your Redux Framework settings from file, text or URL.', 'dexpress'),
                'icon'      => 'el-icon-refresh',
                'fields'    => array(
                    array(
                        'id'            => 'opt-import-export',
                        'type'          => 'import_export',
                        'title'         => 'Import Export',
                        'subtitle'      => 'Save and restore your Redux options',
                        'full_width'    => false,
                    ),
                ),
            );

            $this->sections[] = array(
                'icon'      => 'el-icon-info-sign',
                'title'     => esc_html__('Theme Information', 'dexpress'),
				'icon'      => 'el-icon-website',
                'fields'    => array(
                    array(
                        'id'        => 'opt-raw-info',
                        'type'      => 'raw',
                        'content'   => $item_info,
                    )
                ),
            );
        }

        public function setHelpTabs() {

            // Custom page help tabs, displayed using the help API. Tabs are shown in order of definition.
            $this->args['help_tabs'][] = array(
                'id'        => 'redux-help-tab-1',
                'title'     => esc_html__('Theme Information 1', 'dexpress'),
                'content'   => '<p>'.esc_html__('This is the tab content, HTML is allowed.', 'dexpress').'</p>'
            );

            $this->args['help_tabs'][] = array(
                'id'        => 'redux-help-tab-2',
                'title'     => esc_html__('Theme Information 2', 'dexpress'),
                'content'   => '<p>'.esc_html__('This is the tab content, HTML is allowed.', 'dexpress').'</p>'
            );

            // Set the help sidebar
            $this->args['help_sidebar'] = '<p>'.esc_html__('This is the sidebar content, HTML is allowed.', 'dexpress').'</p>';
        }

        /**

          All the possible arguments for Redux.
          For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments

         * */
        public function setArguments() {

            $theme = wp_get_theme(); // For use with some settings. Not necessary.

            $this->args = array(
                // TYPICAL -> Change these values as you need/desire
                'opt_name'          => 'dexpress_opt',        // This is where your data is stored in the database and also becomes your global variable name.
                'display_name'      => $theme->get('Name'),     // Name that appears at the top of your panel
                'display_version'   => $theme->get('Version'),  // Version that appears at the top of your panel
                'menu_type'         => 'menu',                  //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
                'allow_sub_menu'    => true,                    // Show the sections below the admin menu item or not
                'menu_title'        => esc_html__('Theme Options', 'dexpress'),
                'page_title'        => esc_html__('Theme Options', 'dexpress'),
                
                // You will need to generate a Google API key to use this feature.
                // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
                'google_api_key' => '', // Must be defined to add google fonts to the typography module
                
                'async_typography'  => true,                    // Use a asynchronous font on the front end or font string
                //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
                'admin_bar'         => true,                    // Show the panel pages on the admin bar
                'global_variable'   => '',                      // Set a different name for your global variable other than the opt_name
                'dev_mode'          => false,                    // Show the time the page took to load, etc
                'customizer'        => true,                    // Enable basic customizer support
                //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
                //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

                // OPTIONAL -> Give you extra features
                'page_priority'     => null,                    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
                'page_parent'       => 'themes.php',            // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
                'page_permissions'  => 'manage_options',        // Permissions needed to access the options panel.
                'menu_icon'         => '',                      // Specify a custom URL to an icon
                'last_tab'          => '',                      // Force your panel to always open to a specific tab (by id)
                'page_icon'         => 'icon-themes',           // Icon displayed in the admin panel next to your menu_title
                'page_slug'         => '_options',              // Page slug used to denote the panel
                'save_defaults'     => true,                    // On load save the defaults to DB before user clicks save or not
                'default_show'      => false,                   // If true, shows the default value next to each field that is not the default value.
                'default_mark'      => '',                      // What to print by the field's title if the value shown is default. Suggested: *
                'show_import_export' => true,                   // Shows the Import/Export panel when not used as a field.
                
                // CAREFUL -> These options are for advanced use only
                'transient_time'    => 60 * MINUTE_IN_SECONDS,
                'output'            => true,                    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
                'output_tag'        => true,                    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
                // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.
                
                // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
                'database'              => '', // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
                'system_info'           => false, // REMOVE

                // HINTS
                'hints' => array(
                    'icon'          => 'icon-question-sign',
                    'icon_position' => 'right',
                    'icon_color'    => 'lightgray',
                    'icon_size'     => 'normal',
                    'tip_style'     => array(
                        'color'         => 'light',
                        'shadow'        => true,
                        'rounded'       => false,
                        'style'         => '',
                    ),
                    'tip_position'  => array(
                        'my' => 'top left',
                        'at' => 'bottom right',
                    ),
                    'tip_effect'    => array(
                        'show'          => array(
                            'effect'        => 'slide',
                            'duration'      => '500',
                            'event'         => 'mouseover',
                        ),
                        'hide'      => array(
                            'effect'    => 'slide',
                            'duration'  => '500',
                            'event'     => 'click mouseleave',
                        ),
                    ),
                )
            );


            // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
            $this->args['share_icons'][] = array(
                'url'   => 'https://github.com/ReduxFramework/ReduxFramework',
                'title' => 'Visit us on GitHub',
                'icon'  => 'el-icon-github'
                //'img'   => '', // You can use icon OR img. IMG needs to be a full URL.
            );
            $this->args['share_icons'][] = array(
                'url'   => 'https://www.facebook.com/pages/Redux-Framework/243141545850368',
                'title' => 'Like us on Facebook',
                'icon'  => 'el-icon-facebook'
            );
            $this->args['share_icons'][] = array(
                'url'   => 'http://twitter.com/reduxframework',
                'title' => 'Follow us on Twitter',
                'icon'  => 'el-icon-twitter'
            );
            $this->args['share_icons'][] = array(
                'url'   => 'http://www.linkedin.com/company/redux-framework',
                'title' => 'Find us on LinkedIn',
                'icon'  => 'el-icon-linkedin'
            );

            // Panel Intro text -> before the form
            if (!isset($this->args['global_variable']) || $this->args['global_variable'] !== false) {
                if (!empty($this->args['global_variable'])) {
                    $v = $this->args['global_variable'];
                } else {
                    $v = str_replace('-', '_', $this->args['opt_name']);
                }
            } else {}
        }
    }
    global $reduxConfig;
    $reduxConfig = new dexpress_Theme_Config();
}

/**
  Custom function for the callback referenced above
 */
if (!function_exists('redux_my_custom_field')):
    function redux_my_custom_field($field, $value) {
        print_r($field);
        echo '<br/>';
        print_r($value);
    }
endif;

/**
  Custom function for the callback validation referenced above
 * */
if (!function_exists('redux_validate_callback_function')):
    function redux_validate_callback_function($field, $value, $existing_value) {
        $error = false;
        $value = 'just testing';
        $return['value'] = $value;
        if ($error == true) {
            $return['error'] = $field;
        }
        return $return;
    }
endif;
