<?php

add_action( 'cmb2_admin_init', 'dexpress_metabox' );

function dexpress_metabox() {

	$prefix = '_dexpress_';
    // metabox for page slider or banner
	$cmb2_pagesidebar = new_cmb2_box( array(
		'id'           => $prefix . 'page_header_optons',
		'title'        => esc_html__( 'Page Settings', 'dexpress' ),
		'object_types' => array( 'page'), // Post type
        'show_on_cb' => 'dexpress_metabox_exclude_blog_page',
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );
    
    // metabox for page slider or banner
	$cmb2_headerfooter = new_cmb2_box( array(
		'id'           => $prefix . 'page_header_optons',
		'title'        => esc_html__( 'Page Settings', 'dexpress' ),
		'object_types' => array( 'page'), // Post type
        'show_on_cb' => 'dexpress_metabox_exclude_blog_page',
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );

	$cmb2_headerfooter->add_field( array(
	    'name'             =>  esc_html__( 'Select Header', 'dexpress' ),
	    'id'               => $prefix . 'page_header',
	    'desc'             => esc_html__( 'Select any one. which you want to display','dexpress' ),
	    'type'             => 'select',
	    'default'          => '1',
	    'options'          => array(
	        '1' => esc_html__( 'Header v1', 'dexpress' ),
	        '2'   => esc_html__( 'Header v2', 'dexpress' ),
	    ),
	) );
    // metabox support for dexpress portfolio
	$cmb2_dexpressservice = new_cmb2_box( array(
		'id'           => $prefix . 'service_area',
		'title'        => esc_html__( 'Service Images', 'dexpress' ),
		'object_types' => array( 'dexpress-service'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );
	$cmb2_dexpressservice->add_field( array(
    'name'    =>  esc_html__( 'Client Name Field', 'dexpress' ),
	    'id'      =>  $prefix . 'serviceimge',
	    'type'    =>  'file',
	) );
    // metabox support for dexpress portfolio
	$cmb2_dexpressportfolio = new_cmb2_box( array(
		'id'           => $prefix . 'portfolio_area',
		'title'        => esc_html__( 'Client Name', 'dexpress' ),
		'object_types' => array( 'dexpress-work'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );
	$cmb2_dexpressportfolio->add_field( array(
    'name'    =>  esc_html__( 'Client Name Field', 'dexpress' ),
	    'id'      =>  $prefix . 'client_name',
	    'type'    =>  'text',
        'repeatable' => true,
	) );
	$cmb2_dexpressportfolio->add_field( array(
    'name'    =>  esc_html__( 'Protfolio Link', 'dexpress' ),
	    'id'      =>  $prefix . 'protfolioLink',
	    'type'    =>  'text_url',
	) );
	$cmb2_dexpressportfolio->add_field( array(
    'name'    =>  esc_html__( 'Protfolio Image', 'dexpress' ),
	    'id'      =>  $prefix . 'protfolioimg',
	    'type'    =>  'file',
	) );
    // metabox support for dexpress Project
	$cmb2_testimonil = new_cmb2_box( array(
		'id'           => $prefix . 'testimonial_area',
		'title'        => esc_html__( 'dexpress Testimonial Settings', 'dexpress' ),
		'object_types' => array( 'dexpress_testimonial'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );

	$cmb2_testimonil->add_field( array(
	    'name'    =>  esc_html__( 'Client Designation', 'dexpress' ),
	    'id'      =>  $prefix . 'client_desig',
	    'type'    =>  'text',
	    'default' =>  esc_html__( 'CEO, Kutumbari', 'dexpress' ),
	) );
    
    // metabox support for dexpress Advisore
	$cmb2_advisore = new_cmb2_box( array(
		'id'           => $prefix . 'advisore_area',
		'title'        => esc_html__( 'Advisore Settings', 'dexpress' ),
		'object_types' => array( 'dexpress-team'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );
	$cmb2_advisore->add_field( array(
	    'name'    => esc_html__( 'Advisore Designation', 'dexpress' ),
	    'id'      =>  $prefix.'team_designation',
	    'type'    => 'text',
		'default' =>  esc_html__( 'CEO, Kutumbari', 'dexpress' ),
	));
    $team_social_group = $cmb2_advisore->add_field( array(
	    'name'    =>  esc_html__( 'Team Social Icon', 'dexpress' ),
	    'id'      =>  $prefix . 'team_social_icon',
        'type'       => 'group'
	) );
	$cmb2_advisore->add_group_field($team_social_group, array(
	    'name'    => esc_html__( 'Team Social Icon Link', 'dexpress' ),
	    'id'      =>  $prefix.'socialicon_link',
	    'type'    => 'text_url',
        'desc' => esc_html__( 'Use http, https before link', 'dexpress' )
	));	
    $cmb2_advisore->add_group_field($team_social_group, array(
	    'name'    => esc_html__( 'Team Social Icon Name', 'dexpress' ),
	    'id'      =>  $prefix.'socialicon_name',
	    'type'    => 'text'
	));
    

}

