<?php 
/**
 * Adds About address Widget.
 */

class dexpress_address_Widget extends WP_Widget{
	/**
	 * Register widget with WordPress.
    */
	function __construct(){

		$widget_ops = array( 'address' => esc_html__('About address.', 'dexpress'),'customize_selective_refresh' => true, );
 		parent:: __construct('dexpress_address_Widget', esc_html__('dexpress: Address', 'dexpress'),$widget_ops );
	}
	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $subvalue Saved values from database.
	 */
	public function widget($args, $subvalue){
		$wid_addressTitle = !empty($subvalue['contact_hedding']) ? $subvalue['contact_hedding'] : '';
		$wid_address = !empty($subvalue['cont_address']) ? $subvalue['cont_address'] : '';
		$wid_address2 = !empty($subvalue['cont_address2']) ? $subvalue['cont_address2'] : '';
		$wid_phone = !empty($subvalue['cont_phone']) ? $subvalue['cont_phone'] : '';
		$wid_phone2 = !empty($subvalue['cont_phone2']) ? $subvalue['cont_phone2'] : '';
		$wid_email2 = !empty($subvalue['cont_email2']) ? $subvalue['cont_email2'] : '';
		?>
		<?php echo $args['before_widget']; ?>
            <div class="widget widget_contact" data-aos="fade-left" data-aos-duration="3000">
                <div class="widget_title">
                    <h4><?php echo esc_html($wid_addressTitle); ?></h4>
                </div>
                <div class="widget_desc">
                    <ul>
                        <li>
                            <a href="#!">
                                <i class="fa fa-location-arrow"></i>
                                <p>
                                    <?php echo esc_html ($wid_address); ?>
                                    <span><?php echo esc_html ($wid_address2); ?></span>
                                </p>
                            </a>
                        </li>
                        <li>
                            <a href="#!">
                                <i class="fa fa-phone"></i>
                                <p>
                                     <?php echo esc_html($wid_phone); ?>
                                    <span><?php echo esc_html ($wid_phone2); ?></span>
                                </p>
                            </a>
                        </li>
                        <li>
                            <a href="#!">
                                <i class="fa fa-envelope"></i>
                                <p>
                                    <?php echo esc_html ($wid_email2); ?>
                                </p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
		<?php echo $args['after_widget']; ?>

		<?php
	}
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_value Values just sent to be saved.
	 * @param array $old_value Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update($new_value, $old_value){
        $subvalue['contact_hedding'] = ( !empty($new_value['contact_hedding']) ) ? strip_tags ( $new_value['contact_hedding'] ) : '';
        $subvalue['cont_address'] = ( !empty($new_value['cont_address']) ) ? strip_tags ( $new_value['cont_address'] ) : '';
        $subvalue['cont_address2'] = ( !empty($new_value['cont_address2']) ) ? strip_tags ( $new_value['cont_address2'] ) : '';
        $subvalue['cont_phone'] = ( !empty($new_value['cont_phone']) ) ? strip_tags ( $new_value['cont_phone'] ) : '';
        $subvalue['cont_phone2'] = ( !empty($new_value['cont_phone2']) ) ? strip_tags ( $new_value['cont_phone2'] ) : '';
        
        $subvalue['cont_email2'] = ( !empty($new_value['cont_email2']) ) ? strip_tags ( $new_value['cont_email2'] ) : '';
        return $subvalue;
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $subvalue Previously saved values from database.
	 */
	public function form($subvalue){
		$wid_addressTitle = !empty($subvalue['contact_hedding']) ? $subvalue['contact_hedding'] : '';
		$wid_address = !empty($subvalue['cont_address']) ? $subvalue['cont_address'] : '';
		$wid_address2 = !empty($subvalue['cont_address2']) ? $subvalue['cont_address2'] : '';
		$wid_phone = !empty($subvalue['cont_phone']) ? $subvalue['cont_phone'] : '';
		$wid_phone2 = !empty($subvalue['cont_phone2']) ? $subvalue['cont_phone2'] : '';
		
		$wid_email2 = !empty($subvalue['cont_email2']) ? $subvalue['cont_email2'] : '';
    ?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('address-title')); ?>">
			    <?php echo esc_html('Wedget Title:' ,'dexpress') ?>
            </label>
			
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'address-title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'contact_hedding' )); ?>" value="<?php echo esc_attr( $wid_addressTitle ); ?>" class="widefat" />
        </p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('address_field')); ?>">
			    <?php echo esc_html('Address:' ,'dexpress') ?>
            </label>
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'address_field' )); ?>"
			name="<?php echo esc_attr($this->get_field_name( 'cont_address' )); ?>" 
			value="<?php echo esc_attr( $wid_address ); ?>" class="widefat" />
           <input type="text" id="<?php echo esc_attr($this->get_field_id( 'address_field' )); ?>"
			name="<?php echo esc_attr($this->get_field_name( 'cont_address2' )); ?>" 
			value="<?php echo esc_attr( $wid_address2 ); ?>" class="widefat" />
        </p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('phoneno')); ?>">
			    <?php echo esc_html('Phone No:' ,'dexpress') ?>
            </label>
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'phoneno' )); ?>"
			name="<?php echo esc_attr($this->get_field_name( 'cont_phone' )); ?>" 
			value="<?php echo esc_attr( $wid_phone ); ?>" class="widefat" />
           <input type="text" id="<?php echo esc_attr($this->get_field_id( 'phoneno' )); ?>"
			name="<?php echo esc_attr($this->get_field_name( 'cont_phone2' )); ?>" 
			value="<?php echo esc_attr( $wid_phone2 ); ?>" class="widefat" />
        </p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('emailinfo')); ?>">
			    <?php echo esc_html('Email:' ,'dexpress') ?>
            </label>
           <input type="email" id="<?php echo esc_attr($this->get_field_id( 'emailinfo' )); ?>"
			name="<?php echo esc_attr($this->get_field_name( 'cont_email2' )); ?>" 
			value="<?php echo esc_attr( $wid_email2 ); ?>" class="widefat" />
        </p>
	<?php
	}
}
// register Short description widget
function dexpress_address_Widget() {
    register_widget( 'dexpress_address_Widget' );
}
add_action( 'widgets_init', 'dexpress_address_Widget' );