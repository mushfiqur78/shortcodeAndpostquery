<?php 
/**
 * Adds About info Widget.
 */

class dexpress_gallery_Widget extends WP_Widget{
	/**
	 * Register widget with WordPress.
	 */
	function __construct(){

		$widget_ops = array( 'info' => esc_html__('Gallery', 'dexpress'),'customize_selective_refresh' => true, );
 		parent:: __construct('dexpress_gallery_Widget', esc_html__('Dexpress: Gallery', 'dexpress'),$widget_ops );
	}
	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $value Saved values from database.
	 */
	function widget($args, $instance){
		extract($args);
		$title = apply_filters('widget_title', $instance['title']);
		$number = $instance['number'];
		$post_image = $instance[ 'post_image' ] ? 'true' : 'false';
		$post_date = $instance[ 'post_date' ] ? 'true' : 'false';
		echo $before_widget;
		if($title) {
			echo $before_title.$title.$after_title;
		}
		?>

        <div class="widget_desc" data-aos="fade-up" data-aos-duration="3000">
            <ul>
               <?php
				$args = array(
					'post_type' => 'dexpress-gallery',
					'posts_per_page' => $number,
					'has_password' => false,
					'order' => 'DESC'
				);
				$post = new WP_Query($args);
					if($post->have_posts()):
				?>
				<?php while($post->have_posts()): $post->the_post(); ?>
				<?php
					$permalink = get_permalink(); ?>
                      
                        <li>
                           <?php $x = 0; if( 'on' == $instance[ 'post_image' ] ) : $x++; ?>
                            <div class="rc_post_img">
                               <a class="venobox vbox-item" data-gall="gallery01" href="<?php the_post_thumbnail_url(); ?>">
                                    <?php
                                    if ( has_post_thumbnail() ) {
                                        the_post_thumbnail( 'dexpress-widget-postthumb', array( 'class' => 'img-responsive' ) );
                                    }
                                    ?>						  
                                </a>
                            </div>
                            <?php endif; ?>
                            <div class="footer_gallery <?php echo ($x == 0) ? 'noImage' : null?>">
                                
                                    <h4><a href="<?php echo esc_url($permalink); ?>"><?php the_title(); ?></a></h4>
                               
                                <p class="footer_gallery"><span><?php echo esc_html(get_the_time('n M, Y')); ?></span></p>
                                <?php if( 'on' == $instance[ 'post_date' ] ) : ?>
                                <?php endif; ?>
                            </div>
                        </li>
                <?php  endwhile; endif; 
				wp_reset_postdata();
				?>	
            </ul>
        </div>
		<?php
		echo $after_widget;
	}
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_value Values just sent to be saved.
	 * @param array $old_value Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
    function update($new_instance, $old_instance){
		$instance = $old_instance;
		$instance['title'] = $new_instance['title'];
		$instance['number'] = $new_instance['number'];
		$instance['post_image'] = $new_instance['post_image'];
		$instance['post_date'] = $new_instance['post_date'];
		return $instance;
	}
	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $value Previously saved values from database.
	 */
	function form($instance)
	{
		$defaults = array('title' => 'Recent Posts', 'post_image' => '', 'post_date' => '', 'number' => 4);
		$instance = wp_parse_args((array) $instance, $defaults); ?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title','dexpress'); ?>:</label>
			<input class="widefat" type="text" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php echo esc_attr($instance['title']); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of Posts to show','dexpress'); ?>:</label>
			<input class="widefat" type="number" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" value="<?php echo esc_attr($instance['number']); ?>" />
		</p>
		<p>
			<input class="checkbox" type="checkbox" <?php checked( $instance[ 'post_image' ], 'on' ); ?> id="<?php echo esc_attr($this->get_field_id( 'post_image' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'post_image' )); ?>" /> 
			<label for="<?php echo esc_attr($this->get_field_id( 'post_image' )); ?>"><?php esc_html_e('Show Post/News Image', 'dexpress'); ?></label>
		</p>
		<p>
			<input class="checkbox" type="checkbox" <?php checked( $instance[ 'post_date' ], 'on' ); ?> id="<?php echo esc_attr($this->get_field_id( 'postDate' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'post_date' )); ?>" /> 
			<label for="<?php echo esc_attr($this->get_field_id( 'postDate' )); ?>">
			    <?php esc_html_e('Show Post Date', 'dexpress'); ?>
			</label>
		</p>
	<?php
	}
}

// register Short description widget
function dexpress_gallery_Widget() {
    register_widget( 'dexpress_gallery_Widget' );
}
add_action( 'widgets_init', 'dexpress_gallery_Widget' );