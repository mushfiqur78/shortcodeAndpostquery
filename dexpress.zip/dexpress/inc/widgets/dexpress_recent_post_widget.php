<?php

add_action('widgets_init', 'dexpress_recent_post_load_widgets');
function dexpress_recent_post_load_widgets(){
	register_widget('dexpress_recent_post_Widget');
}


class dexpress_recent_post_Widget extends WP_Widget {
	public function __construct() {
		$widget_ops = array('classname' => 'dexpress_recent', 'description' => esc_html__('dexpress: Recent Posts Widget','dexpress') );
		$control_ops = array('id_base' => 'dexpress_recent-widget');
		parent::__construct('dexpress_recent-widget', esc_html__('dexpress: Recent Posts','dexpress'), $widget_ops, $control_ops);
	}

	function widget($args, $instance){
		extract($args);
		$title = apply_filters('widget_title', $instance['title']);
		$number = $instance['number'];
		$post_image = $instance[ 'post_image' ] ? 'true' : 'false';
		$post_date = $instance[ 'post_date' ] ? 'true' : 'false';
		echo $before_widget;
		if($title) {
			echo $before_title.$title.$after_title;
		}
		?>

        <div class="widget_desc" data-aos="fade-up" data-aos-duration="3000">
            <ul>
               <?php
				$args = array(
					'post_type' => 'post',
					'posts_per_page' => $number,
					'has_password' => false,
					'order' => 'DESC'
				);
				$post = new WP_Query($args);
					if($post->have_posts()):
				?>
				<?php while($post->have_posts()): $post->the_post(); ?>
				<?php
					$permalink = get_permalink(); ?>
                      
                        <li>
                           <?php $x = 0; if( 'on' == $instance[ 'post_image' ] ) : $x++; ?>
                            <div class="rc_post_img">
                                <a class="news_thumb" href="<?php echo esc_url($permalink); ?>">
                                    <?php
                                    if ( has_post_thumbnail() ) {
                                        the_post_thumbnail( 'dexpress-widget-postthumb', array( 'class' => 'img-responsive' ) );
                                    }
                                    ?>						  
                                </a>
                            </div>
                            <?php endif; ?>
                            <div class="rc_post_desc <?php echo ($x == 0) ? 'noImage' : null?>">
                                
                                    <h4><a href="<?php echo esc_url($permalink); ?>"><?php the_title(); ?></a></h4>
                               
                                <p><span><?php echo esc_html(get_the_time('n M, Y')); ?></span></p>
                                <?php if( 'on' == $instance[ 'post_date' ] ) : ?>
                                <?php endif; ?>
                            </div>
                        </li>
                <?php  endwhile; endif; 
				wp_reset_postdata();
				?>	
            </ul>
        </div>
		<?php
		echo $after_widget;
	}

	function update($new_instance, $old_instance){
		$instance = $old_instance;
		$instance['title'] = $new_instance['title'];
		$instance['number'] = $new_instance['number'];
		$instance['post_image'] = $new_instance['post_image'];
		$instance['post_date'] = $new_instance['post_date'];
		return $instance;
	}

	function form($instance)
	{
		$defaults = array('title' => 'Recent Posts', 'post_image' => '', 'post_date' => '', 'number' => 4);
		$instance = wp_parse_args((array) $instance, $defaults); ?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title','dexpress'); ?>:</label>
			<input class="widefat" type="text" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php echo esc_attr($instance['title']); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of Posts to show','dexpress'); ?>:</label>
			<input class="widefat" type="number" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" value="<?php echo esc_attr($instance['number']); ?>" />
		</p>
		<p>
			<input class="checkbox" type="checkbox" <?php checked( $instance[ 'post_image' ], 'on' ); ?> id="<?php echo esc_attr($this->get_field_id( 'post_image' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'post_image' )); ?>" /> 
			<label for="<?php echo esc_attr($this->get_field_id( 'post_image' )); ?>"><?php esc_html_e('Show Post/News Image', 'dexpress'); ?></label>
		</p>
		<p>
			<input class="checkbox" type="checkbox" <?php checked( $instance[ 'post_date' ], 'on' ); ?> id="<?php echo esc_attr($this->get_field_id( 'postDate' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'post_date' )); ?>" /> 
			<label for="<?php echo esc_attr($this->get_field_id( 'postDate' )); ?>">
			    <?php esc_html_e('Show Post Date', 'dexpress'); ?>
			</label>
		</p>
	<?php
	}
}
