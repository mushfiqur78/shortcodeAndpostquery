<?php
/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */

function dexpress_widgets_init() {
	register_sidebar( array(
		'name' => esc_html__( 'Blog Sidebar', 'dexpress' ),
		'id' => 'sidebar-1',
		'description' => esc_html__( 'Sidebar on blog page', 'dexpress' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<div class="widget_title"><h4>',
		'after_title' => '</h4></div>',
	) );
	register_sidebar( array(
		'name' => esc_html__( 'Single Blog Sidebar', 'dexpress' ),
		'id' => 'sidebar-singleblog',
		'description' => esc_html__( 'Sidebar on Singel blog page', 'dexpress' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<div class="widget_title"><h4>',
		'after_title' => '</h4></div>',
	) );
    
    register_sidebar( array(
		'name'          => esc_html__( 'Footer Sidebar', 'dexpress' ),
		'id'            => 'footer-sidebar',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="footer_widgets %2$s col-md-12 col-sm-12">',
		'after_widget' => '</aside>',
		'before_title' => '<div class="widget_title"><h4>',
		'after_title' => '</h4></div>',
	) );
	
}
add_action( 'widgets_init', 'dexpress_widgets_init' );
/**
 * Widget
 */
require_once get_template_directory() . '/inc/widgets/dexpress_recent_post_widget.php';
require_once get_template_directory() . '/inc/widgets/dexpress_about_widget.php';
require_once get_template_directory() . '/inc/widgets/dexpress_address_widget.php';
require_once get_template_directory() . '/inc/widgets/dexpress_gallery.php';