(function ($) {
    "use strict";
    var success_story = $('.success_story_area'),
        success_story_bg = success_story.data('bgimg');
        
    $('html').append('<style>.success_story_area::after{background-image: url('+ success_story_bg +');}</style>');
    
	// vc_actived_in_this_page
    if(jQuery('.vc_row').length){
        jQuery('body').addClass('vc_actived_in_this_page');
    }
	
	//meanmenu
	if($.fn.meanmenu){
		$('.mobile_menu').meanmenu({
			meanScreenWidth: 767
		});
    //$('.mean-nav .dropdown').removeClass('dropdown');
	}
    
	// This code is for Magnetic Pop_Up
    $('.popup-youtube').magnificPopup({
        type: 'iframe'
    }); 
    // magnetic pop up end
    
    //Menu
    if( $('.top_toolbar').length){
        $('.menu_area').css({"top": "0"});
        $('.mainmenu > ul').css({"margin-top": "0px"});
        $('.header_area').addClass('has_top_toolbar');
        $('.logo_area').addClass('logo_area_has_top_toolbar');
        $('.logo-overlay').addClass('logo-overlay_has_top_toolbar');
    }
    
	 // Add smooth scrolling to all links
	$("nav ul li a").on('click', function(event) {

    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){

        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
	
	
	/*----------------------------
        lettering word
	------------------------------ */
	$(".section_title h2, .footer_subscribe_heading ").lettering('words');
	
    //service slider
    $('.service_slider').owlCarousel({
        items:4,
		nav:true,
		loop:true,
        dots: false,
		navText: ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
		responsive : {
			300 : {
				items: 1
			},
			480 : {
				items: 1
			},
			768 : {
				items:3
			},
			992: {
				items:4
			}
		}
    });
	
	//tesm slider
    $('.tesm_slider').owlCarousel({
        items:2,
		loop:true,
		autoplay:true,
		smartSpeed:1000,
		dots:false,
		responsive : {
			300 : {
				items: 1
			},
			480 : {
				items: 1
			},
			768 : {
				items:2
			}
		}
    });
	//tesm slider
    $('.cfeedback_slider').owlCarousel({
        items:1,
		loop:true,
		autoplay:true,
		smartSpeed:1000,
		dots:true
    });
	//tesm slider
    $('.rproject_slider').owlCarousel({
        items:1,
		loop:true,
		autoplay:true,
		smartSpeed:1000,
		dots:true
    });
	//branding slider
	var branding_slider = $('.branding_slider');
    branding_slider.owlCarousel({
        items:5,
		loop:true,
		autoplay: dexpress_partnerscroll,
		smartSpeed:2000,
		dots:false,
		responsive : {
			300 : {
				items: 1
			},
			480 : {
				items: 2
			},
			768 : {
				items:3
			},
			992 : {
				items:dexpress_partnernumber
			}
		}
    });
    
    // Owl Carousel for Latest Service
    var tab_slid = $('.tab-pane');
    tab_slid.owlCarousel({
        loop:true,
        margin:15,
        autoplay:false,
        dots:false,
        responsive:{
            0:{
                items:1
            },
            768:{
                items:3
            },
            992:{
                items:3
            }
        }
    });
    
    $('.tab_area_nav .testi_next').on('click', function() {
        tab_slid.trigger('next.owl.carousel');
    });
    
    $('.tab_area_nav .testi_prev').on('click', function() {
        tab_slid.trigger('prev.owl.carousel');
    });
    
    
    
    function firstLastOwl($selector){
		var $this = $selector.find('.owl-stage .owl-item.active');
		$this.first().prev().addClass('brnone');
		$this.last().addClass('brnone');
	}
	firstLastOwl(branding_slider);
	
	branding_slider.on('translated.owl.carousel', function(){
		firstLastOwl($(this));
	}).on('translate.owl.carousel', function(){
		var $this = $(this).find('.owl-stage .owl-item');
		$this.removeClass('brnone');
	});
	//venobox
	$('.venobox').venobox();
	
	//counterup
	$('.counter').counterUp();
	
	//scroll top
	$('.scroll_top a').on('click',function(){
		$('html, body').animate({scrollTop : 0}, 1000);
		return false;
	});
    // vc_actived_in_this_page
    if(jQuery('.protfolio_singlepage_video').length){
        jQuery('body').addClass('singlepage_video');
    }
    AOS.init();
    window.addEventListener('load', AOS.refresh)
     $(window).load(function(){
        
         // tab-pane item height
        var tabpane_height = $('.tab-pane').height();
        $('.tab-content').css('height', tabpane_height)
		
         /*isotope and packery
		$('.grid').isotope({
			layoutMode: 'packery',
			itemSelector: '.grid_item'
		});*/
		
		/*portfolio sorting*/
		$('.filter_list').on( 'click', 'li', function() {
			var filterValue = $(this).attr('data-filter');
			/*$('.grid').isotope({ filter: filterValue });*/
			$(this).addClass('active');
			$('.filter_list li').not(this).removeClass('active');
			AOS.refresh();
		});
        /*$('.grid-item').masonry();*/
         
        
    });
	
	
	
})(jQuery);