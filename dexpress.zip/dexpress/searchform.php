<form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="searchfield" role="search">
    <input type="search" class="form-control" name="s" placeholder="<?php echo esc_attr_x( 'Search', 'placeholder', 'dexpress' ); ?>" value="<?php echo get_search_query(); ?>">
	<input type="submit" class="business-search-submit" value="<?php echo esc_attr_x( 'Go', 'submit button', 'dexpress' ) ?>" />
</form>