<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Giant_Business_-_Business_WordPress_Theme
 */
get_header();
dexpress_singleservicepage_breadcrumb();
?>
	<div id="primary" class="content-area">
		<main id="main" class="site-main">
            <!-- ========================================
                ==Start Single Serivce==
            ======================================== -->
            <section class="section-padding">
                <div class="container">
                    <div class="row service service_detail">
                       <?php echo $image; ?>
                        <?php
                            while ( have_posts() ) : the_post();
                                get_template_part( 'template-parts/service', 'single' );
                            endwhile; // End of the loop.
                        ?>
                    </div>
                </div>
            </section>
            <!-- ========================================
                ==End Single Serivce==
            ======================================== -->
        </main> 
    </div>
<?php get_footer(); ?>
