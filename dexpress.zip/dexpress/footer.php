<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package dexpress
 */

?>

	</div><!-- #content -->

	    <!-- ================================================= 
						Start Footer Subscribe Area
		=================================================== -->
		<?php if ( is_active_sidebar( 'footer-sidebar' ) ) : 
            global $dexpress_opt;
            if( !empty($dexpress_opt['newsletter_description']) || !empty( $dexpress_opt['newsletter_form'] ) || !empty($dexpress_opt['newsletter_title']) ){
        ?>
           
            <div class="footer_subscribe_area" data-aos="fade-right" data-aos-duration="3000">
                <div class="container">
                    <div class="row">
                        <div class="col-md-7">
                            <?php dexpress_newsletter_title(); 
                            global $dexpress_opt;
                            if( !empty($dexpress_opt['newsletter_description']) || !empty( $dexpress_opt['newsletter_form'] ) ){
                            ?>
                            <div class="footer_subscribe_form">
                                <div class="footer_subscribe_desc">
                                    <p><?php dexpress_newsletter_des(); ?></p>
                                </div>
                                <div class="footer_subscribe_input">
                                    <?php dexpress_newsletter_form(); ?>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
		<?php } endif; ?>
		<!-- ==================================================  
						End Footer Subscribe Area
		=================================================== -->

		<!-- ==================================================  
						Start footer Area
		=================================================== -->
		<footer class="footer_area">
		<?php if ( is_active_sidebar( 'footer-sidebar' ) ){ ?>
			<section class="footer_top_area">
				<div class="container">
					<div class="row">
					    <?php dynamic_sidebar( 'footer-sidebar' ); ?>
					</div>
				</div>
			</section>
		<?php } ?>
			<div class="footer_bottom_area">
				<div class="container">
					<div class="row">
						<div class="col-lg-5 col-md-6 col-sm-12">
							<div class="footer_copyright">
								<?php dexpress_copyright(); ?>
							</div>
						</div>
						<div class="col-lg-7 col-md-6 col-sm-12">
							<nav class="footer_menu">
								<?php dexpress_footer_menu(); ?>
							</nav>
						</div>
					</div>
				</div>
				<div class="scroll_top">
					<a href="#!">
						<i class="fa fa-arrow-circle-o-up"></i>
					</a>
				</div>
			</div>
		</footer>
		<!-- ==================================================  
						End footer Area
		=================================================== -->
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
