<body <?php body_class(); ?>>
    <div id="page" class="site body_wrapper home">
        <!-- ==================================================  
						Start Header Area
		=================================================== -->
		<header class="header_area">			
			<div class="menu_area">
				<div class="container-full">
                    <div class="row">
                        <div class="col-md-3 col-sm-3">
                           
                                <div class="logo_area">
                                    <?php global $dexpress_opt;
                                        $logo_url = !empty($dexpress_opt['logo_main']['url']) ? $dexpress_opt['logo_main']['url'] : null;
                                        dexpress_logo( esc_url($logo_url) );  
                                    ?>
                                </div>
                        </div>
						<div class="col-md-9 col-sm-9">
                            <nav class="mainmenu">
                                <?php dexpress_main_menu(); ?>
                            </nav>
							<?php dexpress_socialicons(); ?>
						</div>
						
					</div>
					
				</div>
				
			</div>
			<div class="mobile_menu">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="mobile_mean_logo">
								<?php global $dexpress_opt;
                                    $logo_url = !empty($dexpress_opt['logo_main']['url']) ? $dexpress_opt['logo_main']['url'] : null;
                                   dexpress_logo( esc_url($logo_url) ); 
                                ?>
							</div>
							<nav class="mobile_mean_menu">
								<?php dexpress_mobile_menu(); ?>
				            </nav>
						</div>
					</div>
				</div>
			</div>
		</header>
		
		<!-- ==================================================  
						End Header Area
		=================================================== -->
	<div id="content" class="site-content">