<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package dexpress_-_dexpress_&_Corporate_WordPress_Theme
 */
$pro_img = get_post_meta( get_the_ID(), '_dexpress_protfolioimg','dexpress-protfolio-img', true );
$client_name = get_post_meta($post->ID, '_dexpress_client_name', true);
$item_cats = get_the_terms(get_the_ID(), 'portfolio_category');
$item_classes = '';
if($item_cats){
    $x = 0;
    $delimeter = '';
    foreach($item_cats as $item_cat) {
        if($x == 1){
            $delimeter = ', ';
        }
        
        $item_classes .= $delimeter . $item_cat->slug;
        $x++;
    }
}
?>
   <div class="row">
        <div class="col-md-6">
            <div class="total_p_details clearfix">
                <?php if ( $pro_img ) { ?>
                    <div class="singl_p_details_hover">
                        <img src="<?php echo $pro_img; ?>" alt="service image">
                    </div>
                <?php } ?>
            </div>
        </div>
        <div class="col-md-6">
            <div class="single_planning">
                <?php the_content(); ?>
            </div>
        </div>
    </div>
   
