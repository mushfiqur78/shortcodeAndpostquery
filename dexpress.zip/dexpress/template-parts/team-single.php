<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package dexpress_-_dexpress_&_Corporate_WordPress_Theme
 */

$icon_linkname = get_post_meta( get_the_ID(), '_dexpress_team_social_icon', true );
$teamdesignation = get_post_meta( get_the_ID(), '_dexpress_team_designation', true );
?>
<!-- ==================================================  
						Start Service tab Area
=================================================== -->
    <div class="single_team_area">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="row team-content">
                        <div class="col-sm-4 team-photo">
                            <?php the_post_thumbnail('full'); ?>
                        </div>
                        <div class="col-sm-8 team-heading">
                            <h3><?php the_title(); ?></h3>
                            <h5><?php echo esc_html($teamdesignation); ?></h5>
                            <?php the_content(); ?>
                            <ul>
                            <?php if( is_array($icon_linkname)){
                                foreach($icon_linkname as $iconlink){ ?>
                                <li>
                                    <a href="<?php echo esc_html($iconlink['_dexpress_socialicon_link']); ?>">
                                        <i class="fa fa-<?php echo esc_html($iconlink['_dexpress_socialicon_name']); ?>">
                                    </i>
                                    </a>
                                </li>
                                <?php  }
                            } ?> 
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- ==================================================  
                End Service tab Area
=================================================== -->