<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package dexpress_-_dexpress_&_Corporate_WordPress_Theme
 */
$advisorsdesig = get_post_meta(get_the_id(),'_dexpress_advisore_desig',true);
$advisors_fb = get_post_meta(get_the_id(),'_dexpress_fb_link',true);
$advisors_tw = get_post_meta(get_the_id(),'_dexpress_tw_link',true);
$advisors_ld = get_post_meta(get_the_id(),'_dexpress_ldin_link',true); 
$advisors_sky = get_post_meta(get_the_id(),'_dexpress_sky_link',true);
?>
<!-- ====================================
        ==Start single member==
==================================== -->
<section class="single_member_container_area">
    <div class="container">
        <div class="row">
                <?php if ( has_post_thumbnail() ) { ?>
				<div class="col-xs-12 col-md-4">
                    <div class="single_team_member_image">
						<?php the_post_thumbnail( '', array( 'class' => 'img-responsive' ) ); ?>
                    </div>
				</div>
                <?php } ?>
				<div class="col-xs-12 col-md-8">
					<div class="single_team_member_content">
						<div class="single_team_member_content_title">
							<h3><?php the_title(); ?></h3>
							<span><?php echo esc_html($advisorsdesig); ?></span>
						</div>
						<div class="single_team_member_content_body">
							<ul>
								<li>
									<span><img src="<?php echo get_template_directory_uri(); ?>/assets/img/svg/quote-left.svg" class="svg" alt="quote icon"></span> 
									<?php the_content(); ?>
								</li>
							</ul>
						</div>
						<div class="single_member_content_soccial">
							<ul class="singel_team_social">
								<?php if(!empty($advisors_fb) ){ ?>
								<li><a href="<?php echo esc_attr($advisors_fb); ?>">
									<i class="ion-social-facebook-outline"></i>
									</a>
								</li>
								<?php }
								if(!empty($advisors_tw) ){ ?>
								<li><a href="<?php echo esc_attr($advisors_tw); ?>">
										<i class="ion-social-twitter-outline"></i>
									</a>
								</li>
								<?php }
								if(!empty($advisors_ld)) { ?>
								<li><a href="<?php echo esc_attr($advisors_ld); ?>" class="linkedin">
										<i class="ion-social-linkedin-outline"></i>
									</a>
								</li>
								<?php } ?>
								<?php
								if(!empty($advisors_sky)) { ?>
								<li><a href="<?php echo esc_attr($advisors_sky); ?>">
										<i class="ion-social-skype-outline"></i>
									</a>
								</li>
								<?php } ?>
							</ul> 
						</div>
					</div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ====================================
        ==End single member==
==================================== -->