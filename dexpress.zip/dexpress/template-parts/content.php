<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package dexpress
 */
$blog_layout = dexpress_sidebar_layoutpossition('blog_layout', 'sidebarblog_pos');
if($blog_layout['blogcolwidth'] == 9){
    $singleblogcolwidth = 6;
}else{
	$singleblogcolwidth = 4;
}
?>
<div class="<?php echo esc_attr('col-xs-12 col-sm-' . $singleblogcolwidth); ?>">
   <div class="single_post_big">
        <article <?php post_class('single_post'); ?>>
            <?php if(has_post_thumbnail()){ ?>
            <div class="post_thumbnail">
               <a href="<?php echo esc_url( get_permalink()); ?>">
                    <?php 
                        if($blog_layout['blogcolwidth']==9){
                            the_post_thumbnail( 'dexpress-blog-sidebarthumb', array( 'class' => 'img-responsive' ) );
                            echo '<i class="fa fa-link"></i>';
                        }else{
                            the_post_thumbnail( 'dexpress-blog-img', array( 'class' => 'img-responsive' ) );
                            echo '<i class="fa fa-link"></i>';
                        }
                    ?>
                </a>
            </div>
            <?php } ?>
            <div class="post_content <?php if ( has_post_thumbnail() ){ echo 'content-padding'; }else{ echo 'content-no-padding'; } ?>">
                <div class="post_meta">
                    <ul>
                        <li>
                            <i class="fa fa-calendar"></i>
                            <?php echo get_the_date(); ?>
                        </li>
                        <li>
                            <i class="fa fa-user"></i>
                            <?php echo get_the_author_link(); ?>
                        </li>
                        <li>
                            <i class="fa fa-comments mrs"></i>
                            <?php comments_popup_link( esc_html__('No Comment','dexpress'), esc_html__('1 Comment', 'dexpress'), esc_html__('% Comments','dexpress'), ' ', esc_html__('Comments off','dexpress')); ?>
                        </li>
                    </ul>
                </div>
                <div class="post_title">
                    <?php the_title( '<h4><a href="' . esc_url( get_permalink() ) . '">', '</a></h4>' ); ?>
                </div>
                <div class="post_desc">
                    <?php the_excerpt();
                        wp_link_pages( array(
                            'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'dexpress' ),
                            'after'  => '</div>',
                        ) );
                    ?>
                </div>
                <div class="post_btn">
                    <a class="care_bt" href="<?php echo esc_url( get_permalink()); ?>">
                        <?php dexpress_blog_read_more(); ?>
                        <i class="fa fa-long-arrow-right"></i>
                    </a>
                </div>
                <?php
                    if ( is_sticky() ) {
                    echo '<div class="sticky_post"><span>'.esc_html__('Featured', 'dexpress').'</span></div>';
                } ?>
            </div>
        </article> 
    </div>
 </div>