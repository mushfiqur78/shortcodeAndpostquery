<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package dexpress
 */
$idd = get_the_ID();
$protfolio_video = esc_url( get_post_meta( $idd, '_dexpress_protfolioLink', 1 ) ); ?>
<div class="col-md-4">
    <div class="single_portfolio_item">
        <div class="portfolio_image">
            <?php the_post_thumbnail('dexpress-protfolio-img'); ?>
        </div>
        <div class="portfolio_hover">
            <?php if($protfolio_video){ ?>
            <div class="portfolio_hover_content_inner">
                                                    <?php the_title( '<h4><a href="' . esc_url( get_permalink() ) . '">', '</a></h4>' );
                                                        ?>
                                                </div>
            <a class="popup-youtube" href="<?php echo esc_attr ( $protfolio_video ); ?>">
                    <i class="fa fa-play"></i>
                </a>
            <?php }else{ ?>
                    <div class="portfolio_hover_content_inner">
                <?php the_title( '<h4><a href="' . esc_url( get_permalink() ) . '">', '</a></h4>' );
                ?>
            </div>
                <?php } ?>
        </div>
    </div>  
</div>  
