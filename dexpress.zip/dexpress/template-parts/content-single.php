<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Giant_Business_-_Business_WordPress_Theme
 */
global $dexpress_opt;

$single_blog_layout = dexpress_sidebar_layoutpossition('single_blog_layout', 'sidebar_single_blog_pos');
?>

    <article class="single_post">
        <div class="post_meta">
            <span><?php echo get_the_date(); ?></span>
            <div class="comment">   
                <span><i class="fa fa-comments-o"></i></span>
				<?php comments_popup_link( esc_html__('No Comment','dexpress'), esc_html__('1 Comment', 'dexpress'), esc_html__('% Comments','dexpress'), ' ', esc_html__('Comments off','dexpress')); ?>
			</div>
        </div>
        <div class="post_content <?php if ( has_post_thumbnail() ){ echo ' then-margin'; }else{ echo ' then-no-margin'; } ?>">
        <?php if ( has_post_thumbnail() ) { ?>
            <div class="single_post_thumbnail">
                <?php
                    if($single_blog_layout['blogcolwidth']==9){
                        the_post_thumbnail( 'dexpress-single-sidebarthumb', array( 'class' => 'img-responsive' ) );
                    }else{
                        the_post_thumbnail( 'full', array( 'class' => 'img-responsive' ) );
                    }
                ?>
            </div>
        <?php } ?>
            <div class="post_desc">
                <?php the_content();
                    wp_link_pages( array(
                        'before'      => '<div class="pagination"><span class="page-links-title">' . esc_html__( 'Pages:', 'dexpress' ) . '</span>',
                        'after'       => '</div>',
                        'link_before' => '<span>',
                        'link_after'  => '</span>',
                    ) );
                ?>
            </div>
        </div>
    </article>
    <div class="post_tag_share">
        <div class="post_tag">
            <!-- Blog post tsgs -->
            <?php if(has_tag()) { ?>
			<span><?php echo esc_html('Tags: ','dexpress'); ?></span>
            <div class="tags">
                <ul>
                    <?php the_tags( '<li>', '</li>, <li>', '</li>' ); ?>
                </ul>
            </div><!-- Blog post tags ends -->
            <?php } ?>
        </div>
        <?php if(function_exists('dexpress_blog_sharing')){ ?>
            <div class="post_share">
                <span><?php echo esc_html('Share Now : ','dexpress'); ?></span>
                <?php dexpress_blog_sharing(); ?>
            </div>
        <?php } ?>
    </div>

