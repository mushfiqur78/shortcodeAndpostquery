<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Giant_Business_-_Business_WordPress_Theme
 */


if ( ! is_active_sidebar( 'sidebar-singleblog' ) ) {
	return;
}
$singlblog_layout = dexpress_sidebar_layoutpossition('single_blog_layout', 'sidebar_single_blog_pos');

//<!--Sidebar-->
 if ( is_active_sidebar( 'sidebar-singleblog' ) ) : ?>
	<div class="col-xs-12 col-sm-3">
		<div class="sidebar <?php echo esc_attr($singlblog_layout['blogsidebar']);?>">
			<?php dynamic_sidebar( 'sidebar-singleblog' ); ?>
		</div>
	</div>
<?php endif; ?>

