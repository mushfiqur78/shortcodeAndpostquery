<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package dexpress_-_dexpress_&_Corporate_WordPress_Theme
 */

?>
<!-- ==================================================  
						Start Service tab Area
=================================================== -->
   <div class="col-sm-12">
    <div class="service_tab_area">
        <div class="container">
            <div class="row">
                    <div class="single_tab_service">
                        <div class="single_tab_service_right">
                            <h3><?php the_title(); ?></h3>
                            <?php the_content(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- ==================================================  
                End Service tab Area
=================================================== -->