<?php
if ( class_exists( 'Attachments' ) ) {
    require_once "lib/attachments.php";
}