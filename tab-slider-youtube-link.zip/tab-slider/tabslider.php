<?php
/*
Plugin Name: Tabslider
Plugin URI:
Description: Slider in Tab
Version: 1.0
Author: Mushfiq
Author URI: https://btibrokeragebd.com
License: GPLv2 or later
Text Domain: tabslider
Domain Path: /languages/
*/

//define
define( 'PLG_URL', plugins_url() );
define( 'PLG_DIR', dirname( __FILE__ ) ); 

/**----------------------------------------------------------------*/
/*    // nextwave all shortcodes
/*-----------------------------------------------------------------*/  
include_once(PLG_DIR. '/bti-custompost.php');

function tinys_load_textdomain() {
	load_plugin_textdomain( 'tabslider', false, dirname( __FILE__ ) . "/languages" );
}

add_action( 'plugins_loaded', 'tinys_load_textdomain' );

function tinys_init(){
	add_image_size('tiny-slider',800,600,true);
}
add_action('init','tinys_init');

function tinys_assets(){
	wp_enqueue_style( 'owl-carousel', plugin_dir_url(__FILE__).'/assets/css/owl.carousel.min.css');
	wp_enqueue_style( 'owl-carousel-theme', plugin_dir_url(__FILE__).'/assets/css/owl.theme.default.min.css');
	wp_enqueue_style( 'magnific-popup', plugin_dir_url(__FILE__).'/assets/css/magnific-popup.css');
	
	wp_enqueue_style( 'style', plugin_dir_url(__FILE__).'/assets/css/style.css');
	
   
	
	wp_enqueue_script('owl-carousel',plugin_dir_url(__FILE__)."/assets/js/owl.carousel.min.js",array('jquery'),'2.3.4',true);
	wp_enqueue_script('magnific-popup',plugin_dir_url(__FILE__)."/assets/js/jquery.magnific-popup.min.js",array('jquery'),'1.1.0',true);
	wp_enqueue_script('main-js',plugin_dir_url(__FILE__)."/assets/js/main.js",array('jquery'),'1.0',true);
	
}
add_action('wp_enqueue_scripts','tinys_assets');


//usages: [dexpress_portfolio]
add_shortcode('dexpress_portfolio', 'dexpress_portfolio_shortcode');
function dexpress_portfolio_shortcode($atts, $content=null){
	extract(shortcode_atts(array(
        'posts_per_page'=> -1,
	),$atts));
	ob_start(); ?>
        <!-- OUR DOCTORS STAET -->
    <section class="">
        <!-- Nav tabs -->
        <div class="row">
            
            <!-- Tab panes -->
            <div class="col-md-12">
                <div class="owlcarousel-area">
                    <div class="tesm_slider owl-carousel">
                        <?php 
                            $g_recentwork = null;
                            $g_recentwork = new WP_Query(array(
                                'post_type' => 'bti-testimonial',
                                'posts_per_page'=> -1,
                                'order'=>'ASC',
                                
                            ));
                                if( $g_recentwork->have_posts() ){
                                    while($g_recentwork->have_posts() ){
                                        $g_recentwork->the_post();
                                        $idd = get_the_ID();
                                        
                                       
                                        $clientname = get_post_meta($idd, 'client_name', 1 );
                                        $protfolio_video = esc_url( get_post_meta( $idd, 'youtube_link', 1 ) );
                                        ?>
                                        
                                        <div class="single_portfolio_item">
                                            <div class="portfolio_image">
                                                <?php the_post_thumbnail(''); ?>
                                            </div>
                                            <div class="portfolio_hover">
                                                <?php if($protfolio_video){ ?>
                                                
                                                
                                                <div class="portfolio_hover_content_inner">
                                                    <?php the_title( '<h4><a href="' . esc_url( get_permalink() ) . '">', '</a></h4>' );
                                                ?>
                                                </div>
                                                <div class="clientanme">
                                                   <?php if( is_array($clientname)){
                                                        foreach($clientname as $canme){ ?>
                                                        <h5>
                                                           <?php echo ($canme); ?>
                                                        </h5>
                                                        <?php  } 
                                                        }?> 
                                                </div>
        
                                  <a class="popup-youtube" href="<?php echo esc_attr ( $protfolio_video ); ?>">
                                                        <i class="fa fa-play"></i>
                                                    </a>
                                                <?php }else{ ?>
                                                        <div class="portfolio_hover_content_inner">
                                                            <?php the_title( '<h4><a href="' . esc_url( get_permalink() ) . '">', '</a></h4>' );
                                                            ?>
                                                        </div>
                                                        <div class="clientanme">
                                                           <?php if( is_array($clientname)){
                                                                foreach($clientname as $canme){ ?>
                                                                <h5>
                                                                   <?php echo ($canme); ?>
                                                                </h5>
                                                                <?php  } 
                                                                }?> 
                                                        </div>
                                                    <?php } ?>
                                            </div>
                                        </div> 
                                        
                                    <?php }
                                    wp_reset_postdata();
                                }else{
                                    echo 'No post';
                                }
                                
                            ?>
                        </div>
                
                </div>
                <div class="tab_area_nav">
                    <i class="fa fa-angle-left testi_prev"></i>
                    <i class="fa fa-angle-right testi_next"></i>
                </div> 
            </div>
        </div> 
    </section>
    <!-- OUR DOCTORS END -->
	<?php
	return ob_get_clean();
}


















