(function ($) {
    "use strict";
    
    // common variable
    var windowWidth = $(window).width(),
        windowHeight = $(window).height(),
        headTag = $('head'),
        body = $('body'),
        siteHeader = $('.site-header'),
        mainNavbar = $('.manu_area'),
        isSticky = $('.sticky_menu_true').length,
        isMobile = windowWidth < 768;
    
    //Affix
    if(isSticky){
        mainNavbar.affix({
            offset: {
                top: 46
            }
        });
    }

    siteHeader.height(siteHeader.height());

    // Jquery Smooth Scroll
    $('.scroll_button h6 a').bind('click', function (event) {
        var $anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: $($anchor.attr('href')).offset().top + 2 + 'px'
        }, 1500, 'easeInOutCubic');
        event.preventDefault();
    });
    
    var vcrow = jQuery('.vc_row[data-vc-full-width]');
    vcrow.each(function(){
      var isFound = jQuery(this).find('.header_paralux').length;
      if(isFound){
        jQuery(this).addClass('overflowinitial');
      }
    });
    
    // Owl Carousel for Main Slider
    var project_slider = $('.project_slider');
    project_slider.owlCarousel({
        loop: true,
        margin: 0,
        autoplay: false,
        dots: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 3
            },
            992: {
                items: 4
            }
        }
    });

    $('ul.project_nav li').eq(0).on('click', function () {
        project_slider.trigger('prev.owl.carousel');
    });
    $('ul.project_nav li').eq(1).on('click', function () {
        project_slider.trigger('next.owl.carousel');
    });
    
    var projectSliderOverlayWidth = (windowWidth - 1140)/2;
    headTag.append('<style>.single_project_slider::before, .single_project_slider::after{width: ' + projectSliderOverlayWidth + 'px;} .single_project_slider::before{ left: -'+ projectSliderOverlayWidth +'px;} .single_project_slider::after{ right: -'+ projectSliderOverlayWidth +'px}</style>');
    // Jquery counterUp
    $('.counter').counterUp({
        time: 3000
    });
    // Footer Map
    $(".scroll_button > p a, .footer_area .scroll_button i").on('click', function () {
        $("#footermap").toggleClass('show');
    });
    if ($('.contact_map_area').length){
        $('.in_footermap').css('visibility', 'hidden');
    }
    // Owl Carousel for Main Slider
    var client_slider = $('.client_slider');
    client_slider.owlCarousel({
        loop: true,
        margin: 0,
        autoplay: false,
        dots: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            992: {
                items: 1
            }
        }
    });

    // Partner Slider
    var partner_slider = $('.partner_slider');
    partner_slider.owlCarousel({
        loop: true,
        margin: 0,
        autoplay: consult_partnerscroll,
        dots: false,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 4
            },
            992: {
                items: consult_partnernumber
            }
        }
    });

    // Partner Slider
    var clientsd = $('.clientsd');
    clientsd.owlCarousel({
        loop: true,
        margin: 0,
        autoplay: false,
        dots: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            992: {
                items: 1
            }
        }
    });

    // Owl Carousel for Main Slider
    var pro_sing_slider = $('.pro_sing_slider');
    pro_sing_slider.owlCarousel({
        loop: true,
        margin: 0,
        autoplay: false,
        dots: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            992: {
                items: 2
            }
        }
    });

    $('ul.pro_sing_nav .testi_next').on('click', function () {
        pro_sing_slider.trigger('next.owl.carousel');
    });
    $('ul.pro_sing_nav .testi_prev').on('click', function () {
        pro_sing_slider.trigger('prev.owl.carousel');
    });

    
    

//    $('.footer_area .scroll_button i').on('click', function () {
//        $('html, body').animate({
//            scrollTop: 0
//        }, 4000);
//        return false;
//    });

    /*====== camera slider for Home-2 ======*/
    isMobile ? windowHeight = 648 : null;
    var camWraper = $('.camera_wraper');
    if (camWraper.length) {
        camWraper.camera({
            height: windowHeight + 'px',
            pagination: false,
            autoAdvance: false,
            thumbnails: false,
            loader: false,
            playPause: false,
            fx: 'random'
        });
    }
    // mobile Menu area
    $('nav.mb_menu').meanmenu({
        meanScreenWidth: '767'
    });
    /*----------------------------
        lettering word
	------------------------------ */
		$(".pro2_text h3, .post_img > h4").lettering('words');
    
    $(window).load(function(){
        $('.grid').masonry({
            // options
            itemSelector: '.grid-item'
        });
        $('input.wysija-submit.wysija-submit-field')
        .replaceWith('<button class="wysija-submit wysija-submit-field" type="submit"><i class="icofont icofont-ui-message"></i></button>');
        $('input.search-submit')
        .replaceWith('<button class="search-submit"><i class="icofont icofont-search"></i></button>');
        
    });

})(jQuery);