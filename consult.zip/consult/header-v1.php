<body <?php body_class(); ?>>
<div id="body" class="homePage">
	<a class="skip-link screen-reader-text" href="#content">
	    <?php esc_html_e( 'Skip to content', 'consult' ); ?>
	</a>

	<header id="masthead" class="site-header">
       <?php consult_hearder_top(); ?>
        <div class="manu_area">
            <div class="container">
                <div class="row">
                    <div class="col-sm-2">
                        <div class="logo">
                            <?php global $consult_opt;
                                $logo_url = !empty($consult_opt['logo_main']['url']) ? $consult_opt['logo_main']['url'] : null;
                                consult_logo( $logo_url ); 
                            ?>
                        </div>
                    </div>
                    <div class="col-sm-10">
                        <div class="mainnmenu">
                            <nav class="hidden-xs">
                                <?php consult_main_menu(); ?>
                            </nav>
                            <nav class="mb_menu hidden">
                                <?php consult_mobile_menu(); ?>
                            </nav>
                            <?php
                                global $consult_opt;
                                if(!empty($consult_opt['free_consulbtn'])) { ?>
                                 <a class="free_consul" href="<?php consult_free_btnLink(); ?>">
                                    <?php consult_free_btnTxt(); ?>
                                </a>   
                            <?php }?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</header><!-- #masthead -->

	<div id="content" class="site-content">
