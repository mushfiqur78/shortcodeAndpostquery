<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package consult
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
global $consult_opt;
$blogsidebar = 'right';
if(isset($consult_opt['sidebarblog_pos']) && $consult_opt['sidebarblog_pos']!=''){
	$blogsidebar = $consult_opt['sidebarblog_pos'];
}
if(isset($_GET['sidebar']) && $_GET['sidebar']!=''){
	$blogsidebar = $_GET['sidebar'];
}

//<!--Sidebar-->
 if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
	<div class="col-xs-12 col-sm-3">
		<div class="sidebar_area <?php echo esc_attr($blogsidebar);?>">
			<?php dynamic_sidebar( 'sidebar-1' ); ?>
		</div>
	</div>
<?php endif; ?>
