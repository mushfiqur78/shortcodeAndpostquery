<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package consult
 */

get_header(); 
consult_singlepage_breadcrumb();

$sidebar_possition = consult_sidebar_layoutpossition('single_blog_layout', 'sidebar_single_blog_pos');

?>
    <div class="singleblog_page inner_page">
        <div class="blog_area">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 <?php echo esc_attr('col-sm-' . $sidebar_possition['blogcolwidth']); if($sidebar_possition['blogsidebar'] == 'left'){ echo ' pull-right'; } ?>">
                        <div id="primary" class="content-area">
                            <main id="main" class="site-main" role="main">
                                <?php
                                    while ( have_posts() ) : the_post();
								        get_template_part( 'template-parts/content-single', get_post_format() );
                                        // If comments are open or we have at least one comment, load up the comment template.
                                        if ( comments_open() || get_comments_number() ) :
                                            comments_template();
                                        endif;
				                    endwhile; // End of the loop.
                                ?>
                            </main><!-- #main -->
                        </div><!-- #primary -->
                    </div>
                    <!-- Sidebar -->
                    <?php if( $sidebar_possition['blogsidebar'] =='left' || $sidebar_possition['blogsidebar']=='right') : ?>
					    <?php get_sidebar(); ?>
				    <?php endif; ?>
                </div>
            </div>
        </div>
	</div>
<?php get_footer();