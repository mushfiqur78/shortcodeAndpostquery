<?php
/**
 * consult functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package consult
 */

if ( ! function_exists( 'consult_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function consult_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on consult, use a find and replace
	 * to change 'consult' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'consult', get_template_directory() . '/languages' );
    
    /*
     * This theme styles the visual editor to resemble the theme style
    */
    add_editor_style( array( 'css/editor-style.css', consult_fonts_url() ) );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );
    add_image_size( 'consult_widget_blog_thumb', 80, 65, true );
    add_image_size( 'consult_post-thumb', 394, 345, true );
    add_image_size( 'consult_team_member', 255, 226, true );
    add_image_size( 'consult_recent-post-thumb', 360, 260, true );
    add_image_size( 'consult_project_thumb', 285, 239, true );
    add_image_size( 'consult_fullwidth-thumb', 1140, 500, true);
    add_image_size( 'consult_sidebar-thumb', 845, 405, true);
    add_image_size( 'consult_service_pg_img', 350, 376, true);
	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'Mainmenu-1' => esc_html__( 'Primary', 'consult' ),
	) );
    
    /*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'consult_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );
}
endif;
add_action( 'after_setup_theme', 'consult_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function consult_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'consult_content_width', 640 );
}
add_action( 'after_setup_theme', 'consult_content_width', 0 );

/**
 * Enqueue google fonts.
 */
function consult_fonts_url(){
	$fonts_url = '';
	 
	/* Translators: If there are characters in your language that are not
	* supported by Poppins, translate this to 'off'. Do not translate
	* into your own language.
	*/
	$poppins = _x( 'on', 'Poppins font: on or off', 'consult' );
	 
	/* Translators: If there are characters in your language that are not
	* supported by Open Sans, translate this to 'off'. Do not translate
	* into your own language.
	*/
	$open_sans = _x( 'on', 'Open Sans font: on or off', 'consult' );
	 
	if ( 'off' !== $poppins || 'off' !== $open_sans ) {
	$font_families = array();
	 
	if ( 'off' !== $poppins ) {
	$font_families[] = 'poppins:300,400,500,600,700';
	}
	 
	if ( 'off' !== $open_sans ) {
	$font_families[] = 'Open Sans:400,600,700,600italic,400italic,700italic,300,300italic';
	}
	 
	$query_args = array(
	'family' => urlencode( implode( '|', $font_families ) ),
	'subset' => urlencode( 'latin,latin-ext' ),	
	);
	 
	$fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
	}
	 
	return esc_url_raw( $fonts_url );
}

function consult_inline_stylesheet(){
    global $consult_opt;
    ob_start(); ?>
    
.our_client {
    background: rgba(2, 7, 39, 0) -webkit-linear-gradient(left, <?php echo $consult_opt['background_secondary_color']['background-color']?> 0%, <?php echo $consult_opt['background_secondary_color']['background-color']?> 50%, <?php echo $consult_opt['background_primary_color']['background-color']?> 50%, <?php echo $consult_opt['background_primary_color']['background-color']?> 100%) repeat scroll 0 0;
    background: rgba(2, 7, 39, 0) linear-gradient(to right, <?php echo $consult_opt['background_secondary_color']['background-color']?> 0%, <?php echo $consult_opt['background_secondary_color']['background-color']?> 50%, <?php echo $consult_opt['background_primary_color']['background-color']?> 50%, <?php echo $consult_opt['background_primary_color']['background-color']?> 100%) repeat scroll 0 0;
}
.about_page .about_area {
  background: rgba(2, 7, 39, 0) linear-gradient(to right, #fff 0%, #fff 50%, <?php echo $consult_opt['background_primary_color']['background-color']; ?> 50%, <?php echo $consult_opt['background_primary_color']['background-color']; ?> 100%) repeat scroll 0 0;
}
.vc_tta-panel-body{
	background: <?php echo $consult_opt['background_secondary_color']['background-color']?> none repeat scroll 0 0 !important;
}
.wpb-js-composer .vc_tta-color-white.vc_tta-style-classic .vc_tta-panel.vc_active .vc_tta-panel-title > a, .wpb-js-composer .vc_tta-color-white.vc_tta-style-classic .vc_tta-panel .vc_tta-panel-title > a{
	color: <?php echo $consult_opt['element_color']?> !important;
}
    
<?php
    return ob_get_clean();
}

/**
 * Enqueue scripts and styles.
 */
function consult_scripts() {
    // Add custom fonts, used in the main stylesheet.
	wp_enqueue_style( 'consult-fonts', consult_fonts_url(), array(), null );
    
    // Bootstrap Min CSS
	wp_enqueue_style( 'bootstrap-min', get_template_directory_uri() . '/css/bootstrap.min.css' );
    
    // Icofont CSS
	wp_enqueue_style( 'iconfont', get_template_directory_uri() . '/css/icofont.css' );
    
    // Font Awesome
	wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css' );
    
    // Animate
	wp_enqueue_style( 'animate', get_template_directory_uri() . '/css/animate.css' );
    
    // Meanmenu
	wp_enqueue_style( 'meanmenu', get_template_directory_uri() . '/css/meanmenu.min.css' );
    
    // Venobox
	wp_enqueue_style( 'venobox', get_template_directory_uri() . '/css/venobox.css' );
    
    // Owl Carousel
	wp_enqueue_style( 'owl-carousel', get_template_directory_uri() . '/css/owl.carousel.css' );
    
    // Main Style
	wp_enqueue_style( 'consult-style', get_stylesheet_uri() );
    
    wp_add_inline_style( 'consult-style', consult_inline_stylesheet() );
    
	
    // Bootstrap Script
	wp_enqueue_script( 'bootstrap-min', get_template_directory_uri() . '/js/bootstrap.min.js', array('jquery'), '3.3.7', true );
    
    // Waypoints Script
	wp_enqueue_script( 'Waypoints', get_template_directory_uri() . '/js/waypoints.min.js', array('jquery'), '2.0.3', true );
    
    // Counter Script
	wp_enqueue_script( 'counterup', get_template_directory_uri() . '/js/jquery.counterup.min.js', array('jquery'), '1.0', true );
    
    // Counter Script
	wp_enqueue_script( 'meanmenu', get_template_directory_uri() . '/js/jquery.meanmenu.min.js', array('jquery'), '1.0', true );
    
    // Counter Script
	wp_enqueue_script( 'easing', get_template_directory_uri() . '/js/jquery.easing.1.3.min.js', array('jquery'), '1.3', true );
    
    // Counter Script
	wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/js/owl.carousel.min.js', array('jquery'), '1.0', true );
    
    // Counter Script
	wp_enqueue_script( 'parallax', get_template_directory_uri() . '/js/jquery.parallax-1.1.3.js', array('jquery'), '1.1.3', true );
    
    // Counter Script
	wp_enqueue_script( 'masonry', get_template_directory_uri() . '/js/masonry.pkgd.min.js', array('jquery'), '4.1.1', true );
    
    // Counter Script
	wp_enqueue_script( 'venobox', get_template_directory_uri() . '/js/venobox.min.js', array('jquery'), '1.7.1', true );
	
	// Lettering Jquery
	wp_enqueue_script( 'lettering', get_template_directory_uri() . '/js/jquery.lettering.js', array('jquery'), '0.7.0', true );
    
    // Animated Headline
    wp_enqueue_script( 'headline', get_template_directory_uri() . '/js/animated-headline.js', array('jquery'), '0.7.0', true );
	
	// consult Main Jquery
	wp_enqueue_script( 'consult-main', get_template_directory_uri() . '/js/main.js', array('jquery'), '1.0.0', true );
    
    wp_enqueue_script( 'consult-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'consult-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'consult_scripts' );


/**
*Custom Admin Style 
*/
function consult_admin_acripts(){
	wp_enqueue_style('thickbox');

	wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');

	 wp_enqueue_script('upload_media_widget', get_template_directory_uri() . '/js/upload-media.js', array('jquery'));
}
add_action('admin_enqueue_scripts','consult_admin_acripts');
/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Load TGM plugin file.
 */
require get_template_directory() . '/inc/tgm-plugin/class-tgm-plugin-activation.php';
require get_template_directory() . '/inc/tgm-plugin/required-plugins.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
 * Widget
 */
require_once get_template_directory() . '/inc/widgets/register-widget.php';
/**
 * Load Redux Framework file.
 */
if ( file_exists( get_template_directory().'/inc/consult-config.php' ) ) {
  require_once( get_template_directory().'/inc/consult-config.php' );
}
/**
 * Load global function file.
 */
require_once get_template_directory() . '/inc/global-function.php';
require_once get_template_directory() . '/inc/consult_metabox.php';


// Replaces the excerpt "more" text by a link
function consult_new_excerpt_more($more) {
	return '';
}
add_filter('excerpt_more', 'consult_new_excerpt_more');

//ertrer
global $consult_opt;
if(isset($consult_opt['map_apy_key']) && !empty($consult_opt['map_apy_key'])){
	add_action('wp_enqueue_scripts', 'consult_googlemap_api_enqueue');
	add_action('wp_footer', 'consult_googlemap', 31);
}
// Inline Script for partner Carosel 
function consult_partner_script() {
 global $consult_opt;
 ?>
 <script type="text/javascript">
 var consult_partnernumber = <?php if(isset($consult_opt['partnernumber'])) { echo esc_js($consult_opt['partnernumber']); } else { echo '6'; } ?>,
 consult_partnerscroll = <?php echo esc_js($consult_opt['partnerscroll'])==1 ? 'true': 'false'; ?>;
 </script> 

 <?php
}
add_action( 'wp_enqueue_scripts', 'consult_partner_script' );


function consult_excerpt_by_id($post, $length = 10, $tags = '<a><em><strong>') {
 
	if(is_int($post)) {
		// get the post object of the passed ID
		$post = get_post($post);
	} elseif(!is_object($post)) {
		return false;
	}
 
	if(has_excerpt($post->ID)) {
		$the_excerpt = $post->post_excerpt;
		return apply_filters('the_content', $the_excerpt);
	} else {
		$the_excerpt = $post->post_content;
	}
 
	$the_excerpt = strip_shortcodes(strip_tags($the_excerpt), $tags);
	$the_excerpt = preg_split('/\b/', $the_excerpt, $length * 2+1);
	$excerpt_waste = array_pop($the_excerpt);
	$the_excerpt = implode($the_excerpt);
 
	return apply_filters('the_content', $the_excerpt);
}
function chefs_cuisine_comment_reply($content) {
    $content = str_replace('Reply', '<i class="icofont icofont-reply"></i> Reply ', $content);
    return $content;
}
add_filter('comment_reply_link', 'chefs_cuisine_comment_reply');