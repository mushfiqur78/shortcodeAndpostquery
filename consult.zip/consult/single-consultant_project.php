<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package consult
 */
get_header(); 
consult_pages_breadcrumb();
global $consult_opt;
while ( have_posts() ) { the_post();
?>
    <div class="singleblog_page inner_page">
        <div class="blog_area">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12">
                        <div id="primary" class="content-area">
                            <main id="main" class="site-main" role="main">
                                <?php
                                    get_template_part( 'template-parts/project', 'single' );
                                    // If comments are open or we have at least one comment, load up the comment template.
                                ?>
                            </main><!-- #main -->
                        </div><!-- #primary -->
                    </div>
                </div>
            </div>
        </div>
	</div>
<?php
    }// End of the loop.
get_footer();
