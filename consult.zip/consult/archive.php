<?php
/**
 * The template for displaying archive pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package consult
 */

get_header(); 
consult_archive_breadcrumb();
    
$sidebar_possition = consult_sidebar_layoutpossition('blog_layout', 'sidebarblog_pos');

?> 
   <!-- ====START ARCHIVE AREA==== -->
    <div class="blog_masonry section-padding masonarypage inner_page">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 <?php echo esc_attr('col-sm-' . $sidebar_possition['blogcolwidth']); if($sidebar_possition['blogsidebar'] == 'left'){ echo ' pull-right'; } ?>">               
                    <div class="grid">
                        <?php
                        if ( have_posts() ) :
                            /* Start the Loop */
                            while ( have_posts() ) : the_post();
                                /*
                                 * Include the Post-Format-specific template for the content.
                                 * If you want to override this in a child theme, then include a file
                                 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
                                 */
                                get_template_part( 'template-parts/content', get_post_format() );
                            endwhile;
                        else :
                            get_template_part( 'template-parts/content', 'none' );
                        endif; ?>                       
                    </div>
                    <div class="clearfix"></div> 
                    <div class="col-sm-12 text-center">
                    <?php the_posts_pagination( array(
                        'type'      => 'list',
                        'prev_text' => '<i class="icofont icofont-long-arrow-left"></i>',
                        'next_text' => '<i class="icofont icofont-long-arrow-right"></i>',
                        'before_page_number' => '<span class="meta-nav screen-reader-text">' . esc_html__( 'Page', 'consult' ) . ' </span>',
                        ) ); ?>
                    </div>
                </div>
                <!-- Sidebar -->
                <?php if( $sidebar_possition['blogsidebar'] =='left' || $sidebar_possition['blogsidebar'] =='right') : ?>
                    <?php get_sidebar(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- ====END ARCHIVE AREA==== -->
<?php
get_footer();
