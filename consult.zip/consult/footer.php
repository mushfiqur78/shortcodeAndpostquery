<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package consult
 */

?>

	</div><!-- #content -->

    <!-- ====MAP AREA START==== -->
       <?php
        if(is_active_sidebar( 'footer-sidebar' )){
            global $consult_opt;
            if(!empty($consult_opt['map_apy_key'])) { ?>	
                <section id="footermap" class="map_area">
                    <div class="container-fluid">
                        <div class="row">
                            <div id="map"></div>
                        </div>
                    </div>
                </section>
            <?php }
        }?>
    <!-- ====MAP AREA END==== -->

    <!-- ====Footer AREA START==== -->
    <footer class="footer_area">
        <?php
        global $consult_opt;
        if ( is_active_sidebar( 'footer-sidebar' ) ) : ?>
        <div class="container">
            <div class="row in_footermap">
                <div class="col-sm-12">
                    <div class="scroll_button">
                        <?php if(!empty($consult_opt['map_apy_key'])) { ?>	
                        <i class="icofont icofont-scroll-long-up"></i>
                        <p><a><?php esc_html_e('MAP HERE', 'consult'); ?></a></p>
                        <?php } ?>
                    </div>
                </div>
            </div>
            
            <div class="row">
               <?php dynamic_sidebar( 'footer-sidebar' ); ?>
                
            </div>
        </div>
        <?php endif; ?>
        <div class="footer_bottom">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="ft_bottom">
                            <p><?php consult_copyright(); ?></p>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="ft_bottom">
                            <p class="text-right"><?php consult_footerright(); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
