<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package consult_-_Agency_&_Corporate_WordPress_Theme
 */
$bloglayout = 'sidebar';
global $consult_opt;
if(isset($consult_opt['blog_layout']) && $consult_opt['blog_layout']!=''){
	$bloglayout = $consult_opt['blog_layout'];
}
if($bloglayout == 'sidebar'){
    $post_thumb = 'consult_sidebar-thumb';
}else{
    $post_thumb = 'consult_fullwidth-thumb';
}
?>
<div id="post-<?php the_ID(); ?>" <?php post_class('service_cotent'); ?>>
    <div class="service_photo">
        <?php if ( has_post_thumbnail() ) { ?>
            <figure class="post_img">
                <?php the_post_thumbnail( $post_thumb, array( 'class' => 'img-responsive' ) ); ?>
            </figure>
        <?php } ?>
        <div class="section_title">
            <h2><?php the_title(); ?></h2>
            
        </div>
    </div>
    <div class="service_content_detail">
       <?php the_content();
            wp_link_pages( array(
                'before'      => '<div class="pagination"><span class="page-links-title">' . esc_html__( 'Pages:', 'consult' ) . '</span>',
                'after'       => '</div>',
                'link_before' => '<span>',
                'link_after'  => '</span>',
            ) );
        ?>
    </div>
    <div class="tag_share">
        <!-- Blog post tsgs -->
        <?php if(has_tag()) { ?>
        <div class="tags">
            <ul>
                <li><i class="icofont icofont-tag"></i></li>
                <?php the_tags( '<li>', '</li> <li>', '</li>' ); ?>
            </ul>
        </div><!-- Blog post tags ends -->
        <?php } ?>
        <!-- Sharing Social icons -->
        <div class="social_icons">
         <?php consult_blog_sharing(); ?>
        </div><!-- Sharing social icons ends -->
    </div>
</div>