<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package consult
 */

$sidebar_possition = consult_sidebar_layoutpossition('blog_layout', 'sidebarblog_pos');

if($sidebar_possition['blogcolwidth'] == 9){
    $singleblogcolwidth = 2;
}else{
	$singleblogcolwidth = 3;
}

?>
<div class="<?php echo esc_attr('blog-col-' . $singleblogcolwidth); ?>">
    <div <?php post_class('grid-item'); ?>>
        <div class="single_blog">
            <figure class="blog_item">
                <?php
                if(has_post_thumbnail()){
                    the_post_thumbnail('consult_post-thumb');
                } else{
                    echo '<div class="no_thumbnail"></div>';
                }
                ?>
                <div class="blog_text">
                    <h6><?php the_time(esc_html__('d M, Y', 'consult')); ?></h6>
                        <?php the_title( '<h4><a href="' . esc_url( get_permalink() ) . '">', '</a></h4>' ); ?>
                    <h5><i class="icofont icofont-ui-user"></i>
                        <?php esc_html_e('by', 'consult'); ?> 
                        <?php the_author_posts_link(); ?>
                    </h5>
                    <?php the_excerpt();
                    wp_link_pages( array(
                            'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'consult' ),
                            'after'  => '</div>',
                        ) );
                    ?>                    
                    
                    <a href="<?php echo esc_url( get_permalink()); ?>">
                        <?php consult_blog_read_more(); ?>
                    </a>
                </div>
            </figure>
        </div>
    </div>
</div>
