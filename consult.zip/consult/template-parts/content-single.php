<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package consult_-_Agency_&_Corporate_WordPress_Theme
 */
$sidebar_possition = consult_sidebar_layoutpossition('blog_layout', 'sidebarblog_pos');

if($sidebar_possition['blogcolwidth'] == 9){
    $post_thumb = 'consult_sidebar-thumb';
}else{
    $post_thumb = 'consult_fullwidth-thumb';
}
?>
	<div id="post-<?php the_ID(); ?>" <?php post_class('single_post'); ?>>
        <?php if ( has_post_thumbnail() ) { ?>
            <figure class="post_img">
                <?php the_post_thumbnail( $post_thumb, array( 'class' => 'img-responsive' ) ); ?>
                <h4>
                   <?php the_time(esc_html__('d M', 'consult')); ?>
                </h4>
            </figure>
        <?php } ?>
        <div class="post_cont">
            <h4 class="post_title"><?php the_title(); ?></h4>
            <ul class="post_admin">
                <li><i class="icofont icofont-user-male"></i>
                    <?php the_author_posts_link(); ?>
                </li>
                <li><i class="icofont icofont-speech-comments"></i>
                   <?php comments_popup_link( esc_html__('No Comment','consult'), esc_html__('1 Comment', 'consult'), esc_html__('% Comments','consult'), ' ', esc_html__('Comments off','consult')); ?>
                </li>
                <?php if(has_tag()) { ?>
                <li><i class="icofont icofont-tag"></i>
                    <?php the_tags( '', ', ', '' ); ?>
                </li>
                <?php } ?>
            </ul>
            <?php the_content();
                wp_link_pages( array(
                    'before'      => '<div class="pagination"><span class="page-links-title">' . esc_html__( 'Pages:', 'consult' ) . '</span>',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                ) );
            ?>
            <div class="tag_share">
                <!-- Blog post tsgs -->
                <?php if(has_tag()) { ?>
                <div class="tags">
                    <ul>
                        <li><i class="icofont icofont-tag"></i></li>
                        <?php the_tags( '<li>', '</li> <li>', '</li>' ); ?>
                    </ul>
                </div><!-- Blog post tags ends -->
                <?php } ?>
                <!-- Sharing Social icons -->
                <div class="social_icons">
                 <?php consult_blog_sharing(); ?>
                </div><!-- Sharing social icons ends -->
            </div>
        </div>
    </div>
	<?php $authordesc = get_the_author_meta( 'description' );
	if ( ! empty ( $authordesc ) ) { ?>
	<div class="about_auther">
		<div class="auther">
			<?php
			$author_bio_avatar_size = apply_filters( 'consult_author_bio_avatar_size', 163 );
			echo get_avatar( get_the_author_meta( 'user_email' ), $author_bio_avatar_size );
			?>
		</div>
		<div class="auther_details">
			<h5><a href="<?php the_author_link(); ?>"><?php the_author(); ?></a></h5>
			<p><?php echo esc_html($authordesc); ?></p>
		</div>
	</div>
	<?php } ?>