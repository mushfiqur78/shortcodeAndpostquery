<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package consult_-_Agency_&_Corporate_WordPress_Theme
 */
$bloglayout = 'sidebar';
global $consult_opt;
if(isset($consult_opt['blog_layout']) && $consult_opt['blog_layout']!=''){
	$bloglayout = $consult_opt['blog_layout'];
}
if($bloglayout == 'sidebar'){
    $post_thumb = 'consult_sidebar-thumb';
}else{
    $post_thumb = 'consult_fullwidth-thumb';
}
$item_cats = get_the_terms($post->ID, 'project_category');
$item_classes = '';
if($item_cats):
foreach($item_cats as $item_cat) {
	$item_classes .= $item_cat->slug . ', ';
}
endif;
$client_name = get_post_meta($post->ID, '_consult_client_name', true);
$pro_result = get_post_meta($post->ID, '_consult_result', true);
$result_text = get_post_meta($post->ID, '_consult_result_text', true);
$singslider = get_post_meta($post->ID, '_consult_pro_sli', true);
?>
<!-- ====START PORTFOLIO CONTENT AREA==== -->
<div id="post-<?php the_ID(); ?>" <?php post_class('Portfoliopage_content'); ?>>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6">
                <div class="project_details">
                    <h3><?php the_title(); ?></h3>
                    <p><?php the_content(); ?></p>
                    <ul class="pro_des">
                        <li>
                            <p><?php if(!empty($client_name)){esc_html_e('by', 'consult');} ?></p>
                            <span><?php echo esc_html($client_name); ?></span>
                        </li>
                        <li>
                            <p><?php if(!empty($item_classes)){esc_html_e('Category', 'consult');} ?></p>
                            <span><?php echo esc_html($item_classes); ?></span>
                        </li>
                        <li>
                            <p><?php esc_html_e('COMPLETED', 'consult'); ?></p>
                            <span><?php the_time(esc_html__('d M Y', 'consult')); ?></span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="projectman">
                    <?php if ( has_post_thumbnail() ) { ?>
                        <figure>
                            <?php the_post_thumbnail( $post_thumb, array( 'class' => 'img-responsive' ) ); ?>
                        </figure>
                    <?php } ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <?php if(!empty($pro_result)){ ?>
                <h4 class="det_bottom"><?php echo esc_html($pro_result); ?></h4>
                
                <p class="det_para"><?php echo esc_html($result_text); ?></p>
                <?php } ?> 
            </div>
        </div>
    </div>
</div>
<!-- ====END PORTFOLIO CONTENT AREA==== --> 

<!-- ====OUR PROJECT STAR==== -->
<div class="single_project_slider section-padding">
    <div class="pro_slider_box">
            <div class="row">
                <div class="col-sm-12">
                    <div class="pro_sing_slider">
                        <?php if (is_array($singslider)){
                            foreach($singslider as $pro_item){ ?>
                            <div class="single_prject">
                                <figure class="project_photo">
                                    <img src="<?php echo esc_html($pro_item); ?>" alt="" />
                                </figure>
                            </div>
                            <?php }
                        } ?>
                    </div>
                </div>
            </div>
        <ul class="pro_sing_nav">
            <li>
                <i class="icofont icofont-long-arrow-left testi_next"></i>
            </li>
            <li>
                <i class="icofont icofont-long-arrow-right testi_prev"></i>
            </li>
        </ul>
    </div>
</div>
<!-- ====OUR PROJECT END==== -->  