<form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="searchfield" role="search">
    <button type="submit" class="submit">
        <i class="fa fa-search"></i>
    </button>
    <input type="search" class="form-control" name="s" placeholder="<?php echo esc_attr_x( 'Search', 'placeholder', 'consult' ); ?>" value="<?php echo get_search_query(); ?>">
</form>