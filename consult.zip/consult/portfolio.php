<?php
/**
 * Template Name:Project Page
 *
 * This is the template that displays Servoce page.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package consult
 */
get_header(); 
consult_pages_breadcrumb();
global $consult_opt;
?>
    <div class="portfolio_page inner_page">
        <div class="servicepage_area section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12">
                        <div id="primary" class="content-area">
                            <main id="main" class="site-main" role="main">
                                <?php 
                                    $sonsult_project = null;
                                    $sonsult_project = new WP_Query(array(
                                        'post_type' => 'consultant_project',
                                        'posts_per_page'=> 9
                                    ));

                                    if( $sonsult_project->have_posts() ){
                                        while( $sonsult_project->have_posts() ){
                                            $sonsult_project->the_post();
                                            $length = $consult_opt['portfolio_length'] ? $consult_opt['portfolio_length'] : 2;
                                        ?>
                                            <div class="col-xs-12 col-sm-4">
                                                <div class="servicepage_details">
                                                    <div class="servicepage_photo">
                                                        <figure>
                                                             <?php the_post_thumbnail('consult_service_pg_img');?>
                                                            <figcaption>
                                                                <a href="<?php the_permalink(); ?>">
                                                                    <i class="icofont icofont-link"></i>
                                                                </a>
                                                            </figcaption>
                                                        </figure>
                                                        <div class="servicepage_heading">
                                                            <?php the_title( '<h4><a href="' . esc_url( get_permalink() ) . '">', '</a></h4>' ); ?>
                                                            <?php echo consult_excerpt_by_id(get_the_ID(), $length  ); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php }

                                            }else{
                                                echo 'No post';
                                            }
                                            wp_reset_postdata();
                                        ?>
                            </main><!-- #main -->
                        </div><!-- #primary -->
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
get_footer();