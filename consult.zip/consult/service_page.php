<?php
/**
 * Template Name:Service Page
 *
 * This is the template that displays Servoce page.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package consult
 */
get_header(); 
consult_pages_breadcrumb();
global $consult_opt;
?>
    <div class="service_page inner_page">
        <div class="servicepage_area section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12">
                        <div id="primary" class="content-area">
                            <main id="main" class="site-main" role="main">
                                <?php 
                                    $sonsult_service = null;
                                    $sonsult_service = new WP_Query(array(
                                        'post_type' => 'consultant_service',
                                        'posts_per_page'=> 9
                                    ));
                                    if( $sonsult_service->have_posts() ){
                                        while( $sonsult_service->have_posts() ){
                                            $sonsult_service->the_post();
                                            $length = $consult_opt['service_length'] ? $consult_opt['service_length'] : 10;
                                        ?>
                                            <div class="col-xs-12 col-sm-6 col-md-4">
                                                <div class="servicepage_details">
                                                    <div class="servicepage_photo">
                                                        <figure>
                                                            <?php the_post_thumbnail('consult_service_pg_img');?>
                                                        </figure>
                                                        <div class="servicepage_heading">
                                                             <?php the_title( '<h4><a href="' . esc_url( get_permalink() ) . '">', '</a></h4>' );
                                                            echo consult_excerpt_by_id(get_the_ID(), $length  ); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php }

                                            }else{
                                                echo 'No post';
                                            }
                                            wp_reset_postdata();
                                        ?>
                            </main><!-- #main -->
                        </div><!-- #primary -->
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
get_footer();