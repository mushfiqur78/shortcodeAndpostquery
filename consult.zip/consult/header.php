<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package consult
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="<?php echo consult_is_sticky_menu(); ?>">
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="profile" href="http://gmpg.org/xfn/11">

        <?php wp_head(); ?>
    </head>
  <?php 
 function consult_header_layout(){
    // Header layout
	global $consult_opt;
	if ( $consult_opt['header_layout']=='default' || !isset($consult_opt['header_layout'])) {
		get_header('v1');
	} else {
		get_header($consult_opt['header_layout']);
	};
 }   
$consult_pg_header =  get_post_meta(get_the_ID(),'_consult_page_header',true); 
   if( is_page() ):
        if( ($consult_pg_header==2) ){
     get_header('v2'); 
    }
    elseif( ($consult_pg_header==3) ){
        get_header('v3'); 
    }
    else{
        get_header('v1');
    }
   else:
        consult_header_layout();
   endif; 
  ?>
