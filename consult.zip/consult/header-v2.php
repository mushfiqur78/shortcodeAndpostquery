<body <?php body_class('home_2'); ?>>
<div class="page_warapper">
	<a class="skip-link screen-reader-text" href="#content">
	    <?php esc_html_e( 'Skip to content', 'consult' ); ?>
	</a>
	<header id="masthead" class="site-header">
        <div class="manu_area hidden-xs">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                        <div class=" logo">
                            <?php global $consult_opt; 
                                consult_logo( $consult_opt['logo_2']['url'] ); 
                            ?>
                        </div>
                    </div>
                    <div class="col-sm-9">
                        <div class="header_top">
                            <ul class="top_contact part_1 text-right">
                               <?php if(consult_top_bar_phone() ){ ?>
                                <li>
                                    <i class="icofont icofont-phone"></i>
                                    <a href="tel:<?php echo esc_attr(consult_top_bar_phone()); ?>">
                                        <?php echo esc_html(consult_top_bar_phone()); ?>
                                    </a>
                                </li>
                                <?php } ?>
                                <?php if(consult_top_bar_email() ){ ?>
                                <li>
                                    <a href="mailto:info@consult.com">
                                        <i class="icofont icofont-envelope"></i>
                                        <?php echo esc_html(consult_top_bar_email()); ?>
                                    </a>
                                </li>
                                <?php } ?>
                            </ul>
                            <?php consult_socialicons(); ?>
                            <div class="top_contact">
                               <?php get_search_form(); ?>
                            </div>
                        </div>
                        <div class="mainnmenu">
                            <div class="mainnmenu">
                                <nav>
                                    <?php consult_main_menu(); ?>
                                </nav>
                                <nav class="mb_menu hidden">
                                    <?php consult_mobile_menu(); ?>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</header><!-- #masthead -->

	<div id="content" class="site-content">
