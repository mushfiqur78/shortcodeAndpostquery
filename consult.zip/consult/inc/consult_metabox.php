<?php

add_action( 'cmb2_admin_init', 'consult_metabox' );

function consult_metabox() {

	$prefix = '_consult_';
	
    // metabox support for Consult Project
	$cmb2_project = new_cmb2_box( array(
		'id'           => $prefix . 'project_area',
		'title'        => esc_html__( 'Portfolio Settings', 'consult' ),
		'object_types' => array( 'consultant_project'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );

	$cmb2_project->add_field( array(
	    'name'    =>  esc_html__( 'Client Name', 'consult' ),
	    'id'      =>  $prefix . 'client_name',
	    'type'    =>  'text',
	    'default' =>  esc_html__( 'Jeremy House', 'consult' ),
	) );

	$cmb2_project->add_field( array(
	    'name'    =>  esc_html__( 'Result', 'consult' ),
	    'id'      =>  $prefix . 'result',
	    'type'    =>  'text',
	    'default' =>  esc_html__( 'Result Title', 'consult' ),
	) );

	$cmb2_project->add_field( array(
	    'name'    =>  esc_html__( 'Result Text', 'consult' ),
	    'id'      =>  $prefix . 'result_text',
	    'type'    =>  'textarea',
	    'default' =>  esc_html__( 'Result Text', 'consult' ),
	) );

	$cmb2_project->add_field( array(
	    'name'    =>  esc_html__( 'slider single Project', 'consult' ),
	    'id'      =>  $prefix . 'pro_sli',
	    'type'    =>  'file_list',
	    'default' =>  esc_html__( 'Result Text', 'consult' ),
	) );
    
    // metabox support for Our Advisore
	$cmb2_advisore = new_cmb2_box( array(
		'id'           => $prefix . 'our_advisore',
		'title'        => esc_html__( 'Advisore Section Setting', 'consult' ),
		'object_types' => array( 'consultant_advisore'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );

	$cmb2_advisore->add_field( array(
	    'name'    =>  esc_html__( 'Advisore Designation', 'consult' ),
	    'id'      =>  $prefix . 'desig',
	    'type'    =>  'text',
	    'default' =>  esc_html__( 'Advisore Designation', 'consult' ),
	) );
    $cmb2_advisore->add_field( array(
	    'name'    => esc_html__( 'Facebook Link', 'consult' ),
	    'id'      =>  $prefix.'fb_link',
	    'type'    => 'text_url',
		'desc' => esc_html__( 'Use http, https before link', 'consult' )
	));	

	$cmb2_textimonials = new_cmb2_box( array(
		'id'           => $prefix . 'testimonial',
		'title'        => esc_html__( 'Client Designation Setting', 'consult' ),
		'object_types' => array( 'consult_testimonial'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );
    $cmb2_textimonials->add_field( array(
	    'name'    => esc_html__( 'Client Designation', 'consult' ),
	    'id'      =>  $prefix.'clientdgi',
	    'type'    => 'text',
		'desc' => esc_html__( 'CEO, AVION', 'consult' )
	));	
    $cmb2_advisore->add_field( array(
	    'name'    => esc_html__( 'Twitter Link', 'consult' ),
	    'id'      =>  $prefix.'tw_link',
	    'type'    => 'text_url',
		'desc' => esc_html__( 'Use http, https before link', 'consult' )
	));		
    $cmb2_advisore->add_field( array(
	    'name'    => esc_html__( 'Twitter Link', 'consult' ),
	    'id'      =>  $prefix.'ldin_link',
	    'type'    => 'text_url',
		'desc' => esc_html__( 'Use http, https before link', 'consult' )
	));		
    $cmb2_advisore->add_field( array(
	    'name'    => esc_html__( 'Skype Link', 'consult' ),
	    'id'      =>  $prefix.'sky_link',
	    'type'    => 'text_url',
		'desc' => esc_html__( 'Use http, https before link', 'consult' )
	));
    
    
	// metabox for page slider or banner
	$cmb2_headerfooter = new_cmb2_box( array(
		'id'           => $prefix . 'page_header_optons',
		'title'        => esc_html__( 'Page Settings', 'consult' ),
		'object_types' => array( 'page'), // Post type
        'show_on_cb' => 'consult_metabox_exclude_blog_page',
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );

	$cmb2_headerfooter->add_field( array(
	    'name'             =>  esc_html__( 'Select Header', 'consult' ),
	    'id'               => $prefix . 'page_header',
	    'desc'             => esc_html__( 'Select any one.which you want to display','consult' ),
	    'type'             => 'select',
	    'default'          => '1',
	    'options'          => array(
	        '1' => esc_html__( 'Header v1', 'consult' ),
	        '2'   => esc_html__( 'Header v2', 'consult' ),
	        '3'   => esc_html__( 'Header v3', 'consult' ),
	    ),
	) ); 
}

