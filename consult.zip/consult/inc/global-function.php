<?php
// Display header top bar
function consult_header_top_show(){
	global $consult_opt;
    if( class_exists( 'ReduxFrameworkPlugin' ) ){
        return $consult_opt['show_header_top_bar'];
    }else{
        return 1;
    }
}
// Phone number
function consult_top_bar_phone(){
    global $consult_opt;
    $return = (isset($consult_opt['top_bar_phone']) && !empty($consult_opt['top_bar_phone'])) ? $consult_opt['top_bar_phone'] : false;
	return $return;
}

// Email Address
function consult_top_bar_email(){
	global $consult_opt;
    $return = (isset($consult_opt['top_bar_email']) && !empty($consult_opt['top_bar_email'])) ? $consult_opt['top_bar_email'] : false;
	return $return;
}
//Add google map API
function consult_googlemap_api(){
	global $consult_opt;
	//Add google map API
	$google_map_js_url = 'https://maps.googleapis.com/maps/api/js?key=' . $consult_opt['map_apy_key'];
	return esc_url_raw($google_map_js_url);
}

//For enqueue google map script
function consult_googlemap_api_enqueue(){
	wp_enqueue_script( 'google-map', consult_googlemap_api(), array(), null );
}
// Consult hearder top
function consult_hearder_top(){
	if( consult_header_top_show() == true) : ?>
	    <div class="header_top_area">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-md-offset-7">
                        <div class="header_top">
                            <ul class="top_contact">
                                <?php if( consult_top_bar_phone() ){ ?>
                                <li>
                                    <i class="icofont icofont-phone"></i>
                                    <a href="tel:<?php echo esc_attr(consult_top_bar_phone()); ?>">
                                        <?php echo esc_html(consult_top_bar_phone()); ?>
                                    </a>
                                </li>
                                <?php } ?>
                                <?php if( consult_top_bar_email() ){ ?>
                                <li>
                                    <a href="mailto:<?php echo esc_attr(consult_top_bar_email()); ?>">
                                        <i class="icofont icofont-envelope"></i> 
                                        <?php echo esc_html(consult_top_bar_email()); ?>
                                    </a>
                                </li>
                                <?php } ?>
                                <li>
                                    <form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="searchfield" role="search">
                                        <button type="submit" class="submit">
                                            <i class="fa fa-search"></i>
                                        </button>
                                        <input type="text" class="form-control" name="s" placeholder="<?php echo esc_attr_x( 'Search', 'placeholder', 'consult' ); ?>" value="<?php echo esc_attr(get_search_query()); ?>">
                                    </form>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	<?php endif;
}
// Topbar Social link
function consult_socialicons(){
	global $consult_opt;
	if(isset($consult_opt['topbar_social_icons'])) {?>							
		<?php echo '<ul class="social_icon top_contact text-right">';
			foreach($consult_opt['topbar_social_icons'] as $key=>$value ) {
				if($value!=''){
					if($key=='vimeo'){
						echo '<li><a class="'.esc_attr($key).' social-icon" href="'.esc_url($value).'" title="'.ucwords(esc_attr($key)).'" target="_blank"><i class="icofont icofont-brand-linkedin"></i></a></li>';
					} else {
						echo '<li><a class="'.esc_attr($key).' social-icon" href="'.esc_url($value).'" title="'.ucwords(esc_attr($key)).'" target="_blank"><i class="icofont icofont-social-'.esc_attr($key).'"></i></a></li>';
					}
				}
			}
			echo '</ul>';
		?>							
	<?php };
}

// Main Menu
function consult_main_menu(){
	wp_nav_menu( array(
        'theme_location'    => 'Mainmenu-1', 
        'container_class'   => '',
        'menu_class'        => 'menu nav',
        'fallback_cb'       => 'consult_menu_cb'
    ));
}
function consult_mobile_menu(){
    wp_nav_menu( array(
        'theme_location'    => 'Mainmenu-1', 
        'container_class'   => '',
        'menu_class'        => 'menu_for_mobile',
        'fallback_cb'       => 'consult_menu_cb'
    ));
}

function consult_menu_cb (){
        echo '<ul class="menu nav">';
        echo '<li><a href="' . admin_url( 'nav-menus.php' ) . '">Add a menu</a></li>';
        echo '</ul>';
}

//Is Sticky Menu?
function consult_is_sticky_menu(){
    global $consult_opt;
    $return = 'sticky_menu_true';
    if(isset($consult_opt['is_sticky_menu']) and !empty($consult_opt['is_sticky_menu'])){
        $return = $consult_opt['is_sticky_menu'];
    }
    return $return;
}

// Display logo
function consult_logo($theme_logo_url = ''){
    $theme_logo = $theme_logo_url;
	if(is_ssl()){
		$theme_logo = str_replace('http:', 'https:', $theme_logo_url);
	}
	
	if( !empty($theme_logo) ){ ?>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
				<img src="<?php echo esc_url($theme_logo); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" />
			</a>
		<?php
		} else { ?>
			<h3 class="navbar-blog-info">
			    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
			        <?php bloginfo( 'name' ); ?>
			    </a>
            </h3>
			<?php
		} ?>
	<?php
}

// Contact copyright text
function consult_copyright(){
	global $consult_opt;
	if( isset($consult_opt['copyright']) && $consult_opt['copyright']!='' ) {
		echo wp_kses($consult_opt['copyright'], array(
			'a' => array(
				'href' => array(),
				'title' => array()
			),
			'br' => array(),
			'em' => array(),
			'strong' => array(),
		));
	} else {
		echo esc_html__('Copyright & copy; 2017 ' , 'consult'). " <a href='".esc_url('themeebit.com')."' target='_blank'>".esc_html__('consult' , 'consult')."</a> ".esc_html__('All Rights Reserved by ThemeeBiT.' , 'consult');

	};
}
// Free Consult Button Text
function consult_free_btnTxt(){
	global $consult_opt;
	if(isset($consult_opt)){ 
        echo esc_html($consult_opt['free_consulbtn']); 
    }else { 
        esc_html_e('free consultation', 'consult');
    }
}
// Free Consult Button Link
function consult_free_btnLink(){
	global $consult_opt;
	if(isset($consult_opt)){ 
        echo esc_html($consult_opt['consulbtn_link']); 
    }else { 
        esc_html_e('#', 'consult');
    }
}

// Contact Footer Right text
function consult_footerright(){
	global $consult_opt;
	if( isset($consult_opt['footerright']) && $consult_opt['footerright']!='' ) {
		echo wp_kses($consult_opt['footerright'], array(
			'a' => array(
				'href' => array(),
				'title' => array()
			),
			'br' => array(),
			'em' => array(),
			'strong' => array(),
		));
	} else {
		echo esc_html__('Developed by ThemeeBiT' , 'consult'). " <a href='".esc_url('themeebit.com')."' target='_blank'>".esc_html__('consult' , 'consult')."</a> ".esc_html__('All Rights Reserved by ThemeeBiT.' , 'consult');
	};
}
// Blog Read More Button Text
function consult_blog_read_more(){
	global $consult_opt;
	if(isset($consult_opt)){ 
        echo esc_html($consult_opt['readmore_text']); 
    } else { 
        esc_html_e('Read More', 'consult');
    }
}

//Change excerpt length
function consult_change_excerpt_length( $length ) {
	global $consult_opt;
	
	if(isset($consult_opt['excerpt_length'])){
		return $consult_opt['excerpt_length'];
	}
	return 16;
}
add_filter( 'excerpt_length', 'consult_change_excerpt_length', 999 );

function consult_metabox_exclude_blog_page() {
    $post_id = 0;

    // If we're showing it based on ID, get the current ID
    if ( isset( $_GET['post'] ) ) {
        $post_id = $_GET['post'];
    } elseif ( isset( $_POST['post_ID'] ) ) {
        $post_id = $_POST['post_ID'];
    }

    if ( ! $post_id ) {
        return false;
    }

    // Get ID of page set as front page, 0 if there isn't one
    $blog_page = get_option( 'page_for_posts' );

    // there is a front page set and we're on it!
    return $post_id !== $blog_page;
}
add_filter( 'cmb2_show_on', 'consult_metabox_exclude_blog_page', 10, 2 );

// Consult blog title  dispaly
function consult_blog_header(){
	global $consult_opt;
	if(isset($consult_opt)) { 
        echo esc_html($consult_opt['blog_header_text']); 
    } else { 
        esc_html_e('Our news & blog', 'consult');
    }
}
// display pages breadcrumb
function consult_pages_breadcrumb(){
	global $consult_opt;
	$condition = true;
	if ( class_exists( 'ReduxFrameworkPlugin' ) ){
		$condition = $consult_opt['breadcrumb_on_off'];
	}
	if($condition){ ?>
	
	<!--================================
		2.START PAGE BREADCRUMB AREA CSS
	=================================-->
	<div class="breadcrumb_area pages_bdcmb">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h1><?php the_title();?></h1>
                    <ul>
                        <li><a href="<?php echo esc_url(home_url('/'));?>">
                            <?php esc_html_e('Home' , 'consult');?>
                            </a>
                        </li>
                        <li><?php esc_html_e('/', 'consult'); ?></li>
                        <li class="active"><?php the_title();?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
	<!--================================
		2.END PAGE BREADCRUMB AREA CSS
	=================================-->
	<?php }
}
// display blog breadcrumb
function consult_blogs_breadcrumb(){
	global $consult_opt;
    
	$condition = true;
	if ( class_exists( 'ReduxFrameworkPlugin' ) ){
		$condition = $consult_opt['breadcrumb_on_off_blog']== 1;
	}
	if($condition){ ?>    
	<!--================================
		2.START BLOG BREADCRUMB AREA CSS
	=================================-->
	<div class="breadcrumb_area blog-bdcmb">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h1><?php consult_blog_header(); ?></h1>
                    <ul>
                        <li><a href="<?php echo esc_url(home_url('/'));?>">
                            <?php esc_html_e('Home' , 'consult');?>
                            </a>
                        </li>
                        <li><?php esc_html_e('/', 'consult'); ?></li>
                        <li class="active"><?php consult_blog_header(); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
	<!--================================
		2.END BREADCRUMB AREA CSS
	=================================-->
	<?php }
}


// display archive breadcrumb
function consult_archive_breadcrumb(){
	global $consult_opt;
	$condition = true;
	if ( class_exists( 'ReduxFrameworkPlugin' ) ){
		$condition = $consult_opt['breadcrumb_on_off_blog']== 1;
	}
	if($condition){ ?>
	<!--================================
		2.START BLOG BREADCRUMB AREA CSS
	=================================-->
	<div class="breadcrumb_area blog-bdcmb">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h1><?php the_archive_title( '<h1>', '</h1>' ); ?></h1>
                    <ul>
                        <li><a href="<?php echo esc_url(home_url('/'));?>">
                            <?php esc_html_e('Home' , 'consult');?>
                            </a>
                        </li>
                        <li><?php esc_html_e('/', 'consult'); ?></li>
                        <li class="active"><?php the_archive_title(); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
	<!--================================
		2.END BREADCRUMB AREA CSS
	=================================-->
	<?php }
}

// display Search breadcrumb
function consult_search_breadcrumb(){
	global $consult_opt; 
    
	$condition = true;
	if ( class_exists( 'ReduxFrameworkPlugin' ) ){
		$condition = $consult_opt['breadcrumb_on_off_blog']== 1;
	}
	if($condition){ ?>
	<!--================================
		2.START SEARCH BREADCRUMB AREA CSS
	=================================-->
	<div class="breadcrumb_area blog-bdcmb">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h1><?php printf( esc_html__( 'Search Results for: %s', 'consult' ), '<span>' . get_search_query() . '</span>' ); ?></h1>
                    <ul>
                        <li>
                            <a href="<?php echo esc_url(home_url('/'));?>">
                                <?php esc_html_e('Home' , 'consult');?>
                            </a>
                        </li>
                        <li><?php esc_html_e('/', 'consult'); ?></li>
                        <li class="active"><?php if ( have_posts() ) :
                            printf( '<span>' . get_search_query() . '</span>' );
                                else :
                            esc_html_e( 'Nothing Found', 'consult' );
                            endif; ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
	<!--================================
		2.END BREADCRUMB AREA CSS
	=================================-->
	<?php }
}

// display error page breadcrumb
function consult_error_page_breadcrumb(){
	global $consult_opt;
	$condition = true;
	if ( class_exists( 'ReduxFrameworkPlugin' ) ){
		$condition = $consult_opt['breadcrumb_on_off_error']== 1;
	}
	if($condition){ ?>
	<!--================================
		2.START BREADCRUMB AREA CSS
	=================================-->
	<div class="breadcrumb_area error-page">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h1><?php wp_title(''); ?></h1>
                    <ul>
                        <li><a href="<?php echo esc_url(home_url('/'));?>"><?php esc_html_e('Home' , 'consult');?></a></li>
                        <li><?php esc_html_e('/', 'consult'); ?></li>
                        <li class="active"><?php wp_title(''); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
	<!--================================
		2.END BREADCRUMB AREA CSS
	=================================-->
	<?php }
}

// Consult Single Blog title dispaly
function consult_single_blog_header(){
	global $consult_opt;
	if(isset($consult_opt)) { 
        echo esc_html($consult_opt['single_blog_header_text']); 
    } else { 
        esc_html_e('Our news & blog details', 'consult');
    }
}

// Single Page
function consult_singlepage_breadcrumb(){
	global $consult_opt; 
	$condition = true;
	if ( class_exists( 'ReduxFrameworkPlugin' ) ){
		$condition = $consult_opt['breadcrumb_on_off_blog']== 1;
	}
	if($condition){ ?>
	<!--================================
		2.START SEARCH BREADCRUMB AREA CSS
	=================================-->
	<div class="breadcrumb_area blog-bdcmb">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <h1><?php consult_single_blog_header(); ?></h1>
                    <ul>
                        <li>
                            <a href="<?php echo esc_url(home_url('/'));?>">
                                <?php esc_html_e('Home' , 'consult');?>
                            </a>
                        </li>
                        <li><?php esc_html_e('/', 'consult'); ?></li>
                        <li class="active"><?php the_title(); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
	<!--================================
		2.END BREADCRUMB AREA CSS
	=================================-->
	<?php }
}

function consult_sidebar_layoutpossition($layout, $sidebar_possition, $page_layout=false){
    global $consult_opt;
    $bloglayout = 'sidebar';

    if($page_layout){
        $bloglayout = $page_layout;
    }else{
        if(isset($consult_opt[$layout]) && $consult_opt[$layout]!=''){
            $bloglayout = $consult_opt[$layout];
        }
    }
    
    if(isset($_GET['layout']) && $_GET['layout']!=''){
        $bloglayout = $_GET['layout'];
    }

    $blogsidebar = 'right';
    if(isset($consult_opt[$sidebar_possition]) && $consult_opt[$sidebar_possition]!=''){
        $blogsidebar = $consult_opt[$sidebar_possition];
    }

    if(isset($_GET['sidebar']) && $_GET['sidebar']!=''){
        $blogsidebar = $_GET['sidebar'];
    }

    $returnArray = array(
        'blogcolwidth' => 0,
        'blogsidebar' => $blogsidebar
    );
    
    if($bloglayout == 'sidebar'){
        $blogcolwidth = 9;
        
        $returnArray['blogcolwidth'] = $blogcolwidth;
    }else{
        $blogcolwidth = 12;
        $blogsidebar = 'no-sidebar';
        
        $returnArray['blogcolwidth'] = $blogcolwidth;
        $returnArray['blogsidebar'] = $blogsidebar;
    }
    return $returnArray;
}

/* Blog sharing */
function consult_blog_sharing() {
	global $post, $consult_opt;	
	$share_url = get_permalink( $post->ID );
	$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'large' );
	$postimg = $large_image_url[0];
	$posttitle = get_the_title( $post->ID );
	?>
		<ul class="post_social">
			<li><a class="facebook social-icon" href="#" onclick="javascript: window.open('<?php echo esc_url('https://www.facebook.com/sharer/sharer.php?u='.$share_url); ?>'); return false;" title="Facebook" target="_blank"><i class="icofont icofont-social-facebook"></i></a></li>
			<li><a class="twitter social-icon" href="#" title="Twitter" onclick="javascript: window.open('<?php echo esc_url('https://twitter.com/home?status='.$posttitle.'&nbsp;'.$share_url); ?>'); return false;" target="_blank"><i class="icofont icofont-social-twitter"></i></a></li>
			<li><a class="pinterest social-icon" href="#" onclick="javascript: window.open('<?php echo esc_url('https://pinterest.com/pin/create/button/?url='.$share_url.'&amp;media='.$postimg.'&amp;description='.$posttitle); ?>'); return false;" title="Pinterest" target="_blank"><i class="icofont icofont-social-pinterest"></i></a></li>
			<li><a class="gplus social-icon" href="#" onclick="javascript: window.open('<?php echo esc_url('https://plus.google.com/share?url='.$share_url); ?>'); return false;" title="Google +" target="_blank"><i class="icofont icofont-social-google-plus"></i></a></li>
			<li><a class="linkedin social-icon" href="#" onclick="javascript: window.open('<?php echo esc_url('https://www.linkedin.com/shareArticle?mini=true&amp;url='.$share_url.'&amp;title='.$posttitle); ?>'); return false;" title="LinkedIn" target="_blank"><i class="icofont icofont-social-linkedin"></i></a></li>
		</ul>
	<?php
}
/**
 *  comment list modify 
 */
function consult_comments($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment; ?>
    
	
	<li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
		<div class="comment_list">
            <div class="commenter">
                <?php echo get_avatar( $comment, 82 ); ?>
            </div>
            <div class="about_commenter">
                <h5>
                    <a href="<?php comment_author_url(); ?>">
                        <?php comment_author(); ?>
                    </a>
                </h5>
                <h6>
                    <i class="icofont icofont-calendar"></i> 
                    <?php echo esc_html(get_comment_date('n-j-y')); ?> 
                    <?php echo esc_html(get_comment_date('g:i')); ?>
                </h6>
				
                <?php if ($comment->comment_approved == '0') : ?>
                    <p><em><?php esc_html_e('Your comment is awaiting moderation.','consult'); ?></em></p>
                <?php endif; ?>
				<span class="comment_reply">
					<?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))); ?>
				</span>
                <?php comment_text() ?>
            </div>
		</div>
<?php }

// comment box title change
add_filter( 'comment_form_defaults', 'consult_remove_comment_form_allowed_tags' );
function consult_remove_comment_form_allowed_tags( $defaults ) {

	$defaults['comment_notes_after'] = '';
	$defaults['comment_notes_before'] = '';
	return $defaults;
}

// comment form modify

function consult_modify_comment_form_fields($fields){
	$commenter = wp_get_current_commenter();
	$req	   = get_option( 'require_name_email' );

	$fields['author'] = '<div class="row"><div class="col-md-4">
            <input type="text" placeholder="'. esc_attr__("Your Name *", "consult").'" name="author" value="'. esc_attr( $commenter['comment_author'] ) .'" '. ( $req ? 'aria-required="true"' : '' ).'></div>';


	$fields['email'] = '<div class="col-md-4">
            <input type="email" placeholder="'. esc_attr__("Your Email *", "consult").'" name="email" value="'. esc_attr( $commenter['comment_author_email'] ) .'" '. ( $req ? 'aria-required="true"' : '' ).'></div>';
	
	$fields['url'] = '<div class="col-md-4">
            <input type="text" placeholder="'. esc_attr__("Your Website", "consult").'" name="website" value="'. esc_attr( $commenter['comment_author_url'] ) .'" '. ( $req ? 'aria-required="false"' : '' ).'></div></div>';

	return $fields;
}
add_filter('comment_form_default_fields','consult_modify_comment_form_fields'); 

function consult_comment_reform ($arg) {

$arg['title_reply'] = esc_html__('Leave a Reply','consult');
$arg['comment_field'] = '<div class="row"><div class="col-md-12">
    <textarea id="comment" class="comment_field" name="comment" cols="77" rows="8" placeholder="'. esc_html__("Write your Comment", "consult").'" aria-required="true">
    </textarea></div></div>';

return $arg;

}
add_filter('comment_form_defaults','consult_comment_reform');

// Google map 
function consult_googlemap (){ 
	global $consult_opt; 
	$map_desc = str_replace(array("\r\n", "\r", "\n"), "<br />", $consult_opt['map_desc']);
	$map_desc = addslashes($map_desc);
	ob_start(); 
?>
		<script type="text/javascript">
        var myCenter=new google.maps.LatLng(<?php if(isset($consult_opt['map_lat'])) { echo esc_js($consult_opt['map_lat']); } else { echo '40.76732'; } ?>, <?php if(isset($consult_opt['map_long'])) { echo esc_js($consult_opt['map_long']); } else { echo '-74.20487'; } ?>);
            function initialize()
            {
            var mapProp = {
              center:myCenter,
              zoom:<?php if(isset($consult_opt['map_zoom'])) { echo esc_js($consult_opt['map_zoom']); } else { echo 14; } ?>,
              scrollwheel:<?php if($consult_opt['map_scrollwheel'] == 0 ) { echo 'false'; } else { echo 'true'; } ?>,
              mapTypeId:google.maps.MapTypeId.ROADMAP,
                styles: [{"featureType":"water","elementType":"geometry","stylers":[{"color":"<?php echo esc_js($consult_opt['map_color']);?>"},{"lightness":17}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":20}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffffff"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#ffffff"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":16}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":21}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#dedede"},{"lightness":21}]},{"elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"lightness":16}]},{"elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#333333"},{"lightness":40}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#f2f2f2"},{"lightness":19}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#fefefe"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#fefefe"},{"lightness":17},{"weight":1.2}]}]
              };

            var map=new google.maps.Map(document.getElementById("map"),mapProp);

            var marker=new google.maps.Marker({
              position:myCenter,
              animation:google.maps.Animation.BOUNCE,
              icon:'<?php if( isset($consult_opt['map_marker']['url']) && $consult_opt['map_marker']['url']!='') :
					echo esc_js($consult_opt['map_marker']['url']);
				else :
					echo get_template_directory_uri() . '/img/map-marker.png';
				endif; ?>'
            });
			var infowindow = new google.maps.InfoWindow({
				content: "<?php echo wp_kses($map_desc, array(
							'a' => array(
								'href' => array(),
								'title' => array()
							),
							'i' => array(
								'class' => array()
							),
							'img' => array(
								'src' => array(),
								'alt' => array()
							),
							'br' => array(),
							'em' => array(),
							'strong' => array(),
							'p' => array(),
						)); ?>"
			});
			infowindow.open(map,marker);

            marker.setMap(map);
            }
			var mapContainer = jQuery('#map');
			if(mapContainer.length){
				google.maps.event.addDomListener(window, 'load', initialize);
			}
	</script>
	<?php echo ob_get_clean();
}
// 404 error page title
function consult_not_found_title() {
	global $consult_opt;
	if ($consult_opt['notfound_title']){
		echo $consult_opt['notfound_title'];
	}
	else {
		echo '404';
	}
}

// 404 error page error massage
function consult_not_found_content() {
	global $consult_opt;
	if ($consult_opt['notfound_content']){
		echo $consult_opt['notfound_content'];
	}
	else {
		echo esc_html('The page you are looking for, is not available','consult');
	}
}

// 404 error page error massage
function consult_not_found_img() {
	global $consult_opt;
	if (empty ($consult_opt['not_foundimg'])){ ?>
		<img src="<?php echo esc_url($consult_opt['not_foundimg']['url']); ?>"/>
	<?php }
	else {
		echo '<p class="notfound_img"><span>404</span> Not Found</p>';
	}
}

