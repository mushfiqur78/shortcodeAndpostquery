<?php 
/**
 * Adds About info Widget.
 */

class consult_freecontact_Widget extends WP_Widget{
	/**
	 * Register widget with WordPress.
	 */
	function __construct(){

		$widget_ops = array( 'info' => esc_html__('Free Consutation Info.', 'consult'),'customize_selective_refresh' => true, );
 		parent:: __construct('consult_freecontact_Widget', esc_html__('Consult: Free Consutation', 'consult'),$widget_ops );
	}
	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $value Saved values from database.
	 */
	public function widget($args, $value){
		$wid_titlename = !empty($value['widgetTitelName']) ? $value['widgetTitelName'] : '';
		$wid_getfree = !empty($value['get_freeT']) ? $value['get_freeT'] : '';
		$wid_freeNo = !empty($value['FphoneNO']) ? $value['FphoneNO'] : '';
        $wid_freetext = !empty($value['free_text']) ? $value['free_text'] : '';
		?>
		<?php echo $args['before_widget']; ?>
			<div class="sidebar-widget">
                <div class="regi">
                    <h4 class="s_heading"><?php echo esc_attr ($wid_titlename); ?></h4>
                    <h6><?php echo esc_attr ($wid_getfree); ?></h6>
                    <h3>
                        <i class="icofont icofont-phone"></i> 
                       <?php echo esc_attr ($wid_freeNo); ?>
                    </h3>
                    <p><?php echo esc_attr ($wid_freetext); ?></p>
                </div>
            </div>
		<?php echo $args['after_widget']; ?>

		<?php
	}
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_value Values just sent to be saved.
	 * @param array $old_value Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update($new_value, $old_value){
		$instace = array();
		
        $value['widgetTitelName'] = ( !empty($new_value['widgetTitelName']) ) ? strip_tags ( $new_value['widgetTitelName'] ) : '';
        $value['get_freeT'] = ( !empty($new_value['get_freeT']) ) ? strip_tags ( $new_value['get_freeT'] ) : '';
        $value['FphoneNO'] = ( !empty($new_value['FphoneNO']) ) ? strip_tags ( $new_value['FphoneNO'] ) : '';
        $value['free_text'] = ( !empty($new_value['free_text']) ) ? strip_tags ( $new_value['free_text'] ) : '';
       
		return $value;

	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $value Previously saved values from database.
	 */
	public function form($value){
		$wid_titlename = !empty($value['widgetTitelName']) ? $value['widgetTitelName'] : '';
		$wid_getfree = !empty($value['get_freeT']) ? $value['get_freeT'] : '';
		$wid_freeNo = !empty($value['FphoneNO']) ? $value['FphoneNO'] : '';
        $wid_freetext = !empty($value['free_text']) ? $value['free_text'] : '';
	?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('Widget_title')); ?>">
			    <?php esc_html_e('Title:' ,'consult') ?>
			 </label>
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'Widget_title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'widgetTitelName' )); ?>" value="<?php echo esc_attr( $wid_titlename ); ?>" class="widefat" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('info_des')); ?>">
			    <?php esc_html_e('Get Free:' ,'consult') ?>
			</label>
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'info_des' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'get_freeT' )); ?>" value="<?php echo esc_attr( $wid_getfree ); ?>" class="widefat" />
        </p>
        <p>
			<label for="<?php echo esc_attr($this->get_field_id('cNO')); ?>">
			    <?php esc_html_e('Phone NO:' ,'consult') ?>
            </label>
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'cNO' )); ?>" 
			name="<?php echo esc_attr($this->get_field_name( 'FphoneNO' )); ?>" 
			value="<?php echo esc_attr( $wid_freeNo ); ?>" class="widefat" />
		</p>
        <p>
			<label for="<?php echo esc_attr($this->get_field_id('ftext')); ?>">
			    <?php esc_html_e('Free Text:' ,'consult') ?>
            </label>
			<textarea id="<?php echo esc_attr($this->get_field_id('ftext')); ?>" name="<?php echo esc_attr($this->get_field_name('free_text')); ?>" rows="10" class="widefat">
			    <?php echo esc_attr( $wid_freetext ); ?>
			</textarea>
		</p>
	<?php
	}
}

// register Short description widget
function consult_freecontact_Widget() {
    register_widget( 'consult_freecontact_Widget' );
}
add_action( 'widgets_init', 'consult_freecontact_Widget' );