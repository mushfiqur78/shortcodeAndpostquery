<?php
/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */

function consult_widgets_init() {
	register_sidebar( array(
		'name' => esc_html__( 'Blog Sidebar', 'consult' ),
		'id' => 'sidebar-1',
		'description' => esc_html__( 'Sidebar on blog page', 'consult' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<div class="widget_title"><h4>',
		'after_title' => '</h4></div>',
	) );
    
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Sidebar', 'consult' ),
		'id'            => 'footer-sidebar',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="footer_widgets %2$s col-xs-12 col-md-3">',
		'after_widget' => '</aside>',
		'before_title' => '<div class="footer_widget"><h4>',
		'after_title' => '</h4></div>',
	) );
	
}
add_action( 'widgets_init', 'consult_widgets_init' );
/**
 * Widget
 */
require_once get_template_directory() . '/inc/widgets/consult_recent_post_widget.php';
require_once get_template_directory() . '/inc/widgets/consult_about_widget.php';
require_once get_template_directory() . '/inc/widgets/free_consultation.php';
require_once get_template_directory() . '/inc/widgets/address_widget.php';