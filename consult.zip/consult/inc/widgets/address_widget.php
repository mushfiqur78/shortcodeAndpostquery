<?php 
/**
 * Adds About address Widget.
 */

class consult_address_Widget extends WP_Widget{
	/**
	 * Register widget with WordPress.
	 */
	function __construct(){

		$widget_ops = array( 'address' => esc_html__('About address.', 'consult'),'customize_selective_refresh' => true, );
 		parent:: __construct('consult_address_Widget', esc_html__('Consult: Address', 'consult'),$widget_ops );
	}
	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $subvalue Saved values from database.
	 */
	public function widget($args, $subvalue){
		$wid_addressTitle = !empty($subvalue['contact_hedding']) ? $subvalue['contact_hedding'] : '';
		$wid_address = !empty($subvalue['cont_address']) ? $subvalue['cont_address'] : '';
		$wid_phone = !empty($subvalue['cont_phone']) ? $subvalue['cont_phone'] : '';
		$wid_email = !empty($subvalue['cont_email']) ? $subvalue['cont_email'] : '';
		$wid_time = !empty($subvalue['cont_time']) ? $subvalue['cont_time'] : '';
		?>
		<?php echo $args['before_widget']; ?>
            <div class="footer_widget">
                <h4><?php echo esc_attr ($wid_addressTitle); ?></h4>
                <ul class="ft_conta">
                    <li>
                        <i class="icofont icofont-social-google-map"></i>
                        <span><?php echo esc_attr ($wid_address); ?></span>
                    </li>
                    <li>
                        <i class="icofont icofont-phone"></i>
                        <a href="#">
                            <?php echo esc_attr ($wid_phone); ?>
                        </a>
                    </li>
                    <li>
                        <i class="icofont icofont-ui-message"></i>
                        <a href="#">
                            <?php echo esc_attr ($wid_email); ?>
                        </a>
                    </li>
                    <li>
                        <i class="icofont icofont-clock-time"></i>
                        <?php echo esc_attr ($wid_time); ?>
                    </li>
                </ul>
            </div>
		<?php echo $args['after_widget']; ?>

		<?php
	}
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_value Values just sent to be saved.
	 * @param array $old_value Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update($new_value, $old_value){
        $subvalue['contact_hedding'] = ( !empty($new_value['contact_hedding']) ) ? strip_tags ( $new_value['contact_hedding'] ) : '';
        $subvalue['cont_address'] = ( !empty($new_value['cont_address']) ) ? strip_tags ( $new_value['cont_address'] ) : '';
        $subvalue['cont_phone'] = ( !empty($new_value['cont_phone']) ) ? strip_tags ( $new_value['cont_phone'] ) : '';
        $subvalue['cont_email'] = ( !empty($new_value['cont_email']) ) ? strip_tags ( $new_value['cont_email'] ) : '';
        $subvalue['cont_time'] = ( !empty($new_value['cont_time']) ) ? strip_tags ( $new_value['cont_time'] ) : '';

		return $subvalue;

	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $subvalue Previously saved values from database.
	 */
	public function form($subvalue){
		$wid_addressTitle = !empty($subvalue['contact_hedding']) ? $subvalue['contact_hedding'] : '';
		$wid_address = !empty($subvalue['cont_address']) ? $subvalue['cont_address'] : '';
		$wid_phone = !empty($subvalue['cont_phone']) ? $subvalue['cont_phone'] : '';
		$wid_email = !empty($subvalue['cont_email']) ? $subvalue['cont_email'] : '';
		$wid_time = !empty($subvalue['cont_time']) ? $subvalue['cont_time'] : '';
	?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('address-title')); ?>">
			    <?php esc_html_e('Wedget Title:' ,'consult') ?>
            </label>
			
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'address-title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'contact_hedding' )); ?>" value="<?php echo esc_attr( $wid_addressTitle ); ?>" class="widefat" />
        </p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('address_field')); ?>">
			    <?php esc_html_e('Address:' ,'consult') ?>
            </label>
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'address_field' )); ?>"
			name="<?php echo esc_attr($this->get_field_name( 'cont_address' )); ?>" 
			value="<?php echo esc_attr( $wid_address ); ?>" class="widefat" />
        </p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('phoneno')); ?>">
			    <?php esc_html_e('Phone No:' ,'consult') ?>
            </label>
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'phoneno' )); ?>"
			name="<?php echo esc_attr($this->get_field_name( 'cont_phone' )); ?>" 
			value="<?php echo esc_attr( $wid_phone ); ?>" class="widefat" />
        </p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('emailinfo')); ?>">
			    <?php esc_html_e('Email:' ,'consult') ?>
            </label>
			<input type="email" id="<?php echo esc_attr($this->get_field_id( 'emailinfo' )); ?>"
			name="<?php echo esc_attr($this->get_field_name( 'cont_email' )); ?>" 
			value="<?php echo esc_attr( $wid_email ); ?>" class="widefat" />
        </p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('call_time')); ?>">
			    <?php esc_html_e('Contact Time:' ,'consult') ?>
            </label>
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'call_time' )); ?>"
			name="<?php echo esc_attr($this->get_field_name( 'cont_time' )); ?>" 
			value="<?php echo esc_attr( $wid_time ); ?>" class="widefat" />
        </p>

	<?php
	}
}

// register Short description widget
function consult_address_Widget() {
    register_widget( 'consult_address_Widget' );
}
add_action( 'widgets_init', 'consult_address_Widget' );