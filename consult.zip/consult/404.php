<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package consult
 */
get_header(); 
global $consult_opt;
consult_error_page_breadcrumb(); ?>
	<section class="error_page section-padding">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <?php consult_not_found_img(); ?>
                </div>
                <div class="col-sm-6">
                    <div class="error_tex">
                        <h1><?php consult_not_found_title() ?></h1>
                        <p><?php consult_not_found_content(); ?></p>
                        <a href="<?php echo esc_url( home_url('/') ); ?>" class="consult_btn btn_colored"><i class="icofont icofont-long-arrow-left"></i><?php esc_html_e('Back to Home', 'consult'); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php
get_footer();