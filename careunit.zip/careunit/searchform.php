<form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="searchbox" role="search">
   <div class="form_group">
    <input type="search" class="form-control" name="s" placeholder="<?php echo esc_attr_x( 'Search Now', 'placeholder', 'careunit' ); ?>" value="<?php echo get_search_query(); ?>">
	<input type="submit" class="careunit-search-submit" value="<?php echo esc_attr_x( 'Go', 'submit button', 'careunit' ) ?>" />
	</div>
</form>
