<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package careunit
 */

?>

	</div><!-- #content -->

	<!-- FOOTER AREA START-->
       <?php
                if ( is_active_sidebar( 'footer-sidebar' ) ) : ?> 
        <footer class="footer_area">
                <div class="footer_top">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="scroll_area">
                                    <div class="scroll_top">
                                        <i class="fa fa-long-arrow-up" aria-hidden="true"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <?php dynamic_sidebar( 'footer-sidebar' ); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="footer_bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6">
                            <?php careunit_copyright(); ?>
                        </div>
                        <div class="col-sm-6">
                            <?php careunit_socialicons(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- FOOTER AREA END --> 
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
