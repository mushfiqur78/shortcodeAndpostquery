<?php
/**
 * The template for displaying all single posts.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package careunit
 */
get_header();
careunit_breadcrumb();
$single_blog_layout = careunit_sidebar_layoutpossition('single_blog_layout', 'sidebar_single_blog_pos');
?>
    <!-- LATEST NEWS START --> 
    <section class="latestNews section-padding">
        <div class="container">
            <div class="row all_news area_content">
                <div class="col-xs-12 <?php echo 'col-md-'.$single_blog_layout['blogcolwidth'];
                    if($single_blog_layout['blogsidebar']=='left'){ echo ' pull-right'; } ?>">
                        <div id="primary" class="content-area">
                            <main id="main" class="site-main">
                                <?php
                                    while ( have_posts() ) : the_post();
                                        get_template_part( 'template-parts/content-single', get_post_format() );
                                        // If comments are open or we have at least one comment, load up the comment template.
                                        if ( comments_open() || get_comments_number() ) :
                                            comments_template();
                                        endif;
                                    endwhile; // End of the loop.
                                ?>
                            </main><!-- #main -->
                        </div><!-- #primary -->
                    </div>
                    <!-- Sidebar -->
                    <?php if( $single_blog_layout['blogsidebar']=='left' ||         
                            $single_blog_layout['blogsidebar']=='right' ) : ?>
                        <?php get_sidebar('singleblog'); ?>
                    <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- LATEST NEWS END -->
<?php get_footer();
