<?php
/**
 * careunit functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package careunit
 */

if ( ! function_exists( 'careunit_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function careunit_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on careunit, use a find and replace
	 * to change 'careunit' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'careunit', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );
    add_image_size( 'careunit_post_img', 185, 236, true );
    add_image_size( 'careunit_post_style2_img', 555, 227, true );
    add_image_size( 'careunit_with_sidebarthumb', 850, 280, true );
    add_image_size( 'careunit_no_sidebarthumb', 1140, 380, true );
    add_image_size('careunit_doc_img', 295, 384, true);
    add_image_size( 'careunit_clinical_img', 255, 255, true );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'mainmenu' => esc_html__( 'Main Menu', 'careunit' ),
		'headertop' => esc_html__( 'Header Top', 'careunit' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'careunit_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );
}
endif;
add_action( 'after_setup_theme', 'careunit_setup' );


function careunit_theme_add_editor_styles() {
    add_editor_style( '/css/careunit-editor-style.css' );
}
add_action( 'admin_init', 'careunit_theme_add_editor_styles' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function careunit_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'careunit_content_width', 640 );
}
add_action( 'after_setup_theme', 'careunit_content_width', 0 );

/**
 * Careunit Partner Slider
 */
function careunit_partner_script(){
	global $careunit_opt;
	ob_start(); ?>
		var careunit_partnernumber = <?php if(!empty($careunit_opt['partnernumber'])) {
            echo esc_js($careunit_opt['partnernumber']); 
        } else { echo '6'; } ?>,
		careunit_partnerscroll = <?php echo esc_js(!empty($careunit_opt['partnerscroll'])) ? 'true': 'false'; ?>;
	<?php
	return ob_get_clean();
}
/**
 * Set up the WordPress core custom header feature.
 *
 * @uses careunit_header_style()
 */
function careunit_custom_header_setup() {
	add_theme_support( 'custom-header', apply_filters( 'business_custom_header_args', array(
		'default-image'          => '',
		'default-text-color'     => '000000',
		'width'                  => 1000,
		'height'                 => 250,
		'flex-height'            => true,
		'wp-head-callback'       => 'careunit_header_style',
	) ) );
}
add_action( 'after_setup_theme', 'careunit_custom_header_setup' );

if ( ! function_exists( 'careunit_header_style' ) ) :
/**
 * Styles the header image and text displayed on the blog.
 *
 * @see careunit_custom_header_setup().
 */
function careunit_header_style() {
	$header_text_color = get_header_textcolor();

	/*
	 * If no custom options for text are set, let's bail.
	 * get_header_textcolor() options: Any hex value, 'blank' to hide text. Default: add_theme_support( 'custom-header' ).
	 */
	if ( get_theme_support( 'custom-header', 'default-text-color' ) === $header_text_color ) {
		return;
	}
	
}
endif;
// If we get this far, we have custom styles. Let's do this.
function careunit_header_style_script(){
	
	ob_start();
	//add custom css
	global $careunit_opt;
	if ( isset($careunit_opt['custom_css']) && $careunit_opt['custom_css']!='') { ?>
		<?php echo esc_html($careunit_opt['custom_css']); ?>
	<?php }
		// Has the text been hidden?
		if ( ! display_header_text() ) :
	?>
	.site-title,
	.site-description {
		position: absolute;
		clip: rect(1px, 1px, 1px, 1px);
	}
	<?php
		// If the user has set a custom color for the text use that.
		else :
	?>
	.site-title a,
	.site-description {
		color: #<?php
		$header_text_color = get_header_textcolor();
		echo esc_attr( $header_text_color ); ?>;
	}
	<?php endif; ?>
	<?php return ob_get_clean();
}
/**
 * Enqueue google fonts.
 */
function careunit_fonts_url(){
	$fonts_url = '';
	 
	/* Translators: If there are characters in your language that are not
	* supported by raleways, translate this to 'off'. Do not translate
	* into your own language.
	*/
	$raleways = _x( 'on', 'raleways font: on or off', 'careunit' );
	 
	/* Translators: If there are characters in your language that are not
	* supported by Montserrat, translate this to 'off'. Do not translate
	* into your own language.
	*/
	$montserrat = _x( 'on', 'Montserrat font: on or off', 'careunit' );
	 
	if ( 'off' !== $raleways || 'off' !== $montserrat ) {
	$font_families = array();
	 
	if ( 'off' !== $raleways ) {
	$font_families[] = 'Raleway:400,700,100,500,600,300';
	}
	 
	if ( 'off' !== $montserrat ) {
	$font_families[] = 'Montserrat:400,700';
	}
	 
	$query_args = array(
	'family' => urlencode( implode( '|', $font_families ) ),
	'subset' => urlencode( 'latin,latin-ext' ),	
	);
	 
	$fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
	}
	 
	return esc_url_raw( $fonts_url );
}

/**
 * Enqueue scripts and styles.
 */
function careunit_scripts() {
    wp_enqueue_style( 'careunit-fonts', careunit_fonts_url(), array(), null );
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() .'/css/bootstrap.min.css');
	wp_enqueue_style( 'font-awesome', get_template_directory_uri() .'/css/font-awesome.min.css');
	wp_enqueue_style( 'pe-icon-7', get_template_directory_uri() .'/css/pe-icon-7-stroke.css');
	wp_enqueue_style( 'flaticon', get_template_directory_uri() .'/fonts/flaticon.css');
	wp_enqueue_style( 'animate', get_template_directory_uri() .'/css/animate.css');
	wp_enqueue_style( 'venobox', get_template_directory_uri() .'/css/venobox.css');
	wp_enqueue_style( 'meanmenu', get_template_directory_uri() .'/css/meanmenu.min.css');
	wp_enqueue_style( 'owl-carousel', get_template_directory_uri() .'/css/owl.carousel.css');
    wp_enqueue_style( 'careunit-style', get_stylesheet_uri() );
    
	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', array('jquery'), 'v3.3.6', true );
	wp_enqueue_script( 'counterup', get_template_directory_uri() . '/js/jquery.counterup.min.js', array('jquery'), 'v1.0', true );
	wp_enqueue_script( 'waypoints', get_template_directory_uri() . '/js/waypoints.min.js', array('jquery'), 'v1.6.2', true );
	wp_enqueue_script( 'sticky', get_template_directory_uri() . '/js/jquery.sticky.js', array('jquery'), 'v1.0.0', true );
	wp_enqueue_script( 'easing', get_template_directory_uri() . '/js/jquery.easing.1.3.min.js', array('jquery'), 'v1.3', true );
	wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/js/owl.carousel.min.js', array('jquery'), 'v3.3.6', true );
	wp_enqueue_script( 'lwtCountdown', get_template_directory_uri() . '/js/jquery.lwtCountdown-1.0.js', array('jquery'), 'v1.0', true );
	wp_enqueue_script( 'meanmenu', get_template_directory_uri() . '/js/jquery.meanmenu.min.js', array('jquery'), 'v1.0', true );
	wp_enqueue_script( 'parallax', get_template_directory_uri() . '/js/jquery.parallax-1.1.3.js', array('jquery'), 'v1.1.3', true );
	wp_enqueue_script( 'mixitup', get_template_directory_uri() . '/js/jquery.mixitup.min.js', array('jquery'), 'v2.1.11', true );
	wp_enqueue_script( 'jflickrfeed', get_template_directory_uri() . '/js/jflickrfeed.min.js', array('jquery'), 'v1.0', true );
	wp_enqueue_script( 'venobox', get_template_directory_uri() . '/js/venobox.min.js', array('jquery'), 'v1.5.2', true );
    wp_enqueue_script( 'careunit-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );
    wp_enqueue_script( 'lettering', get_template_directory_uri() . '/js/jquery.lettering.js', array('jquery'), '2.0.3', true );
	wp_enqueue_script( 'careunit-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );
	wp_enqueue_script( 'wow', get_template_directory_uri() . '/js/wow.min.js', array('jquery'), 'v1.0.2', true );
    wp_enqueue_script( 'careunit-main-js', get_template_directory_uri() . '/js/main.js', array('jquery'), 'v1.0', true );
    
    // Inline Style
	wp_add_inline_style( 'careunit-style', careunit_header_style_script(),'wp_head' );
    wp_add_inline_script('careunit-main-js', careunit_partner_script(), 'before');
    
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'careunit_scripts' );
/**
*Custom Admin Style 
*/
function careunit_admin_acripts(){
	wp_enqueue_style('thickbox');

	wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');

    wp_enqueue_script('upload_media_widget', get_template_directory_uri() . '/js/upload-media.js', array('jquery'));
}
add_action('admin_enqueue_scripts','careunit_admin_acripts');

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Load TGM plugin file.
 */
require get_template_directory() . '/inc/tgm-plugin/class-tgm-plugin-activation.php';
require get_template_directory() . '/inc/tgm-plugin/required-plugins.php';
/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';
/**
 * Load Redux Framework file.
 */
if ( file_exists( get_template_directory().'/inc/careunit-config.php' ) ) {
  require_once( get_template_directory().'/inc/careunit-config.php' );
}
/**
 * Load global and metabox file function file.
 */
require_once get_template_directory() . '/inc/global-function.php';
require_once get_template_directory() . '/inc/careunit-metabox.php';
/**
 * Custom Excerpt Lenth.
 */
function careunit_excerpt_by_id($post, $length = 10, $tags = '<a><em><strong>') {
 
	if(is_int($post)) {
		// get the post object of the passed ID
		$post = get_post($post);
	} elseif(!is_object($post)) {
		return false;
	}
 
	if(has_excerpt($post->ID)) {
		$the_excerpt = $post->post_excerpt;
		return apply_filters('the_content', $the_excerpt);
	} else {
		$the_excerpt = $post->post_content;
	}
 
	$the_excerpt = strip_shortcodes(strip_tags($the_excerpt), $tags);
	$the_excerpt = preg_split('/\b/', $the_excerpt, $length * 2+1);
	$excerpt_waste = array_pop($the_excerpt);
	$the_excerpt = implode($the_excerpt);
 
	return apply_filters('the_content', $the_excerpt);
}
/**
 * Widget
 */
require_once get_template_directory() . '/inc/widgets/register-widget.php';
/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';
function careunit_comment_reply($content) {
    $content = str_replace('Reply', '<i class="color_second fa fa-reply" aria-hidden="true"></i>', $content);
    return $content;
}
add_filter('comment_reply_link', 'careunit_comment_reply');

//Google Map Api Key
global $careunit_opt;
if(isset($careunit_opt['map_apy_key']) && !empty($careunit_opt['map_apy_key'])){
	add_action('wp_enqueue_scripts', 'careunit_googlemap_api_enqueue');
}


// Replaces the excerpt "more" text by a link
function careunit_new_excerpt_more($more) {
	return '';
}
add_filter('excerpt_more', 'careunit_new_excerpt_more');