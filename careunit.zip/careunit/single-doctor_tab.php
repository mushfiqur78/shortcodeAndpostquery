<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Consult_-_careunit_WordPress_Theme
 */
get_header();
careunit_breadcrumb();
?>
<!-- START DOCTOR DETAILS AREA -->
<section class="doctor_info section-padding">
    <div class="container">
        <div class="row">
            <?php
                while ( have_posts() ) : the_post();
                    get_template_part( 'template-parts/doctortab', 'single' );
                endwhile; // End of the loop.
            ?>
        </div>
    </div>
</section> 
<!-- END DOCTOR DETAILS AREA -->
<?php get_footer(); ?>