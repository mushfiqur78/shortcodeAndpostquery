<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Giant_careunit_-_careunit_WordPress_Theme
 */
global $careunit_opt;

$single_blog_layout = careunit_sidebar_layoutpossition('single_blog_layout', 'sidebar_single_blog_pos');
if(function_exists('careunit_setCrunchifyPostViews')){
    careunit_setCrunchifyPostViews(get_the_ID());
}

$item_cats = get_the_terms($post->ID, 'category');
?>
        <div class="single_news">
            <?php if ( has_post_thumbnail() ) { ?>
                <figure>
                    <?php
                        if($single_blog_layout['blogcolwidth']==9){
                            the_post_thumbnail( 'careunit_with_sidebarthumb', array( 'class' => 'img-responsive' ) );
                        }else{
                            the_post_thumbnail( 'careunit_no_sidebarthumb', array( 'class' => 'img-responsive' ) );
                        }
                    ?>
                </figure>
            <?php } ?>        
                <div class="news_txt">
                    <ul class="single_post_admin">
                        <li>
                            <i class="fa fa-user"></i>
                            <?php the_author_posts_link() ; ?>
                        </li>
                        <li>
                            <i class="fa fa-calendar"></i>
                            <?php echo get_the_date(); ?>
                        </li>
                        <?php if(function_exists('careunit_getCrunchifyPostViews')){ ?>
                            <li><i class="fa fa-eye mrs"></i>
                                <?php echo careunit_getCrunchifyPostViews(get_the_ID()); ?>
                            </li>
                        <?php } ?>
                    </ul>
                    <?php the_content();
                        wp_link_pages( array(
                            'before'      => '<div class="pagination"><span class="page-links-title">' . esc_html__( 'Pages:', 'careunit' ) . '</span>',
                            'after'       => '</div>',
                            'link_before' => '<span>',
                            'link_after'  => '</span>',
                        ) );
                    ?>
                </div>
        </div>
        <div class="pm-single-post-social-features">
            <div class="cat_tag">
                <div class="catagory_list">
                    <?php
                        if($item_cats){
                            echo '<p class="ct_list">'.esc_html('Catagory in:').'</p>';
                            echo '<ul>';
                            foreach($item_cats as $item_cat) {
                                // The $term is an object, so we don't need to specify the $taxonomy.
                                $term_link = get_term_link( $item_cat );

                                // If there was an error, continue to the next term.
                                if ( is_wp_error( $term_link ) ) {
                                    continue;
                                }
                                // We successfully got a link. Print it out.
                                echo '<li><a href="' . esc_url( $term_link ) . '">' . $item_cat->name . '</a></li>';
                            }
                            echo '</ul>';
                        }
                    ?>
                </div>
                <div class="pm-single-post-tags">
                   <?php if(has_tag()) { ?>
                        <p class="sp_tags"><?php echo esc_html('Tagged in:'); ?></p>
                        <?php the_tags( '', ' ', '' ); ?>
                    <?php } ?>
                </div>
            </div>
            <?php if(function_exists('careunit_blog_sharing')){ ?>
            <div class="socialicon_area">
               <?php careunit_blog_sharing(); ?>
            </div>
            <?php } ?>
        </div>
        <?php $authordesc = get_the_author_meta( 'description' );
        if ( ! empty ( $authordesc  ) ) { ?>       
        <div class="about_auther">
            <?php
            $haveAvatar = get_avatar( get_the_author_meta( 'user_email' ), 163 );
            if ( ! empty ( $haveAvatar ) ) { ?>
            <div class="auther">
                <?php
                    echo esc_html($haveAvatar);
                ?>
            </div>
            <?php } ?>
            
            <?php $authordesc = get_the_author_meta( 'description' );
                if ( ! empty ( $authordesc ) ) { ?>
                <div class="auther_details">
                    <h5><?php the_author_posts_link(); ?></h5>
                    <p><?php echo esc_html($authordesc); ?></p>
                </div>
            <?php } ?> 
        </div>
         <?php } ?>
        