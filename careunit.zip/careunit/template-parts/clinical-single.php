<?php 
$departname = get_post_meta( get_the_ID(), '_careunit_depart_name', 1 );
$departicon = get_post_meta( get_the_ID(), '_careunit_depart_icon', 1 ); ?>
<div class="col-sm-5">
    <figure>
        <?php the_post_thumbnail(); ?>
    </figure>
</div>
<div class="col-sm-7">
    <figcaption>
        <i class="flaticon-<?php echo $departicon; ?> "></i>
        <h4><?php the_title(); ?></h4>
        <?php if(!empty($departname)){ ?>
            <h5><?php echo esc_html($departname); ?></h5>
        <?php } ?>
        <?php the_content(); ?>
    </figcaption> 
</div>
