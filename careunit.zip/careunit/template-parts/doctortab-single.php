<?php 
$doctorqualification = get_post_meta(get_the_ID(), '_careunit_doctor_quali_details', true); 
$availability = get_post_meta(get_the_ID(), '_careunit_availability_dateTime', true);
$icon_linkname = get_post_meta( get_the_ID(), '_careunit_doctor_social_icon', true );
$doctorcontact = get_post_meta( get_the_ID(), '_careunit_doctor_contatact', true );
?>
        <div class="col-xs-12 col-sm-8 col-md-8 pull-right pl_60">
                <div class="dtinfo">
                    <h3><?php the_title(); ?></h3>
                    <h5 class="dt_quali">
                    <?php echo get_post_meta(get_the_id(),'_careunit_doctor_designation', true); ?>
                    </h5>
                    <?php the_content(); ?>
                    <ul class="dt_list">
                        <?php if(is_array($doctorqualification)){
                            foreach($doctorqualification as $dtqfication){ ?>
                            <li>
                                <span class="dt_infoHeading">
                                    <?php echo esc_html($dtqfication['_careunit_quali_title']); ?>
                                </span>
                                <div class="dt_child">
                                    <ul class="dt_skill">
                                        <?php if(is_array($dtqfication['_careunit_doctor_quali'])){
                                            foreach($dtqfication['_careunit_doctor_quali'] as $single_dtskille){ ?>
                                              <li><?php echo esc_html($single_dtskille); ?></li> 
                                            <?php }
                                        } ?>
                                    </ul>
                                </div>
                            </li>    
                        <?php }
                        }  ?>
                       
                    </ul>
                </div>
                <div class="get_in_tuch">
                    <h3>
                        <?php echo esc_html('Get In Touch', 'careunit'); ?>
                        <i class="fa fa-envelope-o"></i>
                    </h3>
                    <?php echo do_shortcode($doctorcontact); ?>
                </div>
            </div>
            <div class="col-xs-12 col-sm-4 col-md-4 sidebar pull-left">
                <div class="doc_leftsidebar">
                    <figure class="doctor_photo">
                        <?php the_post_thumbnail(); ?>
                    </figure>
                    <ul class="doctor_social">
                       <?php if( is_array($icon_linkname)){
                            foreach($icon_linkname as $iconlink){ ?>
                            <li>
                                <a href="<?php echo esc_url($iconlink['_careunit_socialicon_link']); ?>">
                                    <i class="fa fa-<?php echo esc_attr($iconlink['_careunit_socialicon_name']); ?>">
                                </i>
                                    <i class="fa fa-<?php echo esc_attr($iconlink['_careunit_socialicon_name']); ?> hovereffect">
                                    </i>
                                </a>
                            </li>
                            <?php  } 
                            }?> 
                    </ul>
                </div>
                <?php if(is_array($availability)){
                    foreach($availability as $single_availability){ ?>
                        <div class="doctor_opening">
                            <h4><i class="fa fa-<?php echo esc_url($single_availability['_careunit_availability_icon']); ?>"></i>
                            <?php echo esc_html($single_availability['_careunit_availability_title']); ?>
                            </h4>
                            <ul>
                                <li>
                                    <?php if(is_array($single_availability['_careunit_doctor_availability'])){
                                        foreach($single_availability['_careunit_doctor_availability'] as $si_availabilyty){ ?>
                                        <span>
                                            <?php echo esc_html($si_availabilyty); ?>
                                        </span>
                                        <?php }
                                    } ?>
                               </li>
                            </ul>
                                <?php
                                    global $careunit_opt;
                                    if(!empty($careunit_opt['appointment_btn_text'])) { ?>
                                    <a class="care_bt" href="<?php careunit_appoinment_btnLink(); ?>">
                                        <?php careunit_appoinment_btnTxt(); ?>
                                    </a>   
                                <?php }?>
                                
                        </div>
                    <?php }
                } ?>
            </div>