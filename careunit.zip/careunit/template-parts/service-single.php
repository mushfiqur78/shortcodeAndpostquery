<?php 
$serviceicon = get_post_meta( get_the_ID(), '_careunit_service_icon', 1 ); ?>
<div class="col-sm-8 col-sm-offset-2">
    <div class="service_box">
        <div class="service_icon">
            <i class="fa fa-<?php echo esc_html($serviceicon); ?>"></i>
        </div>
        <h3><?php the_title(); ?></h3>
        <?php the_content(); ?>
    </div> 
</div>
