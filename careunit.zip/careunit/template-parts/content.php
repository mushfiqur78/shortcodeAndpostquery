<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package careunit
 */

$blog_layout = careunit_sidebar_layoutpossition('blog_layout', 'sidebarblog_pos');
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <!-- .entry-header -->
	<div class="single_news">
        <?php if(has_post_thumbnail()){ ?>
            <figure>
                <?php 
                    if($blog_layout['blogcolwidth']==9){
                        the_post_thumbnail( 'careunit_with_sidebarthumb', array( 'class' => 'img-responsive' ) );
                    }else{
                        the_post_thumbnail( 'careunit_no_sidebarthumb', array( 'class' => 'img-responsive' ) );
                    }
                ?>
                <?php } ?>
            </figure>
            <div class="news_txt">
                <?php
                if ( is_sticky() ) {
                    echo '<div class="sticky_post"><span>'.esc_html__('Featured', 'careunit').'</span></div>';
                }
                the_title( '<h4><a href="' . esc_url( get_permalink() ) . '">', '</a></h4>' ); ?>
                <ul class="single_post_admin">
                    <li>
                        <i class="fa fa-user"></i>
                        <?php the_author_posts_link(); ?>
                    </li>
                    <li>
                        <i class="fa fa-calendar"></i>
                        <?php echo get_the_date(); ?>
                    </li>
                </ul>
                <div>
                <?php the_excerpt();
                    wp_link_pages( array(
                        'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'careunit' ),
                        'after'  => '</div>',
                    ) );
                ?>
                </div>
                <a class="care_bt" href="<?php echo esc_url( get_permalink()); ?>">
                    <?php careunit_blog_read_more(); ?>
                </a>
            </div>
        </div>
</article><!-- #post-## -->
