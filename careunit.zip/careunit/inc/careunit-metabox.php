<?php

add_action( 'cmb2_admin_init', 'careunit_metabox' );

function careunit_metabox() {

	$prefix = '_careunit_';
	
    // metabox support for careunit Project
	$cmb2_clinical_service = new_cmb2_box( array(
		'id'           => $prefix . 'clinical_depart_options',
		'title'        => esc_html__( 'Clinical Service', 'careunit' ),
		'object_types' => array( 'clinical_service'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );
	$cmb2_clinical_service->add_field( array(
	    'name'    =>  esc_html__( 'Department Name', 'careunit' ),
	    'id'      =>  $prefix . 'depart_name',
	    'type'    =>  'text',
	    'default' =>  esc_html__( 'Diagnosis, Therapy', 'careunit' ),
	) );

	$cmb2_clinical_service->add_field( array(
	    'name'    =>  esc_html__( 'Department Icon', 'careunit' ),
	    'id'      =>  $prefix . 'depart_icon',
	    'type'    =>  'text',
	    'default' =>  esc_html__( 'pharmacy2', 'careunit' ),
	) );
	
    // Careunit Service Metabox
	$cmb2_service_metabox = new_cmb2_box( array(
		'id'           => $prefix . 'service_metbox',
		'title'        => esc_html__( 'Service Metabox Icon', 'careunit' ),
		'object_types' => array( 'careunit_service'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );

	$cmb2_service_metabox->add_field( array(
	    'name'    =>  esc_html__( 'Our Service Icon', 'careunit' ),
	    'id'      =>  $prefix . 'service_icon',
	    'type'    =>  'text',
	) );
	// Doctor Details
    $cmb2_doctor_metabox = new_cmb2_box( array(
		'id'           => $prefix . 'doctab',
		'title'        => esc_html__( 'Doctors Details', 'careunit' ),
		'object_types' => array( 'doctor_tab'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );
    $cmb2_doctor_metabox->add_field(array(
	    'name'    => esc_html__( 'Doctor Designation', 'careunit' ),
	    'id'      =>  $prefix.'doctor_designation',
	    'type'    => 'text',
	));	
    $cmb2_doctor_metabox->add_field(array(
	    'name'    => esc_html__( 'Doctor Contact Form', 'careunit' ),
	    'id'      =>  $prefix.'doctor_contatact',
	    'type'    => 'text',
	));	
    $doctor_social_group = $cmb2_doctor_metabox->add_field( array(
	    'name'    =>  esc_html__( 'Doctor Social Icon', 'careunit' ),
	    'id'      =>  $prefix . 'doctor_social_icon',
        'type'       => 'group'
	) );
    $cmb2_doctor_metabox->add_group_field($doctor_social_group, array(
	    'name'    => esc_html__( 'Doctor Social Icon Link', 'careunit' ),
	    'id'      =>  $prefix.'socialicon_link',
	    'type'    => 'text_url',
        'desc' => esc_html__( 'Use http, https before link', 'careunit' )
	));	
    $cmb2_doctor_metabox->add_group_field($doctor_social_group, array(
	    'name'    => esc_html__( 'Doctor Social Icon Name', 'careunit' ),
	    'id'      =>  $prefix.'socialicon_name',
	    'type'    => 'text'
	));
    //Doctor qualification
    $doctor_qualification_group = $cmb2_doctor_metabox->add_field( array(
	    'name'    =>  esc_html__( 'Add Doctor Qualification', 'careunit' ),
	    'id'      =>  $prefix . 'doctor_quali_details',
        'type'       => 'group'
	) );
    $cmb2_doctor_metabox->add_group_field($doctor_qualification_group, array(
	    'name'    => esc_html__( 'Qualification Title', 'careunit' ),
	    'id'      =>  $prefix.'quali_title',
	    'type'    => 'text',
	));	
    $cmb2_doctor_metabox->add_group_field($doctor_qualification_group, array(
	    'name'    => esc_html__( 'Doctor Qualification Details', 'careunit' ),
	    'id'      =>  $prefix.'doctor_quali',
	    'type'    => 'text',
        'repeatable' => true
	));	
    //Doctor Availability
    $doctor_qualification_group = $cmb2_doctor_metabox->add_field( array(
	    'name'    =>  esc_html__( 'Add Doctor Availability', 'careunit' ),
	    'id'      =>  $prefix . 'availability_dateTime',
        'type'       => 'group'
	) );
    $cmb2_doctor_metabox->add_group_field($doctor_qualification_group, array(
	    'name'    => esc_html__( 'Availability Title', 'careunit' ),
	    'id'      =>  $prefix.'availability_title',
	    'type'    => 'text',
	));
    $cmb2_doctor_metabox->add_group_field($doctor_qualification_group, array(
	    'name'    => esc_html__( 'Availability Icon', 'careunit' ),
	    'id'      =>  $prefix.'availability_icon',
	    'type'    => 'text',
	));	
    $cmb2_doctor_metabox->add_group_field($doctor_qualification_group, array(
	    'name'    => esc_html__( 'Doctor Availability Details', 'careunit' ),
	    'id'      =>  $prefix.'doctor_availability',
	    'type'    => 'text',
        'repeatable' => true
	));
    // Testimonial Metabox
    $cmb2_textimonials = new_cmb2_box( array(
		'id'           => $prefix . 'patients_saying_metbox',
		'title'        => esc_html__( 'Patients Designation', 'careunit' ),
		'object_types' => array( 'patients_saying'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );
    $cmb2_textimonials->add_field( array(
	    'name'    => esc_html__( 'Client Designation', 'careunit' ),
	    'id'      =>  $prefix.'desig',
	    'type'    => 'text',
		'desc' => esc_html__( 'CEO, AVION', 'careunit' )
	));
	// metabox for page slider or banner
	$cmb2_headerfooter = new_cmb2_box( array(
		'id'           => $prefix . 'page_header_optons',
		'title'        => esc_html__( 'Page Settings', 'careunit' ),
		'object_types' => array( 'page'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );

	$cmb2_headerfooter->add_field( array(
	    'name'             =>  esc_html__( 'Select Header', 'careunit' ),
	    'id'               => $prefix . 'page_header',
	    'desc'             => esc_html__( 'Select any one.which you want to display','careunit' ),
	    'type'             => 'select',
	    'default'          => '1',
	    'options'          => array(
	        '1' => esc_html__( 'Header v1', 'careunit' ),
	        '2'   => esc_html__( 'Header v2', 'careunit' ),
	        '3'   => esc_html__( 'Header v3', 'careunit' ),
	    ),
	) );   
    // metabox for page slider or banner
	$cmb2_pagesidebar = new_cmb2_box( array(
		'id'           => $prefix . 'page_sidebar_optons',
		'title'        => esc_html__( 'Page Settings', 'careunit' ),
		'object_types' => array( 'page'), // Post type
        'show_on_cb' => 'careunit_metabox_exclude_blog_page',
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );
    
}

