<?php
// Header layout
function careunit_header_layout(){
    global $careunit_opt;
    if ( !isset($careunit_opt['header_layout']) ) {
        get_header('v1');
    } else {
        get_header($careunit_opt['header_layout']);
    }
}
// Topbar Social link
function careunit_socialicons(){
	global $careunit_opt;
	if(isset($careunit_opt['topbar_social_icons'])) {
        echo '<ul class="social_icon">';
        foreach($careunit_opt['topbar_social_icons'] as $key=>$value ) {
            if(!empty($value) && $value!=$key){
                echo '<li><a class="'.esc_attr($key).' social-icon" href="'.esc_url($value).'" title="'.ucwords(esc_attr($key)).'" target="_blank">
                <i class="fa fa-'.esc_attr($key).' "></i>
                <i class="fa fa-'.esc_attr($key).' '.'hovereffect"></i>
                </a></li>';
            }
        }
        echo '</ul>';
    }
}
// Display logo
function careunit_logo($theme_logo_url = ''){
    $theme_logo = $theme_logo_url;
	if(is_ssl()){
		$theme_logo = str_replace('http:', 'https:', $theme_logo_url);
	}
	
	if( !empty($theme_logo) ){ ?>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
				<img src="<?php echo esc_url($theme_logo); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" />
			</a>
		<?php
		} else { ?>
			<h3 class="navbar-blog-info">
			    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
			        <?php bloginfo( 'name' ); ?>
			    </a>
            </h3>
			<?php
		} ?>
	<?php
}
// Display header top bar
function careunit_header_top_show(){
	global $careunit_opt;
    if( !empty($careunit_opt['show_header_top_bar']) ){
        return $careunit_opt['show_header_top_bar'];
    }else{
        return false;
    }
}
// Phone number
function careunit_top_bar_phone(){
    global $careunit_opt;
    $return = (isset($careunit_opt['top_bar_phone']) && !empty($careunit_opt['top_bar_phone'])) ? $careunit_opt['top_bar_phone'] : false;
	return $return;
}
// Email Address
function careunit_top_bar_email(){
	global $careunit_opt;
    $return = (isset($careunit_opt['top_bar_email']) && !empty($careunit_opt['top_bar_email'])) ? $careunit_opt['top_bar_email'] : false;
	return $return;
}
// Free careunit Button Text
function careunit_appoinment_btnTxt(){
	global $careunit_opt;
	if(isset($careunit_opt['appointment_btn_text'])){ 
        echo esc_html($careunit_opt['appointment_btn_text']); 
    }else { 
        esc_html_e('appointment', 'careunit');
    }
}
// Free careunit Button Link
function careunit_appoinment_btnLink(){
	global $careunit_opt;
	if(isset($careunit_opt['appointment_btn_link'])){ 
        echo esc_html($careunit_opt['appointment_btn_link']); 
    }else { 
        esc_html_e('#', 'careunit');
    }
}
// careunit hearder top
function careunit_hearder_topv1(){
	if( careunit_header_top_show() == true) : ?>
	    <!-- HEADER TOP START -->   
        <div class="header_top">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-md-4 col-sm-4">
                        <div class="headertop_left">
                           <?php careunit_headertop_menu(); ?>
                       </div>
                    </div>
                    <div class="col-xs-12 col-sm-8">
                        <div class="headertop_right">
                            <ul>
                               <?php if( careunit_top_bar_phone() ){ ?>
                                <li><i class="fa fa-phone"></i>
                                    <strong><?php echo esc_html('Call Us Now:','careunit'); ?></strong>
                                    <a href="tel:<?php echo esc_attr(careunit_top_bar_phone()); ?>">
                                        <?php echo esc_html(careunit_top_bar_phone()); ?>
                                    </a>
                                </li>
                                <?php } ?>
                                <?php if( careunit_top_bar_email() ){ ?>
                                <li><i class="fa fa-envelope"></i>
                                  <strong><?php echo esc_html('Mail:'); ?></strong>
                                    <a href="<?php echo esc_attr(careunit_top_bar_email()); ?>">
                                        <?php echo esc_html(careunit_top_bar_email()); ?>
                                    </a>
                                </li>
                                <?php } ?>
                            </ul>
                        </div>   
                   </div>
               </div>
           </div>
        </div>
        <!-- HEADER TOP END -->
        <?php endif; ?>
        <!-- HEADER  MID START --> 
        <div class="header_mid">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="logo_area">
                            <?php global $careunit_opt;
                                $logo_url = !empty($careunit_opt['logo_main']['url']) ? $careunit_opt['logo_main']['url'] : null;
                                careunit_logo( $logo_url ); 
                            ?>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <div class="socialicon_area">
                            <?php careunit_socialicons(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- HEADER MID END -->
	<?php
}
// careunit hearder top
function careunit_hearder_topv2(){ ?>
	    <!-- HEADER TOP START -->      
        <div class="header_top">
            <div class="container">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="logo_area">
                            <?php global $careunit_opt;
                                $logo_url = !empty($careunit_opt['logo_main']['url']) ? $careunit_opt['logo_main']['url'] : null;
                                careunit_logo( $logo_url ); 
                            ?>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="socialicon_area">
                            <?php careunit_socialicons(); ?>
                        </div>
                    </div>
               </div>
           </div>
        </div>
        <!-- HEADER TOP END -->
    <?php if( careunit_header_top_show() == true) : ?>   
        <!-- HEADER  MID START --> 
        <div class="header_mid">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="headertop_left">
                           <?php careunit_headertop_menu(); ?>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="headertop_right">
                            <ul>
                               <?php if( careunit_top_bar_phone() ){ ?>
                                <li><i class="fa fa-phone"></i>
                                    <strong><?php echo esc_html('Call Us Now:','careunit'); ?></strong>
                                    <a href="tel:<?php echo esc_attr(careunit_top_bar_phone()); ?>">
                                        <?php echo esc_html(careunit_top_bar_phone()); ?>
                                    </a>
                                </li>
                                <?php } ?>
                                <?php if( careunit_top_bar_email() ){ ?>
                                <li><i class="fa fa-envelope"></i>
                                  <strong><?php echo esc_html('Mail:'); ?></strong>
                                    <a href="<?php echo esc_attr(careunit_top_bar_email()); ?>">
                                        <?php echo esc_html(careunit_top_bar_email()); ?>
                                    </a>
                                </li>
                                <?php } ?>
                            </ul>
                        </div>   
                   </div>
                </div>
            </div>
        </div>
        <!-- HEADER MID END -->
	<?php endif;
}
// careunit hearder top
function careunit_hearder_topv3(){
	if( careunit_header_top_show() == true) : ?>
	    <!-- HEADER TOP START -->  
        <div class="container">
            <div class="row">
                <div class="header_top clearfix">
                    <div class="col-md-4 col-sm-4">
                        <div class="headertop_left">
                           <?php careunit_headertop_menu(); ?>
                        </div>
                    </div>
                    <div class="col-md-8 col-sm-8">
                        <div class="headertop_right">
                            <ul>
                                <?php if( careunit_top_bar_phone() ){ ?>
                                <li><i class="fa fa-phone"></i>
                                    <strong><?php echo esc_html('Call Us Now:','careunit'); ?></strong>
                                    <a href="tel:<?php echo esc_attr(careunit_top_bar_phone()); ?>">
                                        <?php echo esc_html(careunit_top_bar_phone()); ?>
                                    </a>
                                </li>
                                <?php } ?>
                                <?php if( careunit_top_bar_email() ){ ?>
                                <li><i class="fa fa-envelope"></i>
                                  <strong><?php echo esc_html('Mail:'); ?></strong>
                                    <a href="<?php echo esc_attr(careunit_top_bar_email()); ?>">
                                        <?php echo esc_html(careunit_top_bar_email()); ?>
                                    </a>
                                </li>
                                <?php } ?>
                            </ul>
                        </div>   
                   </div>
                </div>
            </div>
        </div>
        <!-- HEADER TOP END -->
        <?php endif; ?>   
        <!-- HEADER  MID START --> 
        <div class="header_mid">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="logo_area">
                            <?php global $careunit_opt;
                                $logo_url = !empty($careunit_opt['logo_main']['url']) ? $careunit_opt['logo_main']['url'] : null;
                                careunit_logo( $logo_url ); 
                            ?>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <div class="socialicon_area">
                            <?php careunit_socialicons(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- HEADER MID END -->
	<?php
}
// Page sidebar without Metabox;
function careunit_metabox_exclude_blog_page() {
    $post_id = true;

    // If we're showing it based on ID, get the current ID
    if ( isset( $_GET['post'] ) ) {
        $post_id = $_GET['post'];
    } elseif ( isset( $_POST['post_ID'] ) ) {
        $post_id = $_POST['post_ID'];
    }

    if ( ! $post_id ) {
        return false;
    }
    // Get ID of page set as front page, 0 if there isn't one
    $blog_page = get_option( 'page_for_posts' );
    // there is a front page set and we're on it!
    return $post_id !== $blog_page;
}
// Sidebar Layout Possion function;
function careunit_sidebar_layoutpossition($layout, $sidebar_possition, $page_layout=false){
    global $careunit_opt;
    $bloglayout = 'sidebar';
    if($page_layout){
        $bloglayout = $page_layout;
    }else{
        if(isset($careunit_opt[$layout]) && !empty($careunit_opt[$layout])){
            $bloglayout = $careunit_opt[$layout];
        }
    }
    
    if(!empty($_GET['layout'])){
        $bloglayout = $_GET['layout'];
    }

    $blogsidebar = 'right';
    if(isset($careunit_opt[$sidebar_possition]) && !empty($careunit_opt[$sidebar_possition])){
        $blogsidebar = $careunit_opt[$sidebar_possition];
    }
    if(isset($_GET['sidebar']) && $_GET['sidebar']!=''){
        $blogsidebar = $_GET['sidebar'];
    }

    $returnArray = array(
        'blogcolwidth' => 0,
        'blogsidebar' => $blogsidebar
    );
    
    if($bloglayout == 'sidebar'){
        $blogcolwidth = 9;
        $returnArray['blogcolwidth'] = $blogcolwidth;
    }else{
        $blogcolwidth = 12;
        $blogsidebar = 'no-sidebar';
        
        $returnArray['blogcolwidth'] = $blogcolwidth;
        $returnArray['blogsidebar'] = $blogsidebar;
    }
    return $returnArray;
}
// Blog Read More Button Text
function careunit_blog_read_more(){
	global $careunit_opt;
	if(isset($careunit_opt['readmore_text'])){ 
        echo esc_html($careunit_opt['readmore_text']); 
    }else { 
        esc_html_e('Read More', 'careunit');
    }
}

//Change excerpt length
function careunit_change_excerpt_length( $length ) {
	global $careunit_opt;
	
	if(isset($careunit_opt['excerpt_length'])){
		return $careunit_opt['excerpt_length'];
	}
	return 26;
}
add_filter( 'excerpt_length', 'careunit_change_excerpt_length', 999 );

/**
 *  comment list modify 
 */
function careunit_comments($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment; ?>
	<li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
		<div class="media" id="comment-8">
			<div class="comment-meta"> 
				<div class="comment-author vcard"> 
					<?php echo get_avatar( $comment, 32 ); ?>
					<b class="fn"><a href="<?php comment_author_url(); ?>"><?php comment_author(); ?></a></b>
				</div>
				<div class="comment-metadata">
					<?php echo esc_html(get_comment_date('j F, Y')); ?> <?php echo esc_html(get_comment_date('g:i')); ?>
				</div>
				<?php if ($comment->comment_approved == '0') : ?>
					<p><em><?php esc_html_e('Your comment is awaiting moderation.','careunit'); ?></em></p>
				<?php endif; ?>				
			</div>
			<div class="comment-content"> 
				<?php comment_text() ?>
			</div> 
			<div class="reply"><?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))); ?></div>	
		</div>
<?php }

// comment box title change
add_filter( 'comment_form_defaults', 'careunit_remove_comment_form_allowed_tags' );
function careunit_remove_comment_form_allowed_tags( $defaults ) {
	$defaults['comment_notes_after'] = '';
	$defaults['comment_notes_before'] = '';
	return $defaults;
}

// comment form modify

function careunit_modify_comment_form_fields($fields){
	$commenter = wp_get_current_commenter();
	$req	   = get_option( 'require_name_email' );

	$fields['author'] = '<input type="text" name="author" id="author" value="'. esc_attr( $commenter['comment_author'] ) .'" placeholder="'. esc_attr__("Your Name *", "careunit").'" size="22" tabindex="1"'. ( $req ? 'aria-required="true"' : '' ).' class="input-name" />';

	$fields['email'] = '<input type="text" name="email" id="email" value="'. esc_attr( $commenter['comment_author_email'] ) .'" placeholder="'.esc_attr__("Your Email *", "careunit").'" size="22" tabindex="2"'. ( $req ? 'aria-required="true"' : '' ).' class="input-email"  />';
	
	$fields['url'] = '<input type="text" name="url" id="url" value="'. esc_attr( $commenter['comment_author_url'] ) .'" placeholder="'. esc_attr__("Website", "careunit").'" size="22" tabindex="2"'. ( $req ? 'aria-required="false"' : '' ).' class="input-url"  />';

	return $fields;
}
add_filter('comment_form_default_fields','careunit_modify_comment_form_fields'); 

function careunit_comment_reform ($arg) {
	$arg['title_reply'] = esc_html__('Leave a Reply','careunit');
	$arg['comment_field'] = '<textarea id="comment" class="comment_field" name="comment" cols="77" rows="8" placeholder="'. esc_html__("Write your Comment", "careunit").'" aria-required="true"></textarea>';
	return $arg;
}
add_filter('comment_form_defaults','careunit_comment_reform');

function careunit_move_comment_field_to_bottom( $fields ) {
	$comment_field = $fields['comment'];
	unset( $fields['comment'] );
	$fields['comment'] = $comment_field;
	return $fields;
}

add_filter( 'comment_form_fields', 'careunit_move_comment_field_to_bottom' );

// 404 error page title
function careunit_not_found_title() {
	global $careunit_opt;
	if ( isset($careunit_opt['notfound_title'])){
		echo esc_html($careunit_opt['notfound_title']);
	}
	else {
		echo esc_html('Oops! That page can\'t be found.','careunit');
	}
}
// 404 error page error massage
function careunit_not_found_content() {
	global $careunit_opt;
	if ( isset($careunit_opt['notfound_content'])){
		echo esc_html($careunit_opt['notfound_content']);
	}
	else {
		echo esc_html('It looks like nothing was found at this location. Maybe try one of the links below or a search?','careunit');
	}
}
// 404 error page error massage
function careunit_not_found_img() {
	global $careunit_opt;
	if ( !empty ($careunit_opt['not_foundimg']['url'])){ ?>
		<img src="<?php echo esc_url($careunit_opt['not_foundimg']['url']); ?>"/>
	<?php }
	else {
		echo esc_html('404','careunit');
	}
}
// Main Menu
function careunit_headertop_menu(){
	wp_nav_menu( array(
        'theme_location'    => 'headertop', 
        'container_class'   => '',
        'menu_class'        => '',
        'fallback_cb'       => ''
    ));
}

// Main Menu
function careunit_main_menu(){
	wp_nav_menu( array(
        'theme_location'    => 'mainmenu', 
        'container_class'   => 'mainmneu_container',
        'menu_class'        => 'menu',
        'fallback_cb'       => 'careunit_menu_cb'
    ));
}
function careunit_mobile_menu(){
    wp_nav_menu( array(
        'theme_location'    => 'mainmenu', 
        'container_class'   => '',
        'menu_class'        => 'menu_for_mobile',
        'fallback_cb'       => 'careunit_menu_cb'
    ));
}
function careunit_menu_cb (){
        echo '<ul class="falback">';
        echo '<li><a href="' . admin_url( 'nav-menus.php' ) . '">'.esc_html('Add a menu','careunit').'</a></li>';
        echo '</ul>';
}
// Contact copyright text
function careunit_copyright(){
	global $careunit_opt;
	if( isset($careunit_opt['copyright']) && !empty($careunit_opt['copyright']) ) {
		echo wp_kses($careunit_opt['copyright'], array(
			'a' => array(
				'href' => array(),
				'title' => array()
			),
			'br' => array(),
			'em' => array(),
			'strong' => array(),
		));
	} else {
		echo esc_html__('Copyright 2017 ' , 'careunit'). " <a href='".esc_url('themeebit.com')."' target='_blank'>".esc_html__('careunit' , 'careunit')."</a> ".esc_html__('All Rights Reserved by ThemeeBiT.' , 'careunit');

	};
}
//Add google map API
function careunit_googlemap_api(){
	global $careunit_opt;
	//Add google map API
	$google_map_js_url = 'https://maps.googleapis.com/maps/api/js?key=' . $careunit_opt['map_apy_key'];
	return esc_url_raw($google_map_js_url);
}

//For enqueue google map script
function careunit_googlemap_api_enqueue(){
	wp_enqueue_script( 'google-map', careunit_googlemap_api(), array(), null );
    // Inline Map
    wp_add_inline_script('careunit-main-js', careunit_googlemap(),'after');
}

// Google map 
function careunit_googlemap (){ 
	global $careunit_opt;
    $map_desc = ! empty($careunit_opt['map_desc']) ? $careunit_opt['map_desc'] : '';
	$map_desc = str_replace(array("\r\n", "\r", "\n"), "<br />", $map_desc);
	$map_desc = addslashes($map_desc);
	ob_start(); 
?>
        var myCenter=new google.maps.LatLng(<?php if(isset($careunit_opt['map_lat'])) { echo esc_js($careunit_opt['map_lat']); } else { echo '40.76732'; } ?>, <?php if(isset($careunit_opt['map_long'])) { echo esc_js($careunit_opt['map_long']); } else { echo '-74.20487'; } ?>);
            function initialize()
            {
            var mapProp = {
              center:myCenter,
              zoom:<?php if(isset($careunit_opt['map_zoom'])) { echo esc_js($careunit_opt['map_zoom']); } else { echo 14; } ?>,
              scrollwheel:<?php if($careunit_opt['map_scrollwheel'] == 0 ) { echo 'false'; } else { echo 'true'; } ?>,
              mapTypeId:google.maps.MapTypeId.ROADMAP,
                styles: [{"featureType":"water","elementType":"geometry","stylers":[{"color":"<?php echo esc_js($careunit_opt['map_color']);?>"},{"lightness":17}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":20}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffffff"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#ffffff"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":16}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":21}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#dedede"},{"lightness":21}]},{"elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"lightness":16}]},{"elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#333333"},{"lightness":40}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#f2f2f2"},{"lightness":19}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#fefefe"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#fefefe"},{"lightness":17},{"weight":1.2}]}]
              };

            var map=new google.maps.Map(document.getElementById("contactgoogleMap"),mapProp);

            var marker=new google.maps.Marker({
              position:myCenter,
              animation:google.maps.Animation.BOUNCE,
              icon: '<?php echo get_template_directory_uri(); ?>/img/map-marker.png'
            });
            marker.setMap(map);
            
            setTimeout(function(){
                jQuery('.gm-style-iw').parent().addClass('hello');
            },1000);
            }
			var mapContainer = jQuery('#contactgoogleMap');
			if(mapContainer.length){
				google.maps.event.addDomListener(window, 'load', initialize);
			}
	<?php return ob_get_clean();
}


//// BREADCRUMB START ////       
function careunit_the_breadcrumb() {
  $showOnHome = 1; // 1 - show breadcrumbs on the homepage, 0 - don't show
  function careunit_breadcrumb_delimiter(){
      return '<i class="fa fa-angle-double-right"></i>';
  } // delimiter between crumbs
    
  $home = __('Home', 'careunit'); // text for the 'Home' link
  $showCurrent = 1; // 1 - show current post/page title in breadcrumbs, 0 - don't show
    
  function careunit_breadcrumb_before(){
      return '<span class="current">';
  } // tag before the current crumb

  function careunit_breadcrumb_after(){
      return '</span>';
  } // tag after the current crumb

  global $post;
  $homeLink = home_url();
 
  if (is_home() || is_front_page()) {
 
    if ($showOnHome == 1 && is_home()) echo '<div id="crumbs"><a href="' . esc_url($homeLink) . '">' . esc_html($home) . '</a></div>';
 
  } else {
 
    echo '<div id="crumbs"><a href="' . esc_url($homeLink) . '">' . esc_html($home) . '</a> ' . careunit_breadcrumb_delimiter() . ' ';
 
    if ( is_category() ) {
      $thisCat = get_category(get_query_var('cat'), false);
      if ($thisCat->parent != 0) echo get_category_parents($thisCat->parent, TRUE, ' ' . careunit_breadcrumb_delimiter() . ' ');
      echo careunit_breadcrumb_before() . esc_html__('Archive by category "', 'careunit') . single_cat_title('', false) . esc_html__('"', 'careunit') . careunit_breadcrumb_after();
 
    } elseif ( is_search() ) {
      echo careunit_breadcrumb_before() . esc_html__('Search results for "', 'careunit') . get_search_query() . esc_html__('"', 'careunit') . careunit_breadcrumb_after();
 
    } elseif ( is_day() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . careunit_breadcrumb_delimiter() . ' ';
      echo '<a href="' . get_month_link(get_the_time('Y'),get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . careunit_breadcrumb_delimiter() . ' ';
      echo careunit_breadcrumb_before() . get_the_time('d') . careunit_breadcrumb_after();
 
    } elseif ( is_month() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . careunit_breadcrumb_delimiter() . ' ';
      echo careunit_breadcrumb_before() . get_the_time('F') . careunit_breadcrumb_after();
 
    } elseif ( is_year() ) {
      echo careunit_breadcrumb_before() . get_the_time('Y') . careunit_breadcrumb_after();
 
    } elseif ( is_single() && !is_attachment() ) {
      if ( get_post_type() != 'post' ) {
        $post_type = get_post_type_object(get_post_type());
        $slug = $post_type->rewrite;
        echo '<a href="' . esc_url($homeLink) . '/' . esc_attr($slug['slug']) . '/">' . esc_html($post_type->labels->singular_name) . '</a>';
        if ($showCurrent == 1) echo ' ' . careunit_breadcrumb_delimiter() . ' ' . careunit_breadcrumb_before() . get_the_title() . careunit_breadcrumb_after();
      } else {
        $cat = get_the_category(); $cat = $cat[0];
        $cats = get_category_parents($cat, TRUE, ' ' . careunit_breadcrumb_delimiter() . ' ');
        if ($showCurrent == 0) $cats = preg_replace("#^(.+)\s". careunit_breadcrumb_delimiter() ."\s$#", "$1", $cats);
        echo wp_kses($cats, array(
            'a' => array(
                'href' => array(),
                'title' => array()
            ),
            'i' => array(
                'class' => array()
            )
        ));
        if ($showCurrent == 1) echo careunit_breadcrumb_before() . get_the_title() . careunit_breadcrumb_after();
      }
 
    } elseif ( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ) {
      $post_type = get_post_type_object(get_post_type());
      echo careunit_breadcrumb_before() . esc_html($post_type->labels->singular_name) . careunit_breadcrumb_after();
 
    } elseif ( is_attachment() ) {
      $parent = get_post($post->post_parent);
      $cat = get_the_category($parent->ID); $cat = $cat[0];
      echo get_category_parents($cat, TRUE, ' ' . careunit_breadcrumb_delimiter() . ' ');
      echo '<a href="' . get_permalink($parent) . '">' . esc_html($parent->post_title) . '</a>';
      if ($showCurrent == 1) echo ' ' . careunit_breadcrumb_delimiter() . ' ' . careunit_breadcrumb_before() . get_the_title() . careunit_breadcrumb_after();
 
    } elseif ( is_page() && !$post->post_parent ) {
      if ($showCurrent == 1) echo careunit_breadcrumb_before() . get_the_title() . careunit_breadcrumb_after();
 
    } elseif ( is_page() && $post->post_parent ) {
      $parent_id  = $post->post_parent;
      $breadcrumbs = array();
      while ($parent_id) {
        $page = get_page($parent_id);
        $breadcrumbs[] = '<a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';
        $parent_id  = $page->post_parent;
      }
      $breadcrumbs = array_reverse($breadcrumbs);
      for ($i = 0; $i < count($breadcrumbs); $i++) {
        echo wp_kses($breadcrumbs[$i], array(
            'a' => array(
                'href' => array()
            )
        ));
        if ($i != count($breadcrumbs)-1) echo ' ' . careunit_breadcrumb_delimiter() . ' ';
      }
      if ($showCurrent == 1) echo ' ' . careunit_breadcrumb_delimiter() . ' ' . careunit_breadcrumb_before() . get_the_title() . careunit_breadcrumb_after();
 
    } elseif ( is_tag() ) {
      echo careunit_breadcrumb_before() . esc_html__('Posts tagged "', 'careunit') . single_tag_title('', false) . esc_html__('"', 'careunit') . careunit_breadcrumb_after();
 
    } elseif ( is_author() ) {
       global $author;
      $userdata = get_userdata($author);
      echo careunit_breadcrumb_before() . esc_html__('Articles posted by "', 'careunit') . esc_html($userdata->display_name) . esc_html__('"', 'careunit') . careunit_breadcrumb_after();
 
    } elseif ( is_404() ) {
      echo careunit_breadcrumb_before() . esc_html__('Error 404', 'careunit') . careunit_breadcrumb_after();
    }
      
    if ( get_query_var('paged') ) {
          if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() || is_page() ) echo '<span>'.esc_html__(' (', 'careunit');
          echo __('Page', 'careunit') . ' ' . get_query_var('paged');
          if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() || is_page() ) echo esc_html__(')', 'careunit').'</span>';
    }
    echo '</div>';
 
  }
}
//// BREADCRUMB END ////

// Display Blog breadcrumb
function careunit_breadcrumb(){
	global $careunit_opt; ?>
	
	    <!-- START BREADCRUMB AREA -->
        <div  class="breadcrumb_area blog-bdcmb">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12">
						<div class="breadcrumb_title">
							<h2>
                            <?php
                                if(is_home() && is_front_page()){
                                    $title = !empty($careunit_opt['blog_breadcrumb_title']) ? $careunit_opt['blog_breadcrumb_title'] : esc_html__( 'Posts', 'careunit' );
                                }else if(is_home()){
                                    $title = !empty($careunit_opt['blog_breadcrumb_title']) ? $careunit_opt['blog_breadcrumb_title'] : wp_title('', false);
                                }else{
                                    $title = wp_title('', false);
                                }
                                echo esc_html($title);
                            ?>
                            </h2>
						</div>
						<div class="breadcrumb_location">
							<?php careunit_the_breadcrumb(); ?>
						</div>
                    </div>
                </div>
            </div>
        </div> 
        <!-- END BREADCRUMB AREA -->
<?php }