<?php

/**
  ReduxFramework Sample Config File
  For full documentation, please visit: https://docs.reduxframework.com
 * */

if (!class_exists('careunit_Theme_Config')) {

    class careunit_Theme_Config {
        public $args        = array();
        public $sections    = array();
        public $theme;
        public $ReduxFramework;
        public function __construct() {

            if (!class_exists('ReduxFramework')) {
                return;
            }

            // This is needed. Bah WordPress bugs.  ;)
            if (  true == Redux_Helpers::isTheme(__FILE__) ) {
                $this->initSettings();
            } else {
                add_action('plugins_loaded', array($this, 'initSettings'), 10);
            }

        }

        public function initSettings() {

            // Just for demo purposes. Not needed per say.
            $this->theme = wp_get_theme();

            // Set the default arguments
            $this->setArguments();

            // Set a few help tabs so you can see how it's done
            $this->setHelpTabs();

            // Create the sections and fields
            $this->setSections();

            if (!isset($this->args['opt_name'])) { // No errors please
                return;
            }

            $this->ReduxFramework = new ReduxFramework($this->sections, $this->args);
        }

        /**

          This is a test function that will let you see when the compiler hook occurs.
          It only runs if a field	set with compiler=>true is changed.

         * */
        function compiler_action($options, $css, $changed_values) {
            echo '<h1>The compiler hook has run!</h1>';
            echo "<pre>";
            print_r($changed_values); // Values that have changed since the last save
            echo "</pre>";
        }

        /**

          Custom function for filtering the sections array. Good for child themes to override or add to the sections.
          Simply include this function in the child themes functions.php file.

          NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
          so you must use get_template_directory_uri() if you want to use any of the built in icons

         * */
        function dynamic_section($sections) {
            //$sections = array();
            $sections[] = array(
                'title' => esc_html__('Section via hook', 'careunit'),
                'desc' => '<p class="description">'.esc_html__('This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.', 'careunit').'</p>',
                'icon' => 'el-icon-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }

        /**

          Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.

         * */
        function change_arguments($args) {
            return $args;
        }

        /**

          Filter hook for filtering the default value of any given field. Very useful in development mode.

         * */
        function change_defaults($defaults) {
            $defaults['str_replace'] = 'Testing filter hook!';

            return $defaults;
        }

        // Remove the demo link and the notice of integrated demo from the redux-framework plugin
        function remove_demo() {

            // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
            if (class_exists('ReduxFrameworkPlugin')) {
                remove_filter('plugin_row_meta', array(ReduxFrameworkPlugin::instance(), 'plugin_metalinks'), null, 2);

                // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                remove_action('admin_notices', array(ReduxFrameworkPlugin::instance(), 'admin_notices'));
				// If Redux is running as a plugin, this will remove the demo notice and links
				add_action( 'redux/plugin/hooks', array( $this, 'remove_demo' ) );				
            }
        }

        public function setSections() {

            ob_start();

            $ct             = wp_get_theme();
            $this->theme    = $ct;
            $item_name      = $this->theme->get('Name');
            $tags           = $this->theme->Tags;
            $screenshot     = $this->theme->get_screenshot();
            $class          = $screenshot ? 'has-screenshot' : '';

            $customize_title = sprintf(esc_html__('Customize &#8220;%s&#8221;', 'careunit'), $this->theme->display('Name'));
            
            ?>
            <div id="current-theme" class="<?php echo esc_attr($class); ?>">
            <?php if ($screenshot) : ?>
                <?php if (current_user_can('edit_theme_options')) : ?>
                        <a href="<?php echo wp_customize_url(); ?>" class="load-customize hide-if-no-customize" title="<?php echo esc_attr($customize_title); ?>">
                            <img src="<?php echo esc_url($screenshot); ?>" alt="<?php esc_attr_e('Current theme preview', 'careunit'); ?>" />
                        </a>
                <?php endif; ?>
                    <img class="hide-if-customize" src="<?php echo esc_url($screenshot); ?>" alt="<?php esc_attr_e('Current theme preview', 'careunit'); ?>" />
                <?php endif; ?>

                <h4><?php echo esc_attr($this->theme->display('Name')); ?></h4>

                <div>
                    <ul class="theme-info">
                        <li><?php printf(esc_html__('By %s', 'careunit'), $this->theme->display('Author')); ?></li>
                        <li><?php printf(esc_html__('Version %s', 'careunit'), $this->theme->display('Version')); ?></li>
                        <li><?php echo '<strong>' . esc_html__('Tags', 'careunit') . ':</strong> '; ?><?php printf($this->theme->display('Tags')); ?></li>
                    </ul>
                    <p class="theme-description">
                        <?php echo esc_attr($this->theme->display('Description')); ?>
                    </p>
                </div>
            </div>

            <?php
            $item_info = ob_get_contents();

            ob_end_clean();
	
 		// General
		$this->sections[] = array(
			'title'     => esc_html__('General', 'careunit'),
			'desc'      => esc_html__('Use this section to select for general theme options', 'careunit'),
			'icon'      => 'el-icon-cog',
			'fields'    => array(
				array(
					'id'        => 'logo_main',
					'type'      => 'media',
					'title'     => esc_html__('Logo', 'careunit'),
					'subtitle'  => esc_html__('Logo Upload For Headerv1 & Headerv3.', 'careunit'),
					'compiler'  => 'true',
					'mode'      => false,
					'desc'      => esc_html__('Upload logo here.', 'careunit'),
                    
				),
                array(
					'id'        => 'service_length',
					'type'      => 'slider',
					'title'     => esc_html__('Service length on Service page', 'careunit'),
					"default"   => 22,
					"min"       => 10,
					"step"      => 2,
					"max"       => 120,
					'display_value' => 'text'
				),
                array(
					'id'        => 'portfolio_length',
					'type'      => 'slider',
					'title'     => esc_html__('Portfolio length on Service page', 'careunit'),
					"default"   => 2,
					"min"       => 2,
					"step"      => 2,
					"max"       => 3,
					'display_value' => 'text'
				),
                array(
					'id'        => 'breadcrumb_bg_blog',
					'type'      => 'background',
					'output'    => array('.breadcrumb_area.blog-bdcmb'),
					'title'     => esc_html__('Breadcrumb Background Image', 'careunit'),
					'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'careunit'),
					'background-color'	=> false
				),
			),
		);
		$this->sections[] = array(
           'icon'       => 'el-icon-website',
           'title'      => esc_html__( 'Newsletter', 'careunit' ),
           'subsection' => true,
           'fields'     => array(
                array(
                     'id'        => 'newsletter_title',
                     'type'      => 'text',
                     'title'     => esc_html__('Newsletter title', 'careunit'),
                     'default'   => 'Newsletter'
                    ),
                array(
                     'id'       => 'newsletter_form',
                     'type'     => 'text',
                     'title'    => esc_html__('Newsletter form ID', 'careunit'),
                     'subtitle' => esc_html__('The form ID of MailPoet plugin.', 'careunit'),
                     'validate' => 'numeric',
                     'msg'      => 'Please enter a form ID',
                     'default'  => '1'
                    ),
               )
          );
		//Header
		$this->sections[] = array(
			'title'     => esc_html__('Header', 'careunit'),
			'desc'      => esc_html__('Use this section to select for header options', 'careunit'),
			'icon'      => 'el-icon-tasks',
            'fields'    => array(
                array(
					'id'        => 'header_layout',
					'type'      => 'select',
					'title'     => esc_html__('Header Layout', 'careunit'),
					'customizer_only'   => false,

					//Must provide key => value pairs for select options
					'options'   => array(
						'v1' => esc_html__('Default' , 'careunit'),
						'v2' => esc_html__('Second' , 'careunit'),
						'v3' => esc_html__('Third' , 'careunit'),
					),
					'default'   => 'v1',
				),
            )
		);
			
		
		//Header Top
		$this->sections[] = array(
			'title'     => esc_html__('Header Top Bar', 'careunit'),
			'desc'      => esc_html__('Use this section to select options for header top bar.', 'careunit'),
			'icon'      => 'el-icon-tasks',
			'subsection'=> true,
			'fields'    => array(			
				array(
					'id'        => 'show_header_top_bar',
					'type'     => 'switch',
					'title'    => esc_html__('Header Top Bar', 'careunit'),
					'subtitle'	=> esc_html__('Show & Hide header top bar.', 'careunit'),
					'default'  => false,
				),
				array(
					'id'        => 'top_bar_phone',
					'type'      => 'text',
					'title'     => esc_html__('Phone Number', 'careunit'),
					'subtitle'	=> esc_html__('Enter phone number at top bar.', 'careunit'),
				),
				array(
					'id'        => 'top_bar_email',
					'type'      => 'text',
					'title'     => esc_html__('Email Address', 'careunit'),
					'subtitle'	=> esc_html__('Enter email address at top bar.', 'careunit'),
				),
				array(
					'id'       => 'topbar_social_icons',
					'type'     => 'sortable',
					'title'    => esc_html__('Social Icons', 'careunit'),
					'subtitle' => esc_html__('Enter social links at top bar.', 'careunit'),
					'desc'     => esc_html__('Drag/drop to re-arrange', 'careunit'),
					'mode'     => 'text',
					'options'  => array(
						'facebook'     => 'facebook',
						'twitter'     => 'twitter',
						'instagram'	=> 'instagram',
						'tumblr'     => 'tumblr',
						'pinterest'     => 'pinterest',
						'google-plus'     => 'google-plus',
						'linkedin'     => 'linkedin',
						'behance'     => 'behance',
						'dribbble'     => 'dribbble',
						'youtube'     => 'youtube',
						'vimeo'     => 'vimeo',
						'rss'     => 'rss'
					),
					
				)
			),
		);
        //Bacground Color Image
		$this->sections[] = array(
			'title'     => esc_html__('Color Change Option', 'careunit'),
			'desc'      => esc_html__('Use this section to select options for Primary Background Color', 'careunit'),
			'icon'      => 'el-icon-cog',
			'fields'    => array(
				array(
					'id'        => 'background_primary_color',
					'type'      => 'background',
					'output'    => array('.socialicon_area ul li a i, .tab-item ul li a i, .footer_bottom ul li a i, .single_doc_item ul li a i, .doctor_info ul li a i, .top_sidebar, .clinicalServices_inner figcaption i::before, .single_news figcaption, .subscribe_area, .scroll_top, .topsider_box i, .index-2 .single_feature .sfi_bg, .vc_tta.vc_general .vc_tta-panel-title, .btn-color-border-solid, .wpcf7-form-control.wpcf7-submit.btn.btn-default.btn-color-border-solid, input.submit[type="submit"], .widget_wysija_cont p.wysija-paragraph input, .timeline_wrap > .inner::after, .timeline_wrap > .inner::before, .timeline_wrap .timeline_item::before'),
					'title'     => esc_html__('Background Primary Color', 'careunit'),
					'subtitle'  => esc_html__('background color.', 'careunit'),
					'background-image' => false,
					'background-repeat' => false,
					'background-attachment' => false,
					'background-position' => false,
					'background-size' => false,
					'default'  => array(
						'background-color' => '#2986e2',
						
					)
                ),
                array(
					'id'        => 'element_color',
					'type'      => 'color',
					'output'    => array('.sec_Hd span, .choose-list > li::before, .service_icon, .single_coudown i, .index-2 .sc_icon, .footer_top i'),
					'title'     => esc_html__('Change All Primary Color', 'careunit'),
					'subtitle'  => esc_html__('Like i, h5, span, Color', 'careunit'),
					'default'   => '#2986e2'
				),
                array(
                    'id'        => 'background_secondary_color',
                    'type'      => 'background',
                    'output'    => array('.sec_Hd::before, .doctor_catagory li.active, .news_txt a.care_bt:hover, .doctor_opening a.care_bt:hover, .about_cont a.care_bt:hover,.socialicon_area ul li a i.hovereffect, .tab-item ul li a i.hovereffect, .footer_bottom ul li a i.hovereffect, .single_doc_item ul li a i.hovereffect, .doctor_info ul li a i.hovereffect, .mainmneu_container .menu li:hover, .topsider_box.active, .topsider_box i.active, .index-2 .single_feature::before, .index-2 .doctor_catagory li.active'),
                    'title'     => esc_html__('Background Secondary Color', 'careunit'),
                    'subtitle'  => esc_html__('background color.', 'careunit'),
                    'background-image' => false,
                    'background-repeat' => false,
                    'background-attachment' => false,
                    'background-position' => false,
                    'background-size' => false,
                    'default'  => array(
                        'background-color' => '#f25d30',
                    )
                ),
				array(
					'id'        => 'secondary_element_color',
					'type'      => 'color',
					'output'    => array('ul.single_post_admin li i, .news_txt a.care_bt, .doctor_opening a.care_bt, .about_cont a.care_bt, .service_box a.care_bt, .theme_button, .wysija-submit.wysija-submit-field, .index-2 .single_feature:hover .sfi_bg, .as_icon i, .breadcrumb_area ul li a, .footer_top ul li a:hover, .footer_area ul li:hover'),
					'title'     => esc_html__('Change All Secondary Color', 'careunit'),
					'subtitle'  => esc_html__('Like i, h5, span, Color', 'careunit'),
					'default'   => '#f25d30'
				),
				array(
					'id'        => 'border-left-right',
					'type'      => 'border',
					'output'    => array('.service_icon'),
					'title'     => esc_html__('Border Left Right', 'careunit'),
					'subtitle'  => esc_html__('Change Color Option Service Border', 'careunit'),
					'default'  => array(
                        'border-color'  => '#2986e2',
                        'border-style'  => 'solid',
                        'border-left'   => '2px',
                        'border-right'   => '2px'
                    )
				),
				array(
					'id'        => 'border-right-top',
					'type'      => 'border',
					'output'    => array('.service_icon::before'),
					'title'     => esc_html__('Border Right Top', 'careunit'),
					'subtitle'  => esc_html__('Change Color Option Service Border', 'careunit'),
					'default'  => array(
                        'border-color'  => '#2986e2',
                        'border-style'  => 'solid',
                        'border-right'   => '2px',
                        'border-top'   => '2px'
                    )
				),
				array(
					'id'        => 'border-bottom-left',
					'type'      => 'border',
					'output'    => array('.service_icon::after'),
					'title'     => esc_html__('Border Bottom Left', 'careunit'),
					'subtitle'  => esc_html__('Change Color Option Service Border', 'careunit'),
					'default'  => array(
                        'border-color'  => '#2986e2',
                        'border-style'  => 'solid',
                        'border-bottom'   => '2px',
                        'border-left'   => '2px'
                    )
				),
                array(
					'id'        => 'border_around',
					'type'      => 'border',
					'output'    => array('.clinicalServices_inner figcaption i::before'),
					'title'     => esc_html__('Border Around', 'careunit'),
					'subtitle'  => esc_html__('Change Member Border', 'careunit'),
					'default'  => array(
                        'border-color'  => '#2986e2', 
                        'border-style'  => 'solid',
                        'border-top'    => '1px', 
                        'border-right'  => '1px', 
                        'border-bottom' => '1px', 
                        'border-left'   => '1px'
                    )
				),
                array(
					'id'        => 'border14px',
					'type'      => 'border',
					'output'    => array('.doctor_catagory li.active::after'),
					'title'     => esc_html__('Doctor Tab Active Border', 'careunit'),
					'subtitle'  => esc_html__('Doctor Tab Active', 'careunit'),
					'default'  => array(
                        'border-color'  => '#f25d30', 
                        'border-style'  => 'solid',
                        'border-left' => '14px'
                    )
				),
                array(
					'id'        => 'border10px',
					'type'      => 'border',
					'output'    => array('.index-2 .doctor_catagory li.active::after'),
					'title'     => esc_html__('Doctor Tab Home-2', 'careunit'),
					'subtitle'  => esc_html__('Doctor Tab Active', 'careunit'),
					'default'  => array(
                        'border-color'  => '#f25d30', 
                        'border-style'  => 'solid',
                        'border-top' => '10px'
                    )
				),
			),
		);
        //Footer
		$this->sections[] = array(
			'title'     => esc_html__('Footer', 'careunit'),
			'desc'      => esc_html__('Use this section to select options for footer options', 'careunit'),
			'icon'      => 'el-icon-cog',
			'fields'    => array(
				array(
					'id'        => 'background_footer',
					'type'      => 'background',
					'output'    => array('footer.footer_area'),
					'title'     => esc_html__('Footer Background', 'careunit'),
					'subtitle'  => esc_html__('Header background with image.', 'careunit'),
					'background-color' => false,
				)
			),
		);

		//Footer Copyright
		$this->sections[] = array(
			'title'     => esc_html__('Copyright', 'careunit'),
			'desc'      => esc_html__('Use this section to select options for copyright.', 'careunit'),
			'icon'      => 'el-icon-cog',
			'subsection'=> true,
			'fields'    => array(
				array(
					'id'        => 'background_footer_copyright',
					'type'      => 'background',
					'output'    => array('.footer_bottom'),
					'title'     => esc_html__('Footer Copyright Background', 'careunit'),
					'subtitle'  => esc_html__('Footer Copyright background color with image.', 'careunit'),
					'default'  => array(
						'background-color' => '#0e181e',
						
					)
				),	
				array(
					'id'      	=> 'copyright',
					'type'    	=> 'editor',
					'title'   	=> esc_html__('Copyright information', 'careunit'),
					'subtitle'	=> esc_html__('HTML tags allowed: a, br, em, strong', 'careunit'),
					'default'	=> esc_html__('Copyright 2017 careunit. All Rights Reserved' , 'careunit'),
					'args' 		=> array(
						'teeny'            => true,
						'textarea_rows'    => 5,
						'media_buttons'	=> false,
					)
				),
				array(
					'id'       => 'footer_social_icons',
					'type'     => 'sortable',
					'title'    => esc_html__('Social Icons', 'careunit'),
					'subtitle' => esc_html__('Enter social links at footer.', 'careunit'),
					'desc'     => esc_html__('Drag/drop to re-arrange', 'careunit'),
					'mode'     => 'text',
					'options'  => array(
						'facebook'     => 'facebook',
						'twitter'     => 'twitter',
						'instagram'	=> 'instagram',
						'tumblr'     => 'tumblr',
						'pinterest'     => 'pinterest',
						'google-plus'     => 'google-plus',
						'linkedin'     => 'linkedin',
						'behance'     => 'behance',
						'dribbble'     => 'dribbble',
						'youtube'     => 'youtube',
						'vimeo'     => 'vimeo',
						'rss'     => 'rss',
					),
					'default' => array(
						'facebook'		=> 'http://facebook.com/',
						'twitter'		=> 'https://twitter.com/',
						'instagram'		=> '',
						'tumblr'     	=> '',
						'pinterest'     => 'https://uk.pinterest.com/',
						'google-plus'   => 'https://plus.google.com/',
						'linkedin'   	=> 'https://www.linkedin.com/',
						'behance'     	=> '',
						'dribbble'    	=> '',
						'youtube'   	=> '',
						'vimeo'    		=> '',
						'rss'    		=> '',
					),
				),

			),
		);
	
		// Sidebar
		$this->sections[] = array(
			'title'     => esc_html__('Sidebar', 'careunit'),
			'desc'      => esc_html__('Use this section to select for Sidebar options', 'careunit'),
			'icon'      => 'el-icon-cog',
			'fields'    => array(
				array(
					'id'        => 'blog_layout',
					'type'      => 'select',
					'title'     => esc_html__('Blog Layout', 'careunit'),
					'customizer_only'   => false,
					'options'   => array(
						'nosidebar' => esc_html__('No Sidebar', 'careunit'),
						'sidebar' => esc_html__('Sidebar', 'careunit'),
					),
					'default'   => esc_html__('sidebar', 'careunit')
				),
				array(
					'id'       => 'sidebarblog_pos',
					'type'     => 'radio',
					'title'    => esc_html__('Blog Sidebar Position', 'careunit'),
					'subtitle' => esc_html__('Sidebar on Blog pages', 'careunit'),
					'options'  => array(
						'left' => esc_html__('Left', 'careunit'),
						'right' => esc_html__('Right', 'careunit')
					),
					'default'  => esc_html__('right', 'careunit')
				),
                array(
					'id'        => 'single_blog_layout',
					'type'      => 'select',
					'title'     => esc_html__('Single Blog Layout', 'careunit'),
					'customizer_only'   => false,
					'options'   => array(
						'nosidebar' => esc_html__('No Sidebar', 'careunit'),
						'sidebar' => esc_html__('Sidebar', 'careunit'),
					),
					'default'   => esc_html__('sidebar', 'careunit')
				),
				array(
					'id'       => 'sidebar_single_blog_pos',
					'type'     => 'radio',
					'title'    => esc_html__('Single Blog Sidebar Position', 'careunit'),
					'subtitle' => esc_html__('Sidebar on Single Blog pages', 'careunit'),
					'options'  => array(
						'left' => esc_html__('Left', 'careunit'),
						'right' => esc_html__('Right', 'careunit')
					),
					'default'  => esc_html__('right', 'careunit')
				),
			),
		);
	
		// Blog options
		$this->sections[] = array(
			'title'     => esc_html__('Blog', 'careunit'),
			'desc'      => esc_html__('Use this section to select options for blog', 'careunit'),
			'icon'      => 'el-icon-file',
			'fields'    => array(
                array(
					'id'        => 'blog_breadcrumb_title',
					'type'      => 'text',
					'title'     => esc_html__('Breadcrumb Title for Blog', 'careunit'),
					'default'   => esc_html__('Latest news', 'careunit')
				),
				array(
					'id'        => 'readmore_text',
					'type'      => 'text',
					'title'     => esc_html__('Read more text', 'careunit'),
					'default'   => esc_html__('Read More', 'careunit')
				),
				array(
					'id'        => 'excerpt_length',
					'type'      => 'slider',
					'title'     => esc_html__('Excerpt length on blog page', 'careunit'),
					"default"   => 14,
					"min"       => 10,
					"step"      => 2,
					"max"       => 120,
					'display_value' => 'text'
				)
			),
		);
        // Single Pages options
		$this->sections[] = array(
			'title'     => esc_html__('Single Service Option', 'careunit'),
			'desc'      => esc_html__('Use this section to select options for blog', 'careunit'),
			'icon'      => 'el-icon-file',
			'fields'    => array(
                array(
					'id'        => 'appointment_btn_text',
					'type'      => 'text',
					'title'     => esc_html__('Appointment Button Text', 'careunit'),
					'compiler'  => 'true',
					'mode'      => false,
					'desc'      => esc_html__('Change Button Text', 'careunit'),
                    
				),
                array(
					'id'        => 'appointment_btn_link',
					'type'      => 'text',
					'title'     => esc_html__('Appointment Button Link', 'careunit'),
					'compiler'  => 'true',
					'mode'      => false,
					'desc'      => esc_html__('Give Your Button Link', 'careunit'),
                    
				),
			),
		); 
		//Partner logos
		$this->sections[] = array(
			'title'     => esc_html__('Partner Logos', 'careunit'),
			'desc'      => esc_html__('Upload partner logos and links.', 'careunit'),
			'icon'      => 'el-icon-briefcase',
			'fields'    => array(
				array(
					'id'        => 'partnernumber',
					'type'      => 'slider',
					'title'     => esc_html__('Number of partner logo per page', 'careunit'),
					'desc'      => esc_html__('Number of partner logos per page, default value: 6', 'careunit'),
					"default"   => 6,
					"min"       => 1,
					"step"      => 1,
					"max"       => 12,
					'display_value' => 'text'
				),
				array(
					'id'       => 'partnerscroll',
					'type'     => 'switch',
					'title'    => esc_html__('Auto scroll', 'careunit'),
					'default'  => true,
				),
				array(
					'id'          => 'partner_logos',
					'type'        => 'slides',
					'title'       => esc_html__('Logos', 'careunit'),
					'desc'        => esc_html__('Upload logo image and enter logo link.', 'careunit'),
					'placeholder' => array(
						'title'           => esc_html__('Title', 'careunit'),
						'description'     => esc_html__('Description', 'careunit'),
						'url'             => esc_html__('Link', 'careunit'),
					),
				),
			),
        );
		
		//Testimonial Page
		$this->sections[] = array(
			'title'     => esc_html__('Testimonial Page', 'careunit'),
			'desc'      => esc_html__('Testimonial Page Setting', 'careunit'),
			'icon'      => 'el-icon-briefcase',
			'fields'    => array(
				array(
					'id'        => 'testimonialnumber',
					'type'      => 'slider',
					'title'     => esc_html__('Number of post per page', 'careunit'),
					'desc'      => esc_html__('Number of post per page, default value: 8', 'careunit'),
					"default"   => 8,
					"min"       => 1,
					"step"      => 1,
					"max"       => 12,
					'display_value' => 'text'
				),
			),
        );
		
		//404 Not Found Page
		$this->sections[] = array(
			'title'     => esc_html__('404 Error Page', 'careunit'),
			'desc'      => esc_html__('Not Found Page Setting', 'careunit'),
			'icon'      => 'el-icon-briefcase',
			'fields'    => array(
				array(
					'id'       => 'breadcrumb_on_off_error',
					'type'     => 'switch',
					'title'    => esc_html__('Breadcrumb Switch', 'careunit'),
					'subtitle'  => esc_html__('Breadcrumb show & hide switch', 'careunit'),
					'default'  => true,
				),
				array(
					'id'        => 'breadcrumb_bg_error',
					'type'      => 'background',
					'output'    => array('.breadcrumb_area.error-page'),
					'title'     => esc_html__('Breadcrumb Background Image', 'careunit'),
					'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'careunit'),
					'background-color'	=> false
				),
				array(
					'id'        => 'notfound_title',
					'type'      => 'text',
					'title'     => esc_html__('404 Not Found Title', 'careunit'),
					'default'  	=> esc_html__('Oops! That page can\'t be found.', 'careunit'),
				),
				array(
					'id'       => 'notfound_content',
					'type'     => 'text',
					'title'    => esc_html__('404 Not Found Content', 'careunit'),
					'default'  => esc_html__('It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'careunit'),
				),
                
				array(
					'id'        => 'not_foundimg',
					'type'      => 'media',
					'title'     => esc_html__('Not Found Image', 'careunit'),
					'subtitle'  => esc_html__('Error Image', 'careunit'),
					'compiler'  => 'true',
					'mode'      => false,
					'desc'      => esc_html__('Upload Error Image here', 'careunit'),
                    
				),
			),
        );
		// Contact Map
        $this->sections[] = array(
			'title'     => esc_html__('Google Map', 'careunit'),
			'desc'      => esc_html__('Use this section to select options for Google Map on contact page', 'careunit'),
			'icon'      => 'el-icon-map-marker',
			'fields'    => array(
				array(
					'id'        => 'map_apy_key',
					'type'      => 'text',
					'title'     => esc_html__('Google API Key', 'careunit'),
					'subtitle'	=>  '<a target="_blank" href="'.esc_url('https://developers.google.com/maps/documentation/javascript/get-api-key', 'careunit').'">'.esc_html__('Click Here', 'careunit').'</a> '.esc_html__('to Get a Google Maps API KEY', 'careunit').'', 
				),
				array(
					'id'        => 'contact_form',
					'type'      => 'text',
					'title'     => esc_html__('Contact Form', 'careunit'),
				),
				array(
					'id'        => 'map_lat',
					'type'      => 'text',
					'title'     => esc_html__('Latitude', 'careunit'),
					'default'   => '23.763762'
				),
				array(
					'id'        => 'map_long',
					'type'      => 'text',
					'title'     => esc_html__('Longtitude', 'careunit'),
					'default'   => '90.4311185',
				),
				array(
					'id'        => 'map_zoom',
					'type'      => 'slider',
					'title'     => esc_html__('Zoom level', 'careunit'),
					"default"   => 17,
					"min"       => 0,
					"step"      => 1,
					"max"       => 21,
					'display_value' => 'text'
				),
				array(
					'id'        => 'map_color',
					'type'      => 'color',
					'title'     => esc_html__('Map Color', 'careunit'),
					'default'   => '#2986e2',
				),
				array(
					'id'        => 'map_scrollwheel',
					'type'      => 'switch',
					'title'     => esc_html__('Scroll Wheel', 'careunit'),
					'desc'      => esc_html__('Switch scrollwheel On OFF', 'careunit'),
					'default'=> 0,
				),				
				array(
					'id'        => 'map_marker',
					'type'      => 'media',
					'title'     => esc_html__('Marker', 'careunit'),
					'compiler'  => 'true',
					'mode'      => false, // Can be set to false to allow any media type, or can also be set to any mime type.
					'desc'      => esc_html__('Upload marker image here, the image size is 30x43 pixels.', 'careunit'),
				),
			),
        );
		$this->sections[] = array(
			'icon'       => 'el-icon-website',
			'title'      => esc_html__( 'Contact Page', 'careunit' ),
			'subsection' => true,
			'fields'     => array(
                    array(
                        'id'        => 'breadcrumb_bg_blog',
                        'type'      => 'background',
                        'output'    => array('.breadcrumb_area.contact-bdcmb'),
                        'title'     => esc_html__('Breadcrumb Background Image', 'careunit'),
                        'subtitle'  => esc_html__('Pick a breadcrumb background with image and color.', 'careunit'),
                        'background-color'	=> false
                    ),
                    array(
                        'id'        => 'contect_title',
                        'type'      => 'text',
                        'title'     => esc_html__('Contact Title', 'careunit'),
                        'subtitle'     => esc_html__('The Title for contact page (example: Contact Us)', 'careunit'),
                        'default'   => esc_html__('Get In Touch', 'careunit'),
                    ),
                    array(
                        'id'        => 'title_description',
                        'type'      => 'textarea',
                        'title'     => esc_html__('Contact Title Description', 'careunit'),
                        'subtitle'     => esc_html__('The Description for contact page (example: Contact Us)', 'careunit'),
                        'default'   => esc_html__('set You Description', 'careunit'),
                    ),
                    array(
                        'id'        => 'address_title',
                        'type'      => 'text',
                        'title'     => esc_html__('Address Title', 'careunit'),
                        'subtitle'     => esc_html__('Paste your contect form Title', 'careunit'),
                        'default'   => ''
                    ),
                    array(
                        'id'        => 'messages_title',
                        'type'      => 'text',
                        'title'     => esc_html__('message Box Title', 'careunit'),
                        'subtitle'     => esc_html__('Paste your contect form Title', 'careunit'),
                        'default'   => ''
                    ),
                    array(
                        'id'        => 'contect_from',
                        'type'      => 'textarea',
                        'title'     => esc_html__('Contact Form', 'careunit'),
                        'subtitle'     => esc_html__('Paste your contect form Shortcode here', 'careunit'),
                        'default'   => ''
                    ),
                    array(
                        'id'      	=> 'contact_custom_text',
                        'type'    	=> 'editor',
                        'title'   	=> esc_html__('Contact Information', 'careunit'),
                        'subtitle'	=> esc_html__('HTML tags allowed: a, br, em, strong', 'careunit'),
                        'default'	=> "<ul><li><p>".esc_html('Phone', 'careunit')."</p><h6>".esc_html('+000 111 2222 33 44', 'careunit')."<p>".esc_html('Monday-Friday, 8am - 8pm', 'careunit')."</p></h6></li><li><p>".esc_html('Email', 'careunit')."</p><h6>".esc_html('info@giant.com', 'careunit')."<p>".esc_html('Drop us a line anytime!', 'careunit')."</p></h6></li><li><p>".esc_html('Address', 'careunit')."</p><h6>".esc_html('724 Woodland Road', 'careunit')."<p>".esc_html('Marlton, NJ 08053', 'careunit')."</p></h6></li></ul>",
                        'args' 		=> array(
                            'teeny'            => true,
                            'textarea_rows'    => 5,
                            'media_buttons'	=> false,
                        )
                    ),
                ),
        );
		
		// Less Compiler
		$this->sections[] = array(
			'title'     => esc_html__('Less Compiler', 'careunit'),
			'desc'      => esc_html__('Turn on this option to apply all theme options. Turn of when you have finished changing theme options and your site is ready.', 'careunit'),
			'icon'      => 'el-icon-wrench',
			'fields'    => array(
				array(
					'id'        => 'enable_less',
					'type'      => 'switch',
					'title'     => esc_html__('Enable Less Compiler', 'careunit'),
					'default'   => true,
				),
			),
		);

            $this->sections[] = array(
                'title'     => esc_html__('Import / Export', 'careunit'),
                'desc'      => esc_html__('Import and Export your Redux Framework settings from file, text or URL.', 'careunit'),
                'icon'      => 'el-icon-refresh',
                'fields'    => array(
                    array(
                        'id'            => 'opt-import-export',
                        'type'          => 'import_export',
                        'title'         => 'Import Export',
                        'subtitle'      => 'Save and restore your Redux options',
                        'full_width'    => false,
                    ),
                ),
            );

            $this->sections[] = array(
                'icon'      => 'el-icon-info-sign',
                'title'     => esc_html__('Theme Information', 'careunit'),
				'icon'      => 'el-icon-website',
                'fields'    => array(
                    array(
                        'id'        => 'opt-raw-info',
                        'type'      => 'raw',
                        'content'   => $item_info,
                    )
                ),
            );
        }

        public function setHelpTabs() {

            // Custom page help tabs, displayed using the help API. Tabs are shown in order of definition.
            $this->args['help_tabs'][] = array(
                'id'        => 'redux-help-tab-1',
                'title'     => esc_html__('Theme Information 1', 'careunit'),
                'content'   => '<p>'.esc_html__('This is the tab content, HTML is allowed.', 'careunit').'</p>'
            );

            $this->args['help_tabs'][] = array(
                'id'        => 'redux-help-tab-2',
                'title'     => esc_html__('Theme Information 2', 'careunit'),
                'content'   => '<p>'.esc_html__('This is the tab content, HTML is allowed.', 'careunit').'</p>'
            );

            // Set the help sidebar
            $this->args['help_sidebar'] = '<p>'.esc_html__('This is the sidebar content, HTML is allowed.', 'careunit').'</p>';
        }

        /**

          All the possible arguments for Redux.
          For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments

         * */
        public function setArguments() {

            $theme = wp_get_theme(); // For use with some settings. Not necessary.

            $this->args = array(
                // TYPICAL -> Change these values as you need/desire
                'opt_name'          => 'careunit_opt',        // This is where your data is stored in the database and also becomes your global variable name.
                'display_name'      => $theme->get('Name'),     // Name that appears at the top of your panel
                'display_version'   => $theme->get('Version'),  // Version that appears at the top of your panel
                'menu_type'         => 'menu',                  //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
                'allow_sub_menu'    => true,                    // Show the sections below the admin menu item or not
                'menu_title'        => esc_html__('Theme Options', 'careunit'),
                'page_title'        => esc_html__('Theme Options', 'careunit'),
                
                // You will need to generate a Google API key to use this feature.
                // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
                'google_api_key' => '', // Must be defined to add google fonts to the typography module
                
                'async_typography'  => true,                    // Use a asynchronous font on the front end or font string
                //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
                'admin_bar'         => true,                    // Show the panel pages on the admin bar
                'global_variable'   => '',                      // Set a different name for your global variable other than the opt_name
                'dev_mode'          => false,                    // Show the time the page took to load, etc
                'customizer'        => true,                    // Enable basic customizer support
                //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
                //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

                // OPTIONAL -> Give you extra features
                'page_priority'     => null,                    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
                'page_parent'       => 'themes.php',            // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
                'page_permissions'  => 'manage_options',        // Permissions needed to access the options panel.
                'menu_icon'         => '',                      // Specify a custom URL to an icon
                'last_tab'          => '',                      // Force your panel to always open to a specific tab (by id)
                'page_icon'         => 'icon-themes',           // Icon displayed in the admin panel next to your menu_title
                'page_slug'         => '_options',              // Page slug used to denote the panel
                'save_defaults'     => true,                    // On load save the defaults to DB before user clicks save or not
                'default_show'      => false,                   // If true, shows the default value next to each field that is not the default value.
                'default_mark'      => '',                      // What to print by the field's title if the value shown is default. Suggested: *
                'show_import_export' => true,                   // Shows the Import/Export panel when not used as a field.
                
                // CAREFUL -> These options are for advanced use only
                'transient_time'    => 60 * MINUTE_IN_SECONDS,
                'output'            => true,                    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
                'output_tag'        => true,                    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
                // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.
                
                // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
                'database'              => '', // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
                'system_info'           => false, // REMOVE

                // HINTS
                'hints' => array(
                    'icon'          => 'icon-question-sign',
                    'icon_position' => 'right',
                    'icon_color'    => 'lightgray',
                    'icon_size'     => 'normal',
                    'tip_style'     => array(
                        'color'         => 'light',
                        'shadow'        => true,
                        'rounded'       => false,
                        'style'         => '',
                    ),
                    'tip_position'  => array(
                        'my' => 'top left',
                        'at' => 'bottom right',
                    ),
                    'tip_effect'    => array(
                        'show'          => array(
                            'effect'        => 'slide',
                            'duration'      => '500',
                            'event'         => 'mouseover',
                        ),
                        'hide'      => array(
                            'effect'    => 'slide',
                            'duration'  => '500',
                            'event'     => 'click mouseleave',
                        ),
                    ),
                )
            );


            // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
            $this->args['share_icons'][] = array(
                'url'   => 'https://github.com/ReduxFramework/ReduxFramework',
                'title' => 'Visit us on GitHub',
                'icon'  => 'el-icon-github'
                //'img'   => '', // You can use icon OR img. IMG needs to be a full URL.
            );
            $this->args['share_icons'][] = array(
                'url'   => 'https://www.facebook.com/pages/Redux-Framework/243141545850368',
                'title' => 'Like us on Facebook',
                'icon'  => 'el-icon-facebook'
            );
            $this->args['share_icons'][] = array(
                'url'   => 'http://twitter.com/reduxframework',
                'title' => 'Follow us on Twitter',
                'icon'  => 'el-icon-twitter'
            );
            $this->args['share_icons'][] = array(
                'url'   => 'http://www.linkedin.com/company/redux-framework',
                'title' => 'Find us on LinkedIn',
                'icon'  => 'el-icon-linkedin'
            );

            // Panel Intro text -> before the form
            if (!isset($this->args['global_variable']) || $this->args['global_variable'] !== false) {
                if (!empty($this->args['global_variable'])) {
                    $v = $this->args['global_variable'];
                } else {
                    $v = str_replace('-', '_', $this->args['opt_name']);
                }
            } else {}
        }
    }
    global $reduxConfig;
    $reduxConfig = new careunit_Theme_Config();
}

/**
  Custom function for the callback referenced above
 */
if (!function_exists('redux_my_custom_field')):
    function redux_my_custom_field($field, $value) {
        print_r($field);
        echo '<br/>';
        print_r($value);
    }
endif;

/**
  Custom function for the callback validation referenced above
 * */
if (!function_exists('redux_validate_callback_function')):
    function redux_validate_callback_function($field, $value, $existing_value) {
        $error = false;
        $value = 'just testing';
        $return['value'] = $value;
        if ($error == true) {
            $return['error'] = $field;
        }
        return $return;
    }
endif;
