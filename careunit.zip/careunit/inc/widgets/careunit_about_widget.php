<?php 
/**
 * Adds About info Widget.
 */
function careunit_info_widget_value($key){
    return $key;
}
class careunit_info_Widget extends WP_Widget{
	/**
	 * Register widget with WordPress.
	 */
	function __construct(){

		$widget_ops = array( 'info' => esc_html__('About Info.', 'careunit'),'customize_selective_refresh' => true, );
 		parent:: __construct('careunit_info_Widget', esc_html__('Careunit: About Info', 'careunit'),$widget_ops );
	}
	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $value Saved values from database.
	 */
	public function widget($args, $value){
        $image	= isset( $value['image'] ) ? $value['image'] : '';
		$info = !empty($value['info']) ? $value['info'] : '';
		$wid_fbLink = !empty($value['fb_Link']) ? $value['fb_Link'] : '';
		$wid_twLink = !empty($value['tw_Link']) ? $value['tw_Link'] : '';
		$wid_linkedin = !empty($value['linkedin_link']) ? $value['linkedin_link'] : '';
		$wid_skyLink = !empty($value['sky_link']) ? $value['sky_link'] : '';
		?>
		<?php echo careunit_info_widget_value($args['before_widget']); ?>
		<div class="social_icon footer_icon">
			<div class="footer_widget">
                <div class="footer_logo">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo-footer">
					    <img src="<?php echo esc_attr ($image); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>">
				    </a>
				</div>
                <p><?php echo esc_attr ($info); ?></p>
                <ul class="social_icon">
                    <?php if(!empty($wid_fbLink)){ ?>
                    <li class="active">
                        <a href="<?php echo esc_attr ($wid_fbLink); ?>" target="_blank">
                            <i class="fa fa-facebook"></i>
                        </a>
                    </li>
                    <?php }
        
                    if(!empty($wid_twLink)){ ?>
                        <li>
                            <a href="<?php echo esc_attr ($wid_twLink); ?>" target="_blank">
                                <i class="fa fa-twitter"></i>
                            </a>
                        </li>
                    <?php }
        
                    if(!empty($wid_linkedin)){ ?>
                        <li>
                            <a href="<?php echo esc_attr ($wid_linkedin); ?>" target="_blank">
                                <i class="fa fa-linkedin"></i>
                            </a>
                        </li>
                    <?php }
        
                    if(!empty($wid_skyLink)){ ?>
                        <li>
                            <a href="<?php echo esc_attr ($wid_skyLink); ?>" target="_blank">
                                <i class="fa fa-skype"></i>
                            </a>
                        </li>
                    <?php } ?>
                </ul>
            </div>
        </div>
		<?php echo careunit_info_widget_value($args['after_widget']); ?>

		<?php
	}
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_value Values just sent to be saved.
	 * @param array $old_value Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update($new_value, $old_value){
        $value['image'] = ( !empty($new_value['image']) ) ? strip_tags ( $new_value['image'] ) : '';
        $value['info'] = ( !empty($new_value['info']) ) ? strip_tags ( $new_value['info'] ) : '';
        $value['fb_Link'] = ( !empty($new_value['fb_Link']) ) ? strip_tags ( $new_value['fb_Link'] ) : '';
        $value['tw_Link'] = ( !empty($new_value['tw_Link']) ) ? strip_tags ( $new_value['tw_Link'] ) : '';
        $value['linkedin_link'] = ( !empty($new_value['linkedin_link']) ) ? strip_tags ( $new_value['linkedin_link'] ) : '';
        $value['sky_link'] = ( !empty($new_value['sky_link']) ) ? strip_tags ( $new_value['sky_link'] ) : '';

		return $value;

	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $value Previously saved values from database.
	 */
	public function form($value){
		$image = !empty($value['image']) ? $value['image'] : '';
		$info = !empty($value['info']) ? $value['info'] : '';
		$wid_fbLink = !empty($value['fb_Link']) ? $value['fb_Link'] : '';
        $wid_twLink = !empty($value['tw_Link']) ? $value['tw_Link'] : '';
		$wid_linkedin = !empty($value['linkedin_link']) ? $value['linkedin_link'] : '';
		$wid_skyLink = !empty($value['sky_link']) ? $value['sky_link'] : '';
	?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('logo_title')); ?>">
			    <?php esc_html_e('Footer_Logo:' ,'careunit') ?>
			 </label>
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'logo_title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'image' )); ?>" value="<?php echo esc_attr( $image ); ?>" class="widefat image" />
		</p>
		<p>
            <button type="submit" class="upload_image btn btn-primary">
			     <?php esc_html_e('Select/ Upload','careunit' ) ?>
            </button>
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('info_des')); ?>">
			    <?php esc_html_e('Description:' ,'careunit') ?>
			</label>
			<textarea id="<?php echo esc_attr($this->get_field_id('info_des')); ?>" name="<?php echo esc_attr($this->get_field_name('info')); ?>" rows="10" class="widefat">
			    <?php echo esc_attr( $info ); ?>
			</textarea>
		<p>
        <p>
			<label for="<?php echo esc_attr($this->get_field_id('facebooklink')); ?>">
			    <?php esc_html_e('Facebook Link:' ,'careunit') ?>
            </label>
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'facebooklink' )); ?>" 
			name="<?php echo esc_attr($this->get_field_name( 'fb_Link' )); ?>" 
			value="<?php echo esc_attr( $wid_fbLink ); ?>" class="widefat" />
		</p>
        <p>
			<label for="<?php echo esc_attr($this->get_field_id('twitterlink')); ?>">
			    <?php esc_html_e('Twitter Link:' ,'careunit') ?>
            </label>
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'twitterlink' )); ?>" 
			name="<?php echo esc_attr($this->get_field_name( 'tw_Link' )); ?>" 
			value="<?php echo esc_attr( $wid_twLink ); ?>" class="widefat" />
		</p>
        <p>
			<label for="<?php echo esc_attr($this->get_field_id('linkedin')); ?>">
			    <?php esc_html_e('Linkedin Link:' ,'careunit') ?>
            </label>
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'linkedin' )); ?>" 
			name="<?php echo esc_attr($this->get_field_name( 'linkedin_link' )); ?>" 
			value="<?php echo esc_attr( $wid_linkedin ); ?>" class="widefat" />
		</p>
        <p>
			<label for="<?php echo esc_attr($this->get_field_id('skype')); ?>">
			    <?php esc_html_e('Skype Link:' ,'careunit') ?>
            </label>
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'skype' )); ?>" 
			name="<?php echo esc_attr($this->get_field_name( 'sky_link' )); ?>" 
			value="<?php echo esc_attr( $wid_skyLink ); ?>" class="widefat" />
		</p>
	<?php
	}
}

// register Short description widget
function careunit_info_Widget() {
    register_widget( 'careunit_info_Widget' );
}
add_action( 'widgets_init', 'careunit_info_Widget' );