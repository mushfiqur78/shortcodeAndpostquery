<?php
function careunit_return_value($key){
    return $key;
}

add_action('widgets_init', 'careunit_recent_post_load_widgets');
function careunit_recent_post_load_widgets(){
	register_widget('careunit_recent_post_Widget');
}
class careunit_recent_post_Widget extends WP_Widget {
	public function __construct() {
		$widget_ops = array('classname' => 'careunit_recent', 'description' => esc_html__('careunit: Recent Posts Widget','careunit') );
		$control_ops = array('id_base' => 'careunit_recent-widget');
		parent::__construct('careunit_recent-widget', esc_html__('Careunit: Recent Posts','careunit'), $widget_ops, $control_ops);
	}
	function widget($args, $instance){
		extract($args);
		$title = apply_filters('widget_title', $instance['title']);
		$number = $instance['number'];
		$post_image = $instance[ 'post_image' ] ? 'true' : 'false';
		$post_date = $instance[ 'post_date' ] ? 'true' : 'false';
		echo careunit_return_value($args['before_widget']);
		if($title) {
			echo careunit_return_value($args['before_title']) . esc_html($title) . careunit_return_value($args['after_title']);
		}
		?>
		<!-- start coding  -->
        <div class="sidebar_widget_body recent_post">
            <ul>
               <?php
				$post_args = array(
					'post_type' => 'post',
					'posts_per_page' => $number,
					'has_password' => false,
					'order' => 'DESC'
				);
				$post = new WP_Query($post_args);
					if($post->have_posts()):
				?>
				<?php while($post->have_posts()): $post->the_post(); ?>
				<?php
					$permalink = get_permalink(); ?>
                      
                        <li>
                           <?php $x = 0; if( 'on' == $instance[ 'post_image' ] ) : $x++; ?>
                            <div class="recent_post_image">
                                <a class="" href="<?php echo esc_url($permalink); ?>">
                                    <?php
                                    if ( has_post_thumbnail() ) {
                                        the_post_thumbnail( 'careunit-widgetPostthumb', array( 'class' => 'img-responsive' ) );
                                    }
                                    ?>						  
                                </a>
                            </div>
                            <?php endif; ?>
                            <div class="recnet_post_content <?php echo ($x == 0) ? 'noImage' : null?>">
                                    <h4><a href="<?php echo esc_url($permalink); ?>"><?php the_title(); ?></a></h4>
                                <p><span><?php echo get_the_date(); ?></span></p>
                                <?php if( 'on' == $instance[ 'post_date' ] ) : ?>
                                <?php endif; ?>
                            </div>
                        </li>
                <?php  endwhile; endif; 
				wp_reset_postdata();
				?>	
            </ul>
        </div>
		<?php
		echo careunit_return_value($args['after_widget']);
	}

	function update($new_instance, $old_instance){
		$instance = $old_instance;
		$instance['title'] = $new_instance['title'];
		$instance['number'] = $new_instance['number'];
		$instance['post_image'] = $new_instance['post_image'];
		$instance['post_date'] = $new_instance['post_date'];
		return $instance;
	}

	function form($instance)
	{
		$defaults = array('title' => 'Recent Posts', 'post_image' => '', 'post_date' => '', 'number' => 4);
		$instance = wp_parse_args((array) $instance, $defaults); ?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title','careunit'); ?>:</label>
			<input class="widefat" type="text" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php echo esc_attr($instance['title']); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of Posts to show','careunit'); ?>:</label>
			<input class="widefat" type="number" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" value="<?php echo esc_attr($instance['number']); ?>" />
		</p>
		<p>
			<input class="checkbox" type="checkbox" <?php checked( $instance[ 'post_image' ], 'on' ); ?> id="<?php echo esc_attr($this->get_field_id( 'post_image' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'post_image' )); ?>" /> 
			<label for="<?php echo esc_attr($this->get_field_id( 'post_image' )); ?>"><?php esc_html_e('Show Post/News Image', 'careunit'); ?></label>
		</p>
		<p>
			<input class="checkbox" type="checkbox" <?php checked( $instance[ 'post_date' ], 'on' ); ?> id="<?php echo esc_attr($this->get_field_id( 'postDate' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'post_date' )); ?>" /> 
			<label for="<?php echo esc_attr($this->get_field_id( 'postDate' )); ?>">
			    <?php esc_html_e('Show Post Date', 'careunit'); ?>
			</label>
		</p>
	<?php
	}
}
