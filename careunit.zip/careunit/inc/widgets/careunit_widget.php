<?php 
/**
 * Adds About address Widget.
 */
function careunit_address_return_value($key){
	return $key;
}

class careunit_address_Widget extends WP_Widget{
	/**
	 * Register widget with WordPress.
	 */
	function __construct(){

		$widget_ops = array( 'address' => esc_html__('About address.', 'careunit'),'customize_selective_refresh' => true, );
 		parent:: __construct('careunit_address_Widget', esc_html__('Careunit: Address', 'careunit'),$widget_ops );
	}
	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $subvalue Saved values from database.
	 */
	public function widget($args, $subvalue){
		$wid_addressTitle = !empty($subvalue['contact_hedding']) ? $subvalue['contact_hedding'] : '';
		$wid_des = !empty($subvalue['contact_description']) ? $subvalue['contact_description'] : '';
		$wid_address = !empty($subvalue['cont_address']) ? $subvalue['cont_address'] : '';
		$wid_phone = !empty($subvalue['cont_phone']) ? $subvalue['cont_phone'] : '';
		$wid_email = !empty($subvalue['cont_email']) ? $subvalue['cont_email'] : '';
		$wid_time = !empty($subvalue['cont_time']) ? $subvalue['cont_time'] : '';
		?>
		<?php echo careunit_address_return_value($args['before_widget']); ?>
            <div class="footer_Widgets">
                <h5><?php echo esc_html ($wid_addressTitle); ?></h5>
                <p><?php echo esc_html ($wid_des); ?></p>
                <div class="widget_text">
                    <ul>
                        <li><i class="fa fa-building-o"></i>
                        <span>
                            <?php echo esc_attr ($wid_address); ?>
                        </span>
                         </li>
                        <li><i class="fa fa-whatsapp"></i>
                            <span>
                                <?php echo esc_attr ($wid_phone); ?>
                            </span>
                         </li>
                        <li><i class="fa fa-envelope"></i> 
                        <?php echo esc_attr ($wid_email); ?>
                        </li>
                        <li><i class="fa fa-desktop"></i>
                            <span> 
                                <?php echo esc_attr ($wid_time); ?>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
		<?php echo careunit_address_return_value($args['after_widget']); ?>

		<?php
	}
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_value Values just sent to be saved.
	 * @param array $old_value Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update($new_value, $old_value){
        $subvalue['contact_hedding'] = ( !empty($new_value['contact_hedding']) ) ? strip_tags ( $new_value['contact_hedding'] ) : '';
        $subvalue['contact_description'] = ( !empty($new_value['contact_description']) ) ? strip_tags ( $new_value['contact_description'] ) : '';
        $subvalue['cont_address'] = ( !empty($new_value['cont_address']) ) ? strip_tags ( $new_value['cont_address'] ) : '';
        $subvalue['cont_phone'] = ( !empty($new_value['cont_phone']) ) ? strip_tags ( $new_value['cont_phone'] ) : '';
        $subvalue['cont_email'] = ( !empty($new_value['cont_email']) ) ? strip_tags ( $new_value['cont_email'] ) : '';
        $subvalue['cont_time'] = ( !empty($new_value['cont_time']) ) ? strip_tags ( $new_value['cont_time'] ) : '';

		return $subvalue;

	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $subvalue Previously saved values from database.
	 */
	public function form($subvalue){
		$wid_addressTitle = !empty($subvalue['contact_hedding']) ? $subvalue['contact_hedding'] : '';
        $wid_des = !empty($subvalue['contact_description']) ? $subvalue['contact_description'] : '';
		$wid_address = !empty($subvalue['cont_address']) ? $subvalue['cont_address'] : '';
		$wid_phone = !empty($subvalue['cont_phone']) ? $subvalue['cont_phone'] : '';
		$wid_email = !empty($subvalue['cont_email']) ? $subvalue['cont_email'] : '';
		$wid_time = !empty($subvalue['cont_time']) ? $subvalue['cont_time'] : '';
	?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('address-title')); ?>">
			    <?php esc_html_e('Address Title:' ,'careunit') ?>
            </label>
			
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'address-title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'contact_hedding' )); ?>" value="<?php echo esc_attr( $wid_addressTitle ); ?>" class="widefat" />
        </p>
        <p>
			<label for="<?php echo esc_attr($this->get_field_id('carepludes')); ?>">
			    <?php esc_html_e('Description:' ,'careunit') ?>
            </label>
			
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'carepludes' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'contact_description' )); ?>" value="<?php echo esc_attr( $wid_des ); ?>" class="widefat" />
        </p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('address_field')); ?>">
			    <?php esc_html_e('Address:' ,'careunit') ?>
            </label>
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'address_field' )); ?>"
			name="<?php echo esc_attr($this->get_field_name( 'cont_address' )); ?>" 
			value="<?php echo esc_attr( $wid_address ); ?>" class="widefat" />
        </p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('phoneno')); ?>">
			    <?php esc_html_e('Phone No:' ,'careunit') ?>
            </label>
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'phoneno' )); ?>"
			name="<?php echo esc_attr($this->get_field_name( 'cont_phone' )); ?>" 
			value="<?php echo esc_attr( $wid_phone ); ?>" class="widefat" />
        </p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('emailinfo')); ?>">
			    <?php esc_html_e('Email:' ,'careunit') ?>
            </label>
			<input type="email" id="<?php echo esc_attr($this->get_field_id( 'emailinfo' )); ?>"
			name="<?php echo esc_attr($this->get_field_name( 'cont_email' )); ?>" 
			value="<?php echo esc_attr( $wid_email ); ?>" class="widefat" />
        </p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('call_time')); ?>">
			    <?php esc_html_e('Contact Time:' ,'careunit') ?>
            </label>
			<input type="text" id="<?php echo esc_attr($this->get_field_id( 'call_time' )); ?>"
			name="<?php echo esc_attr($this->get_field_name( 'cont_time' )); ?>" 
			value="<?php echo esc_attr( $wid_time ); ?>" class="widefat" />
        </p>

	<?php
	}
}

// register Short description widget
function careunit_address_Widget() {
    register_widget( 'careunit_address_Widget' );
}
add_action( 'widgets_init', 'careunit_address_Widget' );