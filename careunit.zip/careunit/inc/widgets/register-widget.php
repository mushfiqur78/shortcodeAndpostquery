<?php
/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */

function careunit_widgets_init() {
	register_sidebar( array(
		'name' => esc_html__( 'Blog Sidebar', 'careunit' ),
		'id' => 'sidebar-1',
		'description' => esc_html__( 'Sidebar on blog page', 'careunit' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<div class="sidebar_widget_title"><h4>',
		'after_title' => '</h4></div>',
	) );
	register_sidebar( array(
		'name' => esc_html__( 'Single Blog Sidebar', 'careunit' ),
		'id' => 'sidebar-singleblog',
		'description' => esc_html__( 'Sidebar on Singel blog page', 'careunit' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<div class="sidebar_widget_title"><h4>',
		'after_title' => '</h4></div>',
	) );
    
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Sidebar', 'careunit' ),
		'id'            => 'footer-sidebar',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="footer_widgets %2$s col-sm-3">',
		'after_widget' => '</aside>',
		'before_title' => '<div class="footer_Widgets"><h5>',
		'after_title' => '</h5></div>',
	) );
	
}
add_action( 'widgets_init', 'careunit_widgets_init' );
/**
 * Widget
 */
require_once get_template_directory() . '/inc/widgets/careunit_recent_post_widget.php';
require_once get_template_directory() . '/inc/widgets/careunit_about_widget.php';
require_once get_template_directory() . '/inc/widgets/careunit_widget.php';