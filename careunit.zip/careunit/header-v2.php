<body <?php body_class(); ?>>
    <div id="page" class="site index-2">
        <!-- HEADER START -->      
        <header class="header_area">
           <?php careunit_hearder_topv2(); ?>
           
            <!-- MAIN MENU START --> 
            <div class="main_menu_area hidden-xs ">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="mainnmenu">
							    <nav>
									<?php careunit_main_menu(); ?>
								</nav>
								<nav class="mb_menu hidden">
									<?php careunit_mobile_menu(); ?>
								</nav>
                                <div class="menu_searchbox">
                                    <?php get_search_form(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- MAIN MENU END -->     
       </header>
       <!-- HEADER END -->