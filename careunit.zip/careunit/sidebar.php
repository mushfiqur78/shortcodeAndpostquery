<?php
/**
 * The sidebar containing the main widget area.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package careunit
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
$blog_layout = careunit_sidebar_layoutpossition('blog_layout', 'sidebarblog_pos');

//<!--Sidebar-->
 if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
	<div class="col-xs-12 col-sm-3">
		<div class="sidebar <?php echo esc_attr($blog_layout['blogsidebar']);?>">
			<?php dynamic_sidebar( 'sidebar-1' ); ?>
		</div>
	</div>
<?php endif; ?>
