<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package careunit
 */

get_header();
careunit_breadcrumb();
global $careunit_opt; ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">
			<!-- ========================================
                    ==Start error content  ==
            ======================================== -->
            <section class="error_container">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="error_page_content">
                                <div class="error_middle_content">
                                    <h1><?php careunit_not_found_img(); ?></h1>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="error_page_content">
                                <div class="error_middle_content">
                                    <h2><?php careunit_not_found_title() ?></h2>
                                    <p><?php careunit_not_found_content(); ?></p>
                                    <a href="<?php echo esc_url( home_url('/') ); ?>" class="careunit_btn btn_colored">
                                        <i class="icofont icofont-long-arrow-left"></i>
                                        <?php esc_html_e('Go Home', 'careunit'); ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
		</main><!-- #main -->
	</div><!-- #primary -->
<?php
get_footer();
