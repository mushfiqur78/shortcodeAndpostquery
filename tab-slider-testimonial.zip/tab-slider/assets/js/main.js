;(function($){
    $(document).ready(function(){

    
       
    // Owl Carousel for Latest Service
    var tab_slid = $('.tesm_slider');
    
    if(tab_slid.length){
    tab_slid.owlCarousel({
        loop:true,
        margin:15,
        autoplay:false,
        dots:false,
        responsive:{
            0:{
                items:1
            },
            768:{
                items:3
            },
            992:{
                items:2
            }
        }
    });
    
    $('.tab_area_nav .testi_next').on('click', function() {
        tab_slid.trigger('next.owl.carousel');
    });
    
    $('.tab_area_nav .testi_prev').on('click', function() {
        tab_slid.trigger('prev.owl.carousel');
    });
    
    $('.doctor_catagory li a').on('click', function (e) {
        e.preventDefault();
        let $this = $(this),
            li = $this.closest('li'),
            content = $this.attr('href');

        li.addClass('active').siblings().removeClass('active');
        $(content).addClass('active').siblings().removeClass('active');
    });
    }

    $('.owl-carousel').owlCarousel({
        items:2,
        merge:true,
        loop:true,
        margin:10,
        video:true,
        lazyLoad:true,
        center:true,
        responsive:{
            480:{
                items:2
            },
            600:{
                items:4
            },
            992:{
                items:2
            }
        }
    })
    
        
    });


    $(window).on('load', function(){
        // tab-pane item height
       var tabpane_height = $('.tab-pane2').height();
       $('.tab-content2').css('height', tabpane_height);
       
   });
})(jQuery);