<?php
// Register Custom Post Type
function bti_post_type() {
	$labels = array(
		'name'                  => _x( 'bti-testimonial', 'Post Type General Name', 'nextwave' ),
		'singular_name'         => _x( 'bti-testimonial', 'Post Type Singular Name', 'nextwave' ),
		'menu_name'             => __( 'bti-testimonial', 'nextwave' ),
		'name_admin_bar'        => __( 'bti-testimonial', 'nextwave' ),
		'archives'              => __( 'Item Archives', 'nextwave' ),
		'attributes'            => __( 'Item Attributes', 'nextwave' ),
		'parent_item_colon'     => __( 'Parent Item:', 'nextwave' ),
		'all_items'             => __( 'All Items', 'nextwave' ),
		'add_new_item'          => __( 'Add New Item', 'nextwave' ),
		'add_new'               => __( 'bti-testimonial', 'nextwave' ),
		'new_item'              => __( 'bti-testimonial', 'nextwave' ),
		'edit_item'             => __( 'Edit Item', 'nextwave' ),
		'update_item'           => __( 'Update Item', 'nextwave' ),
		'view_item'             => __( 'View Item', 'nextwave' ),
		'view_items'            => __( 'View Items', 'nextwave' ),
		'search_items'          => __( 'Search Item', 'nextwave' ),
		'not_found'             => __( 'Not found', 'nextwave' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'nextwave' ),
		'featured_image'        => __( 'Featured Image', 'nextwave' ),
		'set_featured_image'    => __( 'Set featured image', 'nextwave' ),
		'remove_featured_image' => __( 'Remove featured image', 'nextwave' ),
		'use_featured_image'    => __( 'Use as featured image', 'nextwave' ),
		'insert_into_item'      => __( 'Insert into item', 'nextwave' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'nextwave' ),
		'items_list'            => __( 'Items list', 'nextwave' ),
		'items_list_navigation' => __( 'Items list navigation', 'nextwave' ),
		'filter_items_list'     => __( 'Filter items list', 'nextwave' ),
	);
	$args = array(
		'label'                 => __( 'bti-testimonial', 'nextwave' ),
		'description'           => __( 'bti-testimonial', 'nextwave' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
    register_post_type( 'bti-testimonial', $args );
    

}
add_action( 'init', 'bti_post_type', 0 );


// Register Custom Taxonomy
function bti_custom_taxonomy() {

	$labels = array(
		'name'                       => _x( 'Testimonial Categories', 'Taxonomy General Name', 'nextwave' ),
		'singular_name'              => _x( 'Testimonial Categories', 'Taxonomy Singular Name', 'nextwave' ),
		'menu_name'                  => __( 'Testimonial Categories', 'nextwave' ),
		'all_items'                  => __( 'Testimonial Categories', 'nextwave' ),
		'parent_item'                => __( 'Parent Item', 'nextwave' ),
		'parent_item_colon'          => __( 'Parent Item:', 'nextwave' ),
		'new_item_name'              => __( 'Testimonial Categories', 'nextwave' ),
		'add_new_item'               => __( 'Testimonial Categorie', 'nextwave' ),
		'edit_item'                  => __( 'Edit Item', 'nextwave' ),
		'update_item'                => __( 'Update Item', 'nextwave' ),
		'view_item'                  => __( 'View Item', 'nextwave' ),
		'separate_items_with_commas' => __( 'Separate items with commas', 'nextwave' ),
		'add_or_remove_items'        => __( 'Add or remove items', 'nextwave' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'nextwave' ),
		'popular_items'              => __( 'Popular Items', 'nextwave' ),
		'search_items'               => __( 'Search Items', 'nextwave' ),
		'not_found'                  => __( 'Not Found', 'nextwave' ),
		'no_terms'                   => __( 'No items', 'nextwave' ),
		'items_list'                 => __( 'Items list', 'nextwave' ),
		'items_list_navigation'      => __( 'Items list navigation', 'nextwave' ),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => false,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
	);
	register_taxonomy( 'testimonial-category', array( 'bti-testimonial' ), $args );

}
add_action( 'init', 'bti_custom_taxonomy', 0 );